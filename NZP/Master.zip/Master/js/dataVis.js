//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////                                                                                              //////  
//////                 NET ZERO PATHWAYS: DATA VISUALISATIONS                                       //////
//////                         version:  v0.1                                                       //////
//////  ------------------------------------------------------------------------------------------  //////
//////   This module contains scripts to build data visualisations in the HRoM model.               //////
//////   This script is a adapted and licensed  from the Little Sketches Project HRoM library       //////                                                                                            //////               
//////   and  comes with the same MIT License and can be used and adapted freely                    ////// 
//////                                                                                              //////  
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////
/////////  GLOBAL VISUALISATIONS SETTINGS & STATUS OBJECT   ////////
////////////////////////////////////////////////////////////////////

    // Visualisation data and settings
    const vis = {
        focus:                          null,
        renderStatus: {
            emissionsBarCharts:         false,
            costCurve:                  false,
            abatementWedges:            false,
        },
        colours:{
            byEmissionSector:           {},
            palette: {
                forest:             '#005468',
                aqua:               '#4FC6E0',
                red:                '#d7153a',
                blue:               '#002664',
                charcoal:              '#ddd'
            }
        },
        numberFormatters: {
            formatComma:                d3.format(",.0f"),
            formatPct:                  d3.format(".0%"),
            formatPct1dec:              d3.format(".1%"),
            formatInteger:              d3.format(".0f"),   
            formatCostInteger:          d3.format("$,.0f")  
        },     
        helpers:                        {},
        commentary:                     {},
    }

////////////////////////////////////////////////////////////////////
////////   MARGINAL ABATEMENT COST CURVE INTERACTIVE TOOL  /////////
////////////////////////////////////////////////////////////////////
       
    async function renderCostCurve(svgID = 'costCurve-vis', ref='main', mode = 'interactive'){    
        // 0. Setup cost curve data object, and add methods=
            vis.costCurve = {
                chartData:                  [],
                actionData:                  '',
                inputType:                  '',
                svg:                        d3.select('#'+svgID),
                timeHorizon:                settings.parameters.horizon,   
                timeVector:                 Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).fill(0).map((d, i) => i + dataModel.schema.baselineYear),    
                emissionsData: {
                    baselineEmissions:      '', 
                    targetEmissions:        '', 
                    cumAbatement:           0,
                },   
                metrics: {
                    benefitNo:              0,
                    benefitEmissions:       0,
                    costNo:                 0,
                    costEmissions:          0,
                    aveAbatementCost:       0
                },
                dims: {
                    canvasWidth:            1080, 
                    canvasHeight:           720, 
                    margin: {
                        top:                40, 
                        right:              200, 
                        bottom:             50, 
                        left:               100
                    },
                    height:                 '',
                    width:                  ''        
                },
                sectorSourceOrder: [
                    {"Stationary energy": 		["Grid electricity", "Natural gas (reticulated)", "Natural gas (bottled LPG)", "EV charging stations"]},
                    {"Transport": 				["Petrol", "Diesel (transport)", "LPG (transport)", "LNG (transport)", "CNG (transport)","Air travel (short haul)", "Air travel (medium haul)", "Air travel (long haul)"]},
                    {"Waste": 					["Commercial and industrial waste", "Organic waste", "Recycled waste", "Clinical waste" ]},
                    {"Supply chain": 			["Water supply (reticulated)", "Accommodation (domestic)", "Accommodation (international)", "Paper supply"]}
                ],                
                abatementInTargetYear:      0,
                scales:                     {},
                view:                       'curve',
                blockData: {
                    blockIDs:               [], 
                    blockClasses:           [],
                    optionTypeList:         [], 
                    legendIDs:              [],
                },
                tooltipDiv:                 '',
                emissionsScaleMax:          'totalEmissions',
                targetLineRendered:         false,
                targeLineLabelYpos:         60,
                methods:                    {}              
            }

            addCostCurveMethods()
            await vis.costCurve.methods.createCostCurveData();    
            drawCostCurve(vis.costCurve.chartData, 'levelisedCost', 2000, mode);

        // Function to add charting methods of the vis.costCurve object
        function addCostCurveMethods(){
            // Function to draw GreenPower shadow price
            vis.costCurve.methods.offsetLine = function(price, className) {
                const lineData = [ 
                    {"x": 0,    "y": price},
                    {"x": vis.costCurve.emissionsData.targetEmissions, "y": price}
                ]
                const line = d3.line()
                    .x( d => vis.costCurve.scales.xScale(d.x) )
                    .y( d => vis.costCurve.scales.yScale(d.y) )
                vis.costCurve.svg.append('path')
                    .attr('class', 'offsetLine '+className)
                    .attr("d", line(lineData))
            }; // end offsetLine()

            // Function to draw target line
            vis.costCurve.methods.targetLine = function(target, className) {
                const lineData = [ 
                    {"x": target, "y": 0 },
                    {"x": target, "y": height}
                ]
                const line = d3.line()
                    .x( d => vis.costCurve.scales.xScale(d.x))
                    .y( d => vis.costCurve.scales.yScale(d.y))

                vis.costCurve.svg.append('path')
                    .attr('class', 'offsetLine '+className)
                    .attr("d", line(lineData))
            }; // end targetLine()

            // Tooltip for blocks
            vis.costCurve.methods.toolTipOn = function(d, x, y, levelisedCost) {
                const actionData        = vis.costCurve.actionData[d.actionID],
                    name                = d.name,
                    uptakeSitePct       = ui.state.agencyID !== 'allAgency' ? settings.action.byAgency_sitegroup[ui.state.agencyName][d.sitegroup][d.actionID].opportunity.targetUptake : 0,
                    abatementPct        = Math.round(d.abatement /  vis.costCurve.emissionsData.cumAbatement * 1000)/10,
                    abatement           = vis.numberFormatters.formatComma(d.abatement),
                    levelisedCostTip    = Math.round(d['levelisedCost'] * 100)/100    

                vis.costCurve.tooltipDiv  
                    .html("<div id = 'costCurve-tooltip-header' class= 'tooltipHeader'>"+ name 
                        +"</div><div id = 'costCurve-tooltip-uptakeHeader' class = 'tooltipLabel'>Modelled uptake: </div><div id = 'costCurve-tooltip-contributionHeader' class = 'tooltipLabel'>Contribution to modelled reduction</div></div><div id = 'costCurve-tooltip-abatementHeader' class = 'tooltipLabel'>Emissions abatement</div><div id = 'costCurve-tooltip-abatementCostHeader' class = 'tooltipLabel'>Abatement cost per tCO<sub>2</sub>e</div><div id = 'costCurve-tooltip-uptake' class = 'tooltipNumber'>"
                        +vis.numberFormatters.formatPct1dec(uptakeSitePct)+" <span class = 'tooltipUnit'> of sites<br> by "+(vis.costCurve.timeHorizon)
                        +"</span></div><div id = 'costCurve-tooltip-contribution' class = 'tooltipNumber'>"
                        + abatementPct+"%</div><div id = 'costCurve-tooltip-abatement' class = 'tooltipNumber'>" 
                        +abatement+"<br><span class = 'tooltipUnit'>t CO<sub>2</sub>e p.a.</span></div><div id = 'costCurve-tooltip-abatementCost' class = 'tooltipNumber'> $"
                        +levelisedCostTip)
                    .style("left", (x) + "px")   
                    .style("top", (y + 10) + "px")
                    .transition().duration(200)    
                        .style("opacity", .75);   
            }; // end toolTipOn()

            vis.costCurve.methods.toolTipOff = function(){
                vis.costCurve.tooltipDiv.transition().duration(500).style("opacity", 0)
            }; // end toolTipOff()


            // Parse data: add ID anc class fields and sort to least cost order
            vis.costCurve.methods.createCostCurveData = async function(time = vis.costCurve.timeVector.length){
                // 1. Get and set chart variables for selectors
                    let actionBCData, sitegroupBCData, actionSettings, refCaseData = {}
                    switch(ui.state.agencyID){
                        case 'allAgency':
                            switch(ui.state.clusterID){
                                // CASE A: WHOLE OF GOV | ALL AGENCIES 
                                case 'allClusters': 
                                    actionBCData      = model.action.businessCase.byWholeOfGov_action
                                    sitegroupBCData   = model.action.businessCase.byWholeOfGov_sitegroup
                                    actionSettingsObj = model.action.parameters
                                    refCaseData       = model.inventory.referenceCase.summaryTotal
                                    break

                                // CASE B: ALL AGENCIES FOR A SPECIFIED CLUSTER
                                default:                  
                                    actionBCData      = model.action.businessCase.byCluster_action[ui.state.clusterName] 
                                    sitegroupBCData   = model.action.businessCase.byCluster_sitegroup[ui.state.clusterName] 
                                    actionSettingsObj = model.action.parameters
                                    refCaseData       = vis.costCurve.methods.aggregateRefCase(model.inventory.referenceCase.byCluster, ui.state.clusterName)
                                    break
                            }

                            // 2A. Retrieve CostCurve data from all actionBusinessCases and pass to vis.costCurve global object          
                            Object.keys(actionBCData).sort().forEach(actionID => {
                                const actionData            = actionBCData[actionID],
                                    actionParameters        = model.action.parameters[actionID],
                                    actionSettings          = ui.state.sitegroup !== 'none' ? actionSettingsObj[ui.state.sitegroup] :  actionSettingsObj,                 
                                    actionDuration          = actionData.businessCase['Emissions abatement'].filter(d => d !== 0).length,
                                    referenceNetEmissions   = refCaseData.emissions.Total.map((d, i) => d - refCaseData.emissionsSinks.Total[i]),
                                    uptakeAbatement         = actionData.uptakeModel.emissionsReduction.Total,
                                    targetAbatement         = actionData.uptakeModel.emissionsReduction.Total[time],
                                    aveAnnualAbatement      = d3.mean(uptakeAbatement.slice(0, vis.costCurve.timeVector.length))
                                    actionCostCurveObj = {
                                        name:                   actionData.name,
                                        actionID:               actionID,
                                        blockID:                actionID+'-'+ref+'-block',
                                        sector:                 actionParameters.impact.from[0].sector,
                                        source:                 actionParameters.impact.from[0].source,
                                        type:                   actionParameters.impact.type,
                                        levelisedCost:          actionData.businessCase.Metrics['Levelised cost of abatement'],
                                        abatement:              targetAbatement,
                                        abatementUnit:          'tCO2-e',
                                        abatementPct:           targetAbatement / referenceNetEmissions[time],
                                        description:            actionParameters.meta.description       
                                    }
                            
                                vis.costCurve.chartData.push(actionCostCurveObj)
                                vis.costCurve.abatementInTargetYear    += targetAbatement
                                vis.costCurve.metrics.benefitNo        += actionCostCurveObj.levelisedCost < 0 ? 1 : 0
                                vis.costCurve.metrics.benefitEmissions += actionCostCurveObj.levelisedCost < 0 ? actionCostCurveObj.abatement : 0
                                vis.costCurve.metrics.costNo           += actionCostCurveObj.levelisedCost > 0 ? 1 : 0
                                vis.costCurve.metrics.costEmissions    += actionCostCurveObj.levelisedCost > 0 ? actionCostCurveObj.abatement : 0
                            })
                            
                            // 2B. Add ID and classes to block data object
                            vis.costCurve.chartData.forEach( obj => {    
                                const camelType = vis.helpers.camelize(obj.type),
                                    camelSector = vis.helpers.camelize(obj.sector),
                                    camelSource = vis.helpers.camelize(obj.source)
                                obj.class = camelType+" "+camelSector+" "+camelSource 
                            })

                            vis.costCurve.inputType = 'action'
                            break

                        // CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
                        default:     
                            actionBCData      = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName] 
                            sitegroupBCData   = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]
                            actionSettingsObj = settings.action.byAgency_sitegroup[ui.state.agencyName]
                            refCaseData       = vis.costCurve.methods.aggregateRefCase(model.inventory.referenceCase.byAgency, ui.state.agencyName )                                         

                            // 2B. Retrieve CostCurve data from all actionBusinessCases and pass to vis.costCurve global object          
                            Object.keys(actionBCData).forEach(sitegroup => {
                                Object.keys(actionBCData[sitegroup]).sort().forEach(actionID => {                              
                                    const actionData            = actionBCData[sitegroup][actionID],
                                        actionParameters        = model.action.parameters[actionID],
                                        actionSettings          = ui.state.sitegroup !== 'none' ? actionSettingsObj[ui.state.sitegroup] :  actionSettingsObj,                 
                                        actionDuration          = actionData.businessCase['Emissions abatement'].filter(d => d !== 0).length,
                                        referenceNetEmissions   = refCaseData.emissions.Total.map((d, i) => d - refCaseData.emissionsSinks.Total[i]),
                                        uptakeAbatement         = actionData.uptakeModel.emissionsReduction.Total,
                                        targetAbatement         = actionData.uptakeModel.emissionsReduction.Total[time],
                                        aveAnnualAbatement      = d3.mean(uptakeAbatement.slice(0, vis.costCurve.timeVector.length))
                                        actionCostCurveObj = {
                                            name:                   actionData.actionName+' | '+sitegroup,
                                            actionID:               actionID,
                                            blockID:                vis.helpers.camelize(sitegroup)+'-'+actionID+'-'+ref+'-block',
                                            sector:                 actionParameters.impact.from[0].sector,
                                            source:                 actionParameters.impact.from[0].source,
                                            sitegroup:              sitegroup,                                        
                                            type:                   actionParameters.impact.type,
                                            levelisedCost:          actionData.businessCase.Metrics['Levelised cost of abatement'],
                                            abatement:              targetAbatement,
                                            abatementUnit:          'tCO2-e',
                                            abatementPct:           targetAbatement / referenceNetEmissions[time],
                                            description:            actionParameters.meta.description,           
                                        }
                                
                                    vis.costCurve.chartData.push(actionCostCurveObj)
                                    vis.costCurve.abatementInTargetYear    += targetAbatement
                                    vis.costCurve.metrics.benefitNo        += actionCostCurveObj.levelisedCost < 0 ? 1 : 0
                                    vis.costCurve.metrics.benefitEmissions += actionCostCurveObj.levelisedCost < 0 ? actionCostCurveObj.abatement : 0
                                    vis.costCurve.metrics.costNo           += actionCostCurveObj.levelisedCost > 0 ? 1 : 0
                                    vis.costCurve.metrics.costEmissions    += actionCostCurveObj.levelisedCost > 0 ? actionCostCurveObj.abatement : 0
                                })
                            }) 

                            // 3B. Add ID and classes to block data object
                            vis.costCurve.chartData.forEach( obj => {    
                                const camelType = vis.helpers.camelize(obj.type),
                                    camelSector = vis.helpers.camelize(obj.sector),
                                    camelSource = vis.helpers.camelize(obj.source),
                                    camelSitegroup = vis.helpers.camelize(obj.sitegroup)
                                obj.class = camelType+" "+camelSector+" "+camelSource+" "+camelSitegroup
                            })
                            vis.costCurve.inputType = 'actionSitegroup'                        
                    } 
                    vis.costCurve.actionData = actionBCData


                // 4. Sort by levelised cost (lowest first)
                    vis.costCurve.chartData.sort((a,b) => (a.levelisedCost > b.levelisedCost) ? 1 : ((b.levelisedCost > a.levelisedCost) ? -1 : 0) ); 

                // 5. Add a cumulative abatement to each (sorted) action object
                    vis.costCurve.chartData.forEach( obj => {      
                        obj.abatementCumulative = vis.costCurve.emissionsData.cumAbatement;
                        vis.costCurve.emissionsData.cumAbatement += obj.abatement;   
                        vis.costCurve.blockData.blockIDs.push(obj.blockID)          // build BlockIDs array with actionIDs (for scribbles)
                        vis.costCurve.blockData.blockClasses.push(obj.class)        // build blockClasses array (for scribbles)    
                        vis.costCurve.blockData.optionTypeList.push(obj.type)       // build option list type array                     
                    })  

                // 6. Create unique optionType list
                    vis.costCurve.blockData.optionTypeList = vis.costCurve.blockData.optionTypeList.filter(vis.helpers.onlyUnique).sort()
                    for( let i = 0; i < vis.costCurve.blockData.optionTypeList.length; i++){
                        vis.costCurve.blockData.legendIDs[i] = "legendBlock"+vis.helpers.camelize(vis.costCurve.blockData.optionTypeList[i])
                    };

                // 7. Calculate average abatement cost
                    vis.costCurve.chartData.forEach( actionCostCurveObj =>{
                        vis.costCurve.metrics.aveAbatementCost += actionCostCurveObj.levelisedCost * actionCostCurveObj.abatement / vis.costCurve.emissionsData.cumAbatement     
                    })
            }; // end createCostCurveData()

            // Update the data and callback to update the blocks
            vis.costCurve.methods.updateCostCurveData = async function(time = vis.costCurve.timeVector.length){
                // 0. Get and set the reference case data for all agency
                    const refCaseData = vis.costCurve.methods.aggregateRefCase(model.inventory.referenceCase.byAgency, ui.state.agencyName )                      

                // 1. Retrieve CostCurve data for all sitegroup/action blocks
                    vis.costCurve.chartData.forEach( blockObject => {
                        const sitegroup             = typeof blockObject.sitegroup !== 'undefined' ? blockObject.sitegroup : ui.state.sitegroup ,
                            actionData              = typeof model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][sitegroup][blockObject.actionID] !== 'undefined' ? model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][sitegroup][blockObject.actionID] : null,
                            referenceNetEmissions   = refCaseData.emissions.Total.map((d, i) => d - refCaseData.emissionsSinks.Total[i]),
                            uptakeAbatement         = actionData ? actionData.uptakeModel.emissionsReduction.Total : 0,
                            targetAbatement         = actionData ? actionData.uptakeModel.emissionsReduction.Total[vis.costCurve.timeVector.length] : 0,
                            aveAnnualAbatement      = actionData ?  d3.mean(uptakeAbatement.slice(0, vis.costCurve.timeVector.length)) : 0
                        // Update the block object with new action ID
                        blockObject.levelisedCost       = actionData ? actionData.businessCase.Metrics['Levelised cost of abatement'] : 0
                        blockObject.abatement           = targetAbatement
                        blockObject.abatementPct        = targetAbatement / referenceNetEmissions[time]
                    })    

                // 2. Sort by levelised cost (lowest first)
                    vis.costCurve.chartData.sort((a,b) => (a.levelisedCost >b.levelisedCost) ? 1 : ((b.levelisedCost > a.levelisedCost) ? -1 : 0) ); 

                // 3. Update the cumulative abatement and all metrics for the sorted chart data
                    vis.costCurve.emissionsData.cumAbatement = 0
                    vis.costCurve.blockData.blockIDs         = []
                    vis.costCurve.blockData.blockClasses     = []
                    vis.costCurve.metrics.benefitNo          = 0
                    vis.costCurve.metrics.benefitEmissions   = 0
                    vis.costCurve.metrics.costNo             = 0
                    vis.costCurve.metrics.costEmissions      = 0
                    vis.costCurve.metrics.aveAbatementCost   = 0

                    vis.costCurve.chartData.forEach( obj => {      
                        obj.abatementCumulative = vis.costCurve.emissionsData.cumAbatement;
                        vis.costCurve.emissionsData.cumAbatement += obj.abatement;      
                        vis.costCurve.blockData.blockIDs.push(obj.blockID)          // build BlockIDs array with actionIDs (for scribbles)
                        vis.costCurve.blockData.blockClasses.push(obj.class)        // build blockClasses array (for scribbles)    
                        vis.costCurve.metrics.benefitNo        += obj.levelisedCost < 0 ? 1 : 0
                        vis.costCurve.metrics.benefitEmissions += obj.levelisedCost < 0 ? obj.abatement : 0
                        vis.costCurve.metrics.costNo           += obj.levelisedCost > 0 ? 1 : 0
                        vis.costCurve.metrics.costEmissions    += obj.levelisedCost > 0 ? obj.abatement : 0
                    })  
                    vis.costCurve.chartData.forEach( obj => {
                        vis.costCurve.metrics.aveAbatementCost += obj.levelisedCost * obj.abatement / vis.costCurve.emissionsData.cumAbatement  
                    })

                    vis.costCurve.metrics.aveAbatementCost = (vis.costCurve.emissionsData.cumAbatement) ? vis.costCurve.metrics.aveAbatementCost : 0
            }; // end updateCostCurveData()

            // Update the curve blocks
            vis.costCurve.methods.updateBlocks = async function(chartData, animationTime = 500){
                // 1. Update the scales and axis
                const  totalAbatement = (vis.costCurve.emissionsScaleMax === 'totalEmissions') ? d3.max([0.1, d3.sum(chartData, d =>  d.abatement), vis.costCurve.abatementInTargetYear]) : vis.wedgesChart.stockTotal.referenceWorld["netEmissions"][model.schema.reportTime.analysisPeriod]
                vis.costCurve.scales.xScale.domain([0, totalAbatement * 1.05] )
                vis.costCurve.scales.yScale.domain([d3.min([-50, d3.min(chartData,  d => d.levelisedCost) ]), d3.max([50, d3.max(chartData,  d => d.levelisedCost)])  ]) 

                d3.select('.costCurve.x.axis').transition().duration(animationTime).ease(d3.easeLinear)
                    .attr("transform", "translate(0,"+ vis.costCurve.scales.yScale(0) +")")
                    .call(vis.costCurve.scales.xAxis)
                d3.select('.costCurve.y.axis').transition().duration(animationTime).ease(d3.easeLinear)
                    .call(vis.costCurve.scales.yAxis)

                // 2. Update the block positions and widths ; and block labels
                chartData.forEach( blockObject => {       
                    d3.select('#'+blockObject.blockID).transition().duration(animationTime).ease(d3.easeLinear)
                        .attr("x", d => vis.costCurve.scales.xScale(d.abatementCumulative) )
                        .attr("width", d => vis.costCurve.scales.xScale(d.abatement))      
                        .attr("y", d => d.levelisedCost > 0 ? vis.costCurve.scales.yScale(d.levelisedCost) : vis.costCurve.scales.yScale(0) ) 
                        .attr("height", d => Math.abs(vis.costCurve.scales.yScale(d.levelisedCost ? d.levelisedCost : 0) - vis.costCurve.scales.yScale(0)) )          
                        .attr("sitegroup", ui.state.sitegroup)          

                    d3.select('#'+blockObject.blockID_+"_label")
                        .style("text-anchor",    d => d[levelisedCostType] > 0 ? 'end' : 'start')    
                        .transition().duration(animationTime).ease(d3.easeLinear)
                            .attr("x",      d => d[levelisedCostType] > 0 ? vis.costCurve.scales.xScale(d.abatementCumulative) + vis.costCurve.scales.xScale(d3.max([d.abatement, 0.000001])) : vis.costCurve.scales.xScale(d.abatementCumulative)  )
                            .attr('y',      d => vis.costCurve.scales.yScale(d[levelisedCostType]) )                                     
                            .attr("dy",     d => d[levelisedCostType] > 0 ? -10 : 14  ) 
                            .style('opacity', d => d.abatement === 0 ? 0 : null) 
                })

                // 3. Update the summary metrics position and numbers
                d3.select('#costCurveMetrics-group-'+ref).transition().duration(animationTime).ease(d3.easeLinear)                
                    .style('transform', 'translate('+(vis.costCurve.scales.xScale(vis.costCurve.emissionsData.cumAbatement)+10)+'px,'+(vis.costCurve.dims.margin.top*0)+'px)')
                d3.select('#ccMetrics-abatement-'+ref).text(`Annual reduction of ${vis.numberFormatters.formatComma(vis.costCurve.emissionsData.cumAbatement)} tCO2-e of emissions`)
                d3.select('#ccMetrics-abatementCost-l1-'+ref).text(`at an ${vis.costCurve.metrics.aveAbatementCost < 0  ? 'average benefit' : 'average cost'}`)
                d3.select('#ccMetrics-abatementCost-l2-'+ref).text('of '+vis.numberFormatters.formatCostInteger(vis.costCurve.metrics.aveAbatementCost) + ' per tCO2-e')

                // 4. Update the block label positions
                chartData.forEach( blockObject => {    
                    d3.select('#'+blockObject.blockID+'_label').transition().duration(animationTime).ease(d3.easeLinear)
                        .attr("x",      blockObject.levelisedCost > 0 ? vis.costCurve.scales.xScale(blockObject.abatementCumulative) + vis.costCurve.scales.xScale(d3.max([blockObject.abatement, 0.000001])) : vis.costCurve.scales.xScale(blockObject.abatementCumulative)  )
                        .attr('y',      vis.costCurve.scales.yScale(blockObject.levelisedCost) )       
                        .style('opacity', blockObject.abatement < 0.01 ? 0 : null)                                               
                })

                // 5. Update the annotation group (target lines etc.)
                const targetAbatement = vis.wedgesChart.stockTotal.referenceWorld["netEmissions"][vis.costCurve.timeVector.length],
                    gapToTarget = targetAbatement - vis.costCurve.abatementInTargetYear  
                d3.select('#costCurveTargetLabel-'+ref).transition().duration(animationTime).ease(d3.easeLinear)      
                    .style('transform', 'translate('+(10 + vis.costCurve.scales.xScale(targetAbatement))+'px , '+vis.costCurve.targeLineLabelYpos+'px)')
                d3.select('#costCurveAbatementLine-'+ref).transition().duration(animationTime).ease(d3.easeLinear)  
                    .attr('x1', vis.costCurve.scales.xScale(vis.costCurve.emissionsData.cumAbatement))
                    .attr('x2', vis.costCurve.scales.xScale(vis.costCurve.emissionsData.cumAbatement))
                d3.select('#costCurveGapToTargetLabel-'+ref).transition().duration(animationTime).ease(d3.easeLinear)     
                    .style('transform', 'translate('+(10 + vis.costCurve.scales.xScale(vis.costCurve.emissionsData.cumAbatement))+'px , '+(vis.costCurve.targeLineLabelYpos + 30)+'px)')
                d3.select('#costCurveGaptoTarget-label1-'+ref).text(gapToTarget > 0 ? 'Gap to reaching zero emissions' : 'Abatement beyond zero emissions' )
                d3.select('#costCurveGaptoTarget-label2-'+ref).text('of '+vis.numberFormatters.formatComma(gapToTarget) +' tCO2-e' )

                // 6. Show the no curve message if there is no abatement recorded
                if(vis.costCurve.emissionsData.cumAbatement === 0){
                    d3.select('#costCurveMetrics-group-'+ref).classed('hidden', true)         
                    d3.select('#costCurveLegend-'+ref).classed('hidden', true)                                     
                    d3.select('#costCurveNoCurve-group-'+ref).classed('hidden', false)
                        .style('opacity', 0)  
                        .transition().duration(500).delay(1000)
                            .style('opacity', null)                      
                } else {
                    d3.select('#costCurveNoCurve-group-'+ref).classed('hidden', true) 
                    d3.select('#costCurveLegend-'+ref).classed('hidden', false)                        
                    d3.select('#costCurveMetrics-group-'+ref).classed('hidden', false)
                        .style('opacity', 0)  
                            .transition().duration(500).delay(1000)
                            .style('opacity', null)                                  
                }
            }; // end updateBlocks()

            // X. Helper to aggregated referenceCaseDAta
            vis.costCurve.methods.aggregateRefCase = function(refDataObj, targetLevel){
                // a. Initialise obj for each agency/cluster
                const obj  = {
                    cost:           Array(dataModel.schema.modelHorizon).fill(0),
                    emissions: {
                        Scope1:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope2:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope3:     Array(dataModel.schema.modelHorizon).fill(0),
                        Total:      Array(dataModel.schema.modelHorizon).fill(0)
                    },
                    emissionsReduction: {
                        Scope1:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope2:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope3:     Array(dataModel.schema.modelHorizon).fill(0),
                        Total:      Array(dataModel.schema.modelHorizon).fill(0)
                    },
                    emissionsSinks: {
                        Scope1:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope2:     Array(dataModel.schema.modelHorizon).fill(0),
                        Scope3:     Array(dataModel.schema.modelHorizon).fill(0),
                        Total:      Array(dataModel.schema.modelHorizon).fill(0)
                    }                                        
                } 
                // b. Add data for each source
                if(refDataObj[targetLevel]){
                    Object.keys(refDataObj[targetLevel]).forEach(sector => {
                        Object.keys(refDataObj[targetLevel][sector]).forEach( source => {
                            const sourceData = refDataObj[targetLevel][sector][source]                       
                            obj.cost = obj.cost.map( (d,i) => d + sourceData.cost[i])
                            obj.emissions.Scope1 = obj.emissions.Scope1.map( (d,i) => d + sourceData.emissions.Scope1[i])
                            obj.emissions.Scope2 = obj.emissions.Scope2.map( (d,i) => d + sourceData.emissions.Scope2[i])
                            obj.emissions.Scope3 = obj.emissions.Scope3.map( (d,i) => d + sourceData.emissions.Scope3[i])
                            obj.emissions.Total  = obj.emissions.Total.map( (d,i) => d + sourceData.emissions.Total[i])
                            obj.emissionsReduction.Scope1 = obj.emissionsReduction.Scope1.map( (d,i) => d + sourceData.emissionsReduction.Scope1[i])
                            obj.emissionsReduction.Scope2 = obj.emissionsReduction.Scope2.map( (d,i) => d + sourceData.emissionsReduction.Scope2[i])
                            obj.emissionsReduction.Scope3 = obj.emissionsReduction.Scope3.map( (d,i) => d + sourceData.emissionsReduction.Scope3[i])
                            obj.emissionsReduction.Total  = obj.emissionsReduction.Total.map( (d,i) => d + sourceData.emissionsReduction.Total[i])
                            obj.emissionsSinks.Scope1 = obj.emissionsSinks.Scope1.map( (d,i) => d + sourceData.emissionsSinks.Scope1[i])
                            obj.emissionsSinks.Scope2 = obj.emissionsSinks.Scope2.map( (d,i) => d + sourceData.emissionsSinks.Scope2[i])
                            obj.emissionsSinks.Scope3 = obj.emissionsSinks.Scope3.map( (d,i) => d + sourceData.emissionsSinks.Scope3[i])
                            obj.emissionsSinks.Total  = obj.emissionsSinks.Total.map( (d,i) => d + sourceData.emissionsSinks.Total[i])
                        })
                    })
                }
                // c. Return aggregated object
                return obj
            }; // end aggregateRefCase()
        }; // end addCostCurveMethods()


        // Function to draw MACC curve 
        function drawCostCurve(chartData, levelisedCostType, animationTime, mode) {   
            // 0. Remove previous cost curve
                d3.selectAll('#'+svgID+' *, .costCurve-tooltip').remove()

            // 1. Prepare cost curve canvas
                // a. Calculate dimensions and set SVG
                vis.costCurve.dims.width = vis.costCurve.dims.canvasWidth - vis.costCurve.dims.margin.left - vis.costCurve.dims.margin.right
                vis.costCurve.dims.height = vis.costCurve.dims.canvasHeight - vis.costCurve.dims.margin.top - vis.costCurve.dims.margin.bottom
                d3.select('#'+svgID).attr('width', '100%').attr('viewBox', '0 0 '+vis.costCurve.dims.canvasWidth+' '+vis.costCurve.dims.canvasHeight)
                // b. Setup scales and axes
                vis.costCurve.scales.xScale  = d3.scaleLinear().range([0, vis.costCurve.dims.width])
                vis.costCurve.scales.yScale  = d3.scaleLinear().range([vis.costCurve.dims.height, 0])
                vis.costCurve.scales.xAxis   = d3.axisBottom().scale(vis.costCurve.scales.xScale)
                vis.costCurve.scales.yAxis   = d3.axisLeft().scale(vis.costCurve.scales.yScale).ticks(10).tickFormat(d => (d === 0) ? '' : vis.numberFormatters.formatCostInteger(d) )
                // c. Append group for chart             
                vis.costCurve.svg = d3.select("#"+svgID).append("g")
                    .attr('id', 'costCurveGroup-'+ref)
                    .attr("width", vis.costCurve.dims.width + vis.costCurve.dims.margin.left + vis.costCurve.dims.margin.right)
                    .attr("height", vis.costCurve.dims.height + vis.costCurve.dims.margin.top + vis.costCurve.dims.margin.bottom)
                    .append("g")
                        .attr("transform", "translate(" + vis.costCurve.dims.margin.left + "," + vis.costCurve.dims.margin.top + ")");
                // d. Add the tooltips div
                vis.costCurve.tooltipDiv = d3.select("main").append("div").attr("class", "costCurve-tooltip").style("opacity", 0);     // Define the div for the tooltip
            
                // e. Setup groups
                const optionLabelGroup = vis.costCurve.svg.append("g").attr("class", "optionLabelGroup")

            // 2. Set domains for axes from abatement and levelised cost data
                const totalAbatement = d3.sum(chartData, d =>  d.abatement)
                let min = d3.min([-50, d3.min(chartData,  d => d.levelisedCost)]), 
                    max = d3.max([50, d3.max(chartData,  d => d.levelisedCost)]) 

                const clippingNote = d3.select("#"+svgID).append('text')
                    .classed('costCurve-clipping-note', true)
                    .attr('x' , vis.costCurve.dims.width /2)
                    .attr('y' , vis.costCurve.dims.canvasHeight -  vis.costCurve.dims.margin.bottom*0.75)
                    .attr('dy' , 0)

                vis.costCurve.scales.xScale.domain([0, totalAbatement* 1.05] );
                if(mode ==='print' && (d3.min(chartData,  d => d.levelisedCost) < -2000  && d3.max(chartData,  d => d.levelisedCost) > 2000)){
                    min = d3.quantile(chartData.map(d=> d.levelisedCost), 0.05),
                    max = d3.quantile(chartData.map(d=> d.levelisedCost), 0.95)
                    vis.costCurve.scales.yScale.domain([min, max]) 
                    console.log('Clipping MACC axis for better display using p=0.05 ('+Math.round(min)+') and p =0.95 ('+Math.round(max)+')')                    
                    clippingNote.text("This vertical axis of this chart has been clipped as there are a handful of actions with quite 'extreme' abatement benefits and costs (that appear at either end of the cost curve).")
                        .call(vis.helpers.wrap, 380, 1.1) 
                } else if(mode ==='print' && d3.min(chartData,  d => d.levelisedCost) < -2000){
                    min = d3.quantile(chartData.map(d=> d.levelisedCost), 0.05),
                    vis.costCurve.scales.yScale.domain([min, max]) 
                    console.log('Clipping MACC axis for better display using p=0.05 ('+Math.round(min)+') as the minimum)')                    
                    clippingNote.text("This negative part of the vertical axis has been clipped as there are a handful of actions with quite 'extreme' abatement benefits (that appear on the left side of the cost curve).")
                        .call(vis.helpers.wrap, 380, 1.1)
                } else if(mode ==='print' && d3.max(chartData,  d => d.levelisedCost) > 2000){
                    max = d3.quantile(chartData.map(d=> d.levelisedCost), 0.95)
                    vis.costCurve.scales.yScale.domain([min, max]) 
                    console.log('Clipping MACC axis for better display using p=0.05 ('+Math.round(min)+') as the minimum)')                    
                    clippingNote.text("This positive part of the vertical axis has been clipped as there are a handful of actions with quite 'extreme' abatement costs (that appear on the left side of the cost curve).")
                        .call(vis.helpers.wrap, 380, 1.1)
                } else {
                    vis.costCurve.scales.yScale.domain([d3.min([-50, d3.min(chartData,  d => d.levelisedCost) ]), d3.max([50, d3.max(chartData,  d => d.levelisedCost)])  ]) 
                }

            // 3. Add blocks (rectangles)
                vis.costCurve.svg.selectAll(".block").data(chartData)
                    .enter().append("rect")
                    .attr("class", d =>  d.class.replace(/[(/).:]/g,"")+" block" )
                    .attr("id", d =>  d.blockID )
                    .attr("x", d => vis.costCurve.scales.xScale(d.abatementCumulative) )
                    .attr("width", d => vis.costCurve.scales.xScale(d3.max([d.abatement, 0.000001]) ))      // Prevent width from being zero
                    .attr("y", d => d[levelisedCostType] > 0 ? vis.costCurve.scales.yScale(d[levelisedCostType]) : vis.costCurve.scales.yScale(0) )  // Offset positive blocks by height to position correctly on y-axis
                    .attr("height", d => Math.abs(vis.costCurve.scales.yScale(d[levelisedCostType]) - vis.costCurve.scales.yScale(0)) )         
                    .attr("sitegroup", ui.state.sitegroup)                    
                    .on("mouseover", d => vis.costCurve.methods.toolTipOn(d, d3.event.pageX, d3.event.pageY) )          
                    .on("mouseout", vis.costCurve.methods.toolTipOff)        
                    .style('opacity', 0)
                    .transition().duration( (d,i) => (i+1) * 50)
                        .style('opacity', null)
                
            // 4. Add x axis and label
                const xAxisGroup = vis.costCurve.svg.append("g").attr('id', 'costCurveXaxis-'+ref)
                    .attr("class", "x axis costCurve")
                    .attr("transform", "translate(0,"+ vis.costCurve.scales.yScale(0) +")")
                    .call(vis.costCurve.scales.xAxis)
                
                xAxisGroup.append("text")
                    .attr("class", "label costCurve")
                    .attr("transform","translate("+ vis.costCurve.dims.width +", 36)")
                    .style("text-anchor", "end")
                    .text("Scope 1, 2 and 3 emissions abatement")
                    .style('opacity', 0)
                    .transition().duration(500)
                        .style('opacity', null)
                xAxisGroup.append("text")
                    .attr("class", "subLabel costCurve")
                    .attr("transform","translate("+ vis.costCurve.dims.width +", 49)")
                    .style("text-anchor", "end")
                    .text("tonnes of carbon dioxide equivalent per annum")
                    .style('opacity', 0)
                    .transition().duration(500)
                        .style('opacity', null)

            // 5. Add y axis and label
                const yAxisGroup = vis.costCurve.svg.append("g").attr('id', 'costCurveYaxis-'+ref)
                    .attr("class", "y axis costCurve")
                    .call(vis.costCurve.scales.yAxis)
                                       
                yAxisGroup.append("text")
                    .attr("class", "label costCurve")
                    .attr("transform", "rotate(-90)")
                    .attr("y", -62)
                    .style("text-anchor", "end")
                    .text("Marginal cost of abatement")      
                    .style('opacity', 0)
                    .transition().duration(500)
                        .style('opacity', null)      
                yAxisGroup.append("text")
                    .attr("class", "subLabel costCurve")
                    .attr("transform", "rotate(-90)")
                    .attr("y", -52)
                    .style("text-anchor", "end")
                    .text("$ per tonne of carbon dioxide")  
                    .style('opacity', 0)
                    .transition().duration(500)
                        .style('opacity', null)  

            // 6. Add block label group if there are less than 12 action
                if(chartData.length < 20) {
                    optionLabelGroup.selectAll(".optionLabel")
                        .data(chartData).enter().append("text")
                        .attr("class",  d => d.class + " optionLabel")
                        .attr("id",     d => d.blockID+'_label')
                        .attr("x",      d => d[levelisedCostType] > 0 ? vis.costCurve.scales.xScale(d.abatementCumulative) + vis.costCurve.scales.xScale(d3.max([d.abatement, 0.000001])) : vis.costCurve.scales.xScale(d.abatementCumulative)  )
                        .attr('y',      d => vis.costCurve.scales.yScale(d[levelisedCostType]) )                                     
                        .attr("dy",     d => d[levelisedCostType] > 0 ? -10 : 14  ) 
                        .style("text-anchor",    d => d[levelisedCostType] > 0 ? 'end' : 'start')                     
                        .text( d =>   d.abatement < 0.0001 ? '' : d.name)
                        .style('opacity', 0)
                        .transition().duration((d,i) => (i+1) * 50)
                            .style('opacity', d => d.abatement < 0.0001 ? 0 : null  ) 
                }

            // 7. Add Legend
               drawLegend(vis.costCurve.blockData.optionTypeList)

            // 8. Add summary metrics
                const costCurveSummary = vis.costCurve.svg.append('g').attr('id', 'costCurveMetrics-group-'+ref)
                    .style('transform', 'translate('+(vis.costCurve.scales.xScale(vis.costCurve.abatementInTargetYear)+10)+'px,'+(vis.costCurve.dims.margin.top*0)+'px)')
                    .style('opacity', 0)
                    // .transition().duration(500).delay(1000)
                    //     .style('opacity', null)
                // Header
                costCurveSummary.append('text').attr('id', 'ccMetrics-header-'+ref)
                    .classed('costCurve-metrics', true)
                    .attr('x', 0)
                    .attr('y', 0)
                    .text("Total cost and impact")
                // Impact (abatement)
                costCurveSummary.append('text').attr('id', 'ccMetrics-abatement-'+ref)
                    .classed('costCurve-metrics', true)                
                    .attr('x', 0)
                    .attr('y', 18)
                    .text(vis.numberFormatters.formatComma(vis.costCurve.emissionsData.cumAbatement)+' tCO2-e of emissions')

                // Cost per unit
                costCurveSummary.append('text').attr('id', 'ccMetrics-abatementCost-l1-'+ref)
                    .classed('costCurve-metrics', true)                
                    .attr('x', 0)
                    .attr('y', 35)
                    .text( (vis.costCurve.metrics.aveAbatementCost < 0  ? 'saved at an average benefit' : 'saved at an average cost'))
                costCurveSummary.append('text').attr('id', 'ccMetrics-abatementCost-l2-'+ref)
                    .classed('costCurve-metrics', true)                
                    .attr('x', 0)
                    .attr('y', 52)
                    .text('of $'+Math.round(Math.abs(vis.costCurve.metrics.aveAbatementCost*10))/10 + 'per tCO2-e')

            // 9. Add 'no curve' message
                const noCurveMessage = vis.costCurve.svg.append('g').attr('id', 'costCurveNoCurve-group-'+ref)
                    .style('transform', 'translate('+vis.costCurve.scales.xScale(0)+'px,'+(vis.costCurve.dims.margin.top)+'px)')
                noCurveMessage.append('text').attr('id', 'ccNoCurve-header-'+ref)    
                    .classed('costCurve-noCurve', true)
                    .attr('x', 0)
                    .attr('y', 0)
                    .text("There are no actions modelled")                
                noCurveMessage.append('text')
                    .classed('costCurve-noCurve', true)                
                    .attr('x', 0)
                    .attr('y', 18)
                    .text('A cost curve will be shown once actions are')
                noCurveMessage.append('text')
                    .classed('costCurve-noCurve', true)                
                    .attr('x', 0)
                    .attr('y', 35)
                    .text(' modelled with uptake by '+settings.parameters.horizon)
                // Show the no curve messahe if there is no abatement recorded
                if(vis.costCurve.emissionsData.cumAbatement === 0){
                    costCurveSummary.classed('hidden', true)
                    d3.select('#costCurveLegend').classed('hidden', true)                    
                    noCurveMessage.classed('hidden', false)
                        .style('opacity', 0)
                        .transition().duration(500).delay(1000)
                            .style('opacity', null)       
                } else {
                    noCurveMessage.classed('hidden', true)
                    d3.select('#costCurveLegend').classed('hidden', false)
                    costCurveSummary.classed('hidden', false)
                        .style('opacity', 0)
                        .transition().duration(500).delay(1000)
                            .style('opacity', null)                 
                }

            // x. Supporting functions
                // Draw the Legend
                function drawLegend(d,){
                    const dims = vis.costCurve.dims,
                        legend = vis.costCurve.svg.append('g').attr('id', 'costCurveLegend')
                            .style('transform', 'translate('+(dims.width + 13)+'px ,'+(dims.height - dims.margin.bottom)+'px)')
                    
                    legend.append('text').attr('id', 'legend-header-'+ref)
                            .attr("x",  0)
                            .attr("y", (d, i) => -15 )
                            .text('Types of action')
                            .style('opacity', 0)
                            .transition().duration(500).delay(800)
                                .style('opacity', null)
                    legend.selectAll(".block.legend").data(d)
                        .enter().append("rect")
                            .attr('id', d => 'legendBlock'+vis.helpers.camelize(d))
                            .attr('class', d => 'block legend '+vis.helpers.camelize(d))
                            .attr("x",  0)
                            .attr("y", (d, i) => 20 * i)
                            .attr("width", 18)
                            .attr("height", 18)
                            .style('opacity', 0)
                            .transition().duration(500).delay(800)
                                .style('opacity', null)
                    legend.selectAll(".label.legend").data(d)
                        .enter().append("text")
                            .attr('class',  d => 'label legend '+vis.helpers.camelize(d))
                            .attr("x",      d => 20)
                            .attr("y", (d, i) => 22 * i)
                            .attr("dy", 10)
                            .text(d => d.slice(0,1).toUpperCase()+d.slice(1))
                            .style('opacity', 0)
                            .transition().duration(500).delay(800)
                                .style('opacity', null)
                }; // end drawLegend()
        }; // end drawMACC()
    }; // end drawCostCurve()

    // Update the Cost Curve
    async function updateCostCurve(time, levelisedCostType){
        await vis.costCurve.methods.updateCostCurveData(time)
        await vis.costCurve.methods.updateBlocks(vis.costCurve.chartData)
    }; // end updateCostCurve()


////////////////////////////////////////////////////////////////////
//////////////////    ABATEMENT WEDGES CHART      //////////////////
////////////////////////////////////////////////////////////////////

    async function renderWedgesChart(containerID, ref, layout = 'print', mode = "interactive"){
        vis.renderStatus.abatementWedges = true          
        // 0. Setup wedges data object, and add methods
        vis.wedgesChart = {
            svg:                        '',  
            timeHorizon:                settings.parameters.horizon,   
            timeVector:                 Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).fill(0).map((d, i) => i + dataModel.schema.baselineYear),    
            dims: {
                canvasWidth:            layout === 'print' ? 1200 : 1080, 
                canvasHeight:           layout === 'print' ? 800 : 720, 
                margin: {
                    top:                60, 
                    right:              layout === 'print' ? 300 : 200, 
                    bottom:             200, 
                    left:               120
                },
                height:                 '',
                width:                  ''        
            },
            scales:                     {},                                
            actionWedgeData: {
                emissions:              [],
                sinks:                  []
            },
            stockTotal: {
                actionWorld:            {},
                referenceWorld:         {}
            },
            seriesData: {
                wedgesData:             {},
                actionWorldData:        {},
                referenceWorldData:     {},               
            },
            series: {
                emissionsWedges:        {},
                sinksWedges:            {}
            },
            grossData: {
                actionWorldData:        {}                    
            },
            sectorSourceOrder: [
                {"Stationary energy": 		["Grid electricity", "Natural gas (reticulated)", "Natural gas (bottled LPG)", "EV charging stations"]},
                {"Transport": 				["Petrol", "Diesel (transport)", "LPG (transport)", "LNG (transport)", "CNG (transport)","Air travel (short haul)", "Air travel (medium haul)", "Air travel (long haul)"]},
                {"Waste": 					["Commercial and industrial waste", "Organic waste", "Recycled waste", "Clinical waste" ]},
                {"Supply chain": 			["Water supply (reticulated)", "Accommodation (domestic)", "Accommodation (international)", "Paper supply"]}
            ],
            layerOrder:                 [],
            curve:                      d3.curveMonotoneX,
            methods:                    {},
            view: {
                grouping:               'action',       // 'action' or 'sitegroup' ,
                wedgeOutlines:          true,
                layers:                 '',             // Choice of wedge types, emissions "sector", 'summary' of net/gross/offsets, or "actionAbatement" (and 'none')
                type:                   '',             // Stacked or multiples view
                showTotals:             false,          
                showActionLayers:       false           // Boolean to show the action wedges above net emissions (i.e. gap to Reference case)
            }                      
        }   
        addWedgesMethods(vis.wedgesChart.timeHorizon)
        // 0. Remove previous wedges chart but add defs
            d3.selectAll('#'+containerID+' *').remove()
            const glowFilter = d3.select('#'+containerID).append('defs')
                .append('filter').attr('id', ref+'-glow')
            glowFilter.append('feGaussianBlur').classed('blur', true)
                .attr('stdDeviation', 1.5)
                .attr('result', 'coloredBlur')
            const feMerge = glowFilter.append('feMerge')
            feMerge.append('feMergeNode').attr('in', 'coloredBlur')
            feMerge.append('feMeregNode').attr('in', 'SourceGraphic')

        // 1.  Get stock and wedge data 
            await vis.wedgesChart.methods.createWedgesData()
    
        // 2. Draw wedges chart to specified SVG
            drawWedges(containerID, 'emissions', vis.wedgesChart.timeHorizon, layout, mode)

        // 3. Set the starting view
            d3.selectAll('.wedgeLabel').style('opacity', 0)

        // X. Add supporting functions for rendering/updating as methods
            function addWedgesMethods(timeHorizon){         
                vis.wedgesChart.actionWedgeData.emissions = []
                vis.wedgesChart.actionWedgeData.sinks = []
                // Gather wedges chart data
                vis.wedgesChart.methods.createWedgesData = async() => {                    
                    // Initialise actionWorld and referenceWorld objects 
                        let actionCaseData = null,
                            switchCaseData = null,
                            actionBC_bySitegroupData = null,  
                            actionBC_byActionData = null

                        vis.wedgesChart.stockTotal.actionWorld.emissions = {
                            Scope1: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope2: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope3: Array(dataModel.schema.modelHorizon).fill(0),
                            Total: Array(dataModel.schema.modelHorizon).fill(0)
                        }
                        vis.wedgesChart.stockTotal.actionWorld.emissionsSinks = {
                            Scope1: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope2: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope3: Array(dataModel.schema.modelHorizon).fill(0),
                            Total: Array(dataModel.schema.modelHorizon).fill(0)
                        }
                        vis.wedgesChart.stockTotal.referenceWorld.emissions = {
                            Scope1: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope2: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope3: Array(dataModel.schema.modelHorizon).fill(0),
                            Total: Array(dataModel.schema.modelHorizon).fill(0)
                        }
                        vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks = {
                            Scope1: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope2: Array(dataModel.schema.modelHorizon).fill(0),
                            Scope3: Array(dataModel.schema.modelHorizon).fill(0),
                            Total: Array(dataModel.schema.modelHorizon).fill(0)
                        }     

                    // i. GET THE CHART VARIABLES FOR SELECTED VIEW
                        switch(ui.state.agencyID){
                            case 'allAgency':
                                switch(ui.state.clusterID){
                                    // CASE A: WHOLE OF GOV | ALL AGENCIES 
                                    case 'allClusters':                               
                                        actionCaseData = model.inventory.actionCase.bySectorSource
                                        vis.wedgesChart.stockTotal.actionWorld.emissions        = model.inventory.actionCase.summaryTotal.emissions
                                        vis.wedgesChart.stockTotal.actionWorld.emissionsSinks   = model.inventory.actionCase.summaryTotal.emissionsSinks
                                        vis.wedgesChart.stockTotal.referenceWorld.emissions     = model.inventory.referenceCase.summaryTotal.emissions
                                        vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks = model.inventory.referenceCase.summaryTotal.emissionsSinks
                                        actionBC_byActionData = model.action.businessCase.byWholeOfGov_action
                                        actionBC_bySitegroupData = model.action.businessCase.byWholeOfGov_sitegroup  
                                        break
                                    // CASE B: ALL AGENCIES FOR A SPECIFIED CLUSTER
                                    default:                                                                                              
                                        actionCaseData = model.inventory.actionCase.byCluster[ui.state.clusterName]
                                        Object.values(model.inventory.actionCase.byCluster_agency_sitegroup[ui.state.clusterName]).forEach( agencyObj => {
                                            Object.values(agencyObj).forEach(sectorObj => { 
                                                Object.values(sectorObj).forEach(sourceObj => { 
                                                    Object.values(sourceObj).forEach(obj => { 
                                                         if(obj.emissions){
                                                            vis.wedgesChart.stockTotal.actionWorld.emissions = {
                                                                Scope1:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope1.map( (d, i) =>  d + obj.emissions.Scope1[i] ),
                                                                Scope2:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope2.map( (d, i) =>  d + obj.emissions.Scope2[i] ),
                                                                Scope3:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope3.map( (d, i) =>  d + obj.emissions.Scope3[i] ),
                                                                Total:      vis.wedgesChart.stockTotal.actionWorld.emissions.Total.map( (d, i) =>  d + obj.emissions.Total[i] )
                                                            }
                                                        }
                                                        if(obj.emissionsSinks){
                                                            vis.wedgesChart.stockTotal.actionWorld.emissionsSinks = {
                                                                Scope1:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope1.map( (d, i) =>  d + obj.emissionsSinks.Scope1[i] ),
                                                                Scope2:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope2.map( (d, i) =>  d + obj.emissionsSinks.Scope2[i] ),
                                                                Scope3:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope3.map( (d, i) =>  d + obj.emissionsSinks.Scope3[i] ),
                                                                Total:      vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total.map( (d, i) =>   d + obj.emissionsSinks.Total[i] )
                                                            }
                                                        }
                                                    })
                                                })
                                            })
                                        }) 
                                        Object.values(model.inventory.referenceCase.byCluster_agency_sitegroup[ui.state.clusterName]).forEach( agencyObj => {
                                            Object.values(agencyObj).forEach(sectorObj => { 
                                                Object.values(sectorObj).forEach(sourceObj => { 
                                                    Object.values(sourceObj).forEach(obj => { 
                                                        vis.wedgesChart.stockTotal.referenceWorld.emissions = {
                                                            Scope1:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope1.map( (d, i) =>  d + obj.emissions.Scope1[i] ),
                                                            Scope2:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope2.map( (d, i) =>  d + obj.emissions.Scope2[i] ),
                                                            Scope3:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope3.map( (d, i) =>  d + obj.emissions.Scope3[i] ),
                                                            Total:      vis.wedgesChart.stockTotal.referenceWorld.emissions.Total.map( (d, i) =>  d + obj.emissions.Total[i] )
                                                        }
                                                        vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks = {
                                                            Scope1:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope1.map( (d, i) =>  d + obj.emissionsSinks.Scope1[i] ),
                                                            Scope2:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope2.map( (d, i) =>  d + obj.emissionsSinks.Scope2[i] ),
                                                            Scope3:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope3.map( (d, i) =>  d + obj.emissionsSinks.Scope3[i] ),
                                                            Total:      vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Total.map( (d, i) =>   d + obj.emissionsSinks.Total[i] )
                                                        }
                                                    })
                                                })
                                            })
                                        }) 
                                        actionBC_byActionData = model.action.businessCase.byCluster_action[ui.state.clusterName] 
                                        actionBC_bySitegroupData = model.action.businessCase.byCluster_sitegroup[ui.state.clusterName]   
                                        break
                                }
                                break
                            // CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
                            default:                                                              
                                actionCaseData = model.inventory.actionCase.byAgency[ui.state.agencyName]
                                switchCaseData = model.inventory.switchToCase.byAgency[ui.state.agencyName]
                                // Add emissions from actions
                                Object.entries(model.inventory.actionCase.byAgency_sitegroup[ui.state.agencyName]).forEach( ([sitegroup, sectorObj]) => {
                                    Object.entries(sectorObj).forEach(([sector, sourceObj]) => { 
                                        Object.entries(sourceObj).forEach(([source, obj]) => { 
                                            if(obj.emissions){
                                                vis.wedgesChart.stockTotal.actionWorld.emissions = {
                                                    Scope1:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope1.map( (d, i) =>  d + obj.emissions.Scope1[i]),
                                                    Scope2:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope2.map( (d, i) =>  d + obj.emissions.Scope2[i]),
                                                    Scope3:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope3.map( (d, i) =>  d + obj.emissions.Scope3[i]),
                                                    Total:      vis.wedgesChart.stockTotal.actionWorld.emissions.Total.map( (d, i) =>  d + obj.emissions.Total[i] )
                                                }
                                            }
                                            if(obj.emissionsSinks){
                                                vis.wedgesChart.stockTotal.actionWorld.emissionsSinks = {
                                                    Scope1:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope1.map( (d, i) =>  d + obj.emissionsSinks.Scope1[i] ),
                                                    Scope2:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope2.map( (d, i) =>  d + obj.emissionsSinks.Scope2[i] ),
                                                    Scope3:     vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Scope3.map( (d, i) =>  d + obj.emissionsSinks.Scope3[i] ),
                                                    Total:      vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total.map( (d, i) =>   d + obj.emissionsSinks.Total[i] )
                                                }
                                            }
                                        })
                                    })
                                })   
                                // Add switched to emissions
                                Object.entries(model.inventory.switchToCase.byAgency_sitegroup[ui.state.agencyName]).forEach( ([sitegroup, sectorObj]) => {
                                    Object.entries(sectorObj).forEach(([sector, sourceObj]) => { 
                                        Object.entries(sourceObj).forEach(([source, obj]) => { 
                                            if(obj.emissions){
                                                vis.wedgesChart.stockTotal.actionWorld.emissions = {
                                                    Scope1:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope1.map( (d, i) =>  d + obj.emissions.Scope1[i]),
                                                    Scope2:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope2.map( (d, i) =>  d + obj.emissions.Scope2[i]),
                                                    Scope3:     vis.wedgesChart.stockTotal.actionWorld.emissions.Scope3.map( (d, i) =>  d + obj.emissions.Scope3[i]),
                                                    Total:      vis.wedgesChart.stockTotal.actionWorld.emissions.Total.map( (d, i) =>  d + obj.emissions.Total[i] )
                                                }
                                            }
                                        })
                                    })
                                })   



                                Object.values(model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName]).forEach( sectorObj => {
                                    Object.values(sectorObj).forEach(sourceObj => { 
                                        Object.values(sourceObj).forEach(obj => { 
                                            vis.wedgesChart.stockTotal.referenceWorld.emissions = {
                                                Scope1:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope1.map( (d, i) =>  d + obj.emissions.Scope1[i] ),
                                                Scope2:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope2.map( (d, i) =>  d + obj.emissions.Scope2[i] ),
                                                Scope3:     vis.wedgesChart.stockTotal.referenceWorld.emissions.Scope3.map( (d, i) =>  d + obj.emissions.Scope3[i] ),
                                                Total:      vis.wedgesChart.stockTotal.referenceWorld.emissions.Total.map( (d, i) =>  d + obj.emissions.Total[i] )
                                            }
                                            vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks = {
                                                Scope1:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope1.map( (d, i) =>  d + obj.emissionsSinks.Scope1[i] ),
                                                Scope2:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope2.map( (d, i) =>  d + obj.emissionsSinks.Scope2[i] ),
                                                Scope3:     vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Scope3.map( (d, i) =>  d + obj.emissionsSinks.Scope3[i] ),
                                                Total:      vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Total.map( (d, i) =>   d + obj.emissionsSinks.Total[i] )
                                            }
                                        })
                                    })
                                })        
                                actionBC_byActionData = model.action.businessCase.byAgency_action[ui.state.agencyName]
                                actionBC_bySitegroupData = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]
                        } 

                    // ii. ADD PROJECTED EMISSIONS WEDGES 
                        vis.wedgesChart.actionWedgeData.emissions = []
                        vis.wedgesChart.actionWedgeData.sinks = []
                        // I. By sources
                        vis.wedgesChart.sectorSourceOrder.forEach((d,i) => {
                            const sector = Object.keys(d)[0], sources = Object.values(d)[0]                                
                            sources.forEach( source => {
                                const actionData = actionCaseData[sector][source]
                                if(typeof actionData !== 'undefined'){                            
                                    vis.wedgesChart.actionWedgeData.emissions.push({
                                        class:                  'emissionsWedge positiveWedge source',
                                        label:                  source,
                                        emissions:              actionData.emissions,
                                    })
                                } else {
                                    vis.wedgesChart.actionWedgeData.emissions.push({
                                        class:                  'emissionsWedge positiveWedge source dummy',
                                        label:                  'dummy',
                                        emissions: {
                                            Scope1:             Array(dataModel.schema.modelHorizon).fill(0),
                                            Scope2:             Array(dataModel.schema.modelHorizon).fill(0),
                                            Scope3:             Array(dataModel.schema.modelHorizon).fill(0),
                                            Total:              Array(dataModel.schema.modelHorizon).fill(0)
                                        }
                                    })
                                }
                            })
                        })

                    // iii. ADD ACTION WEDGES 
                        // By action and by sitegroup
                        switch(vis.wedgesChart.view.grouping){
                            case 'action':
                                // Abatement wedges by actionID
                                dataModel.schema.actions.ids.forEach( actionID => {    
                                    // Push action data if actionID exists
                                    if(typeof actionBC_byActionData[actionID] !== 'undefined'){
                                        const actionData = actionBC_byActionData[actionID]    
                                        vis.wedgesChart.actionWedgeData.emissions.push({
                                            class:                      `actionWedge positiveWedge abatement`,
                                            label:                      actionData.name,                                
                                            actionID:                   actionID,
                                            emissions: {
                                                   Scope1:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsRedExSinks.Scope1.length) ? actionData.uptakeModel.emissionsRedExSinks.Scope1[i] : actionData.uptakeModel.emissionsRedExSinks.Scope1[actionData.uptakeModel.emissionsRedExSinks.Scope1.length -1] ),
                                                   Scope2:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsRedExSinks.Scope2.length) ? actionData.uptakeModel.emissionsRedExSinks.Scope2[i] : actionData.uptakeModel.emissionsRedExSinks.Scope2[actionData.uptakeModel.emissionsRedExSinks.Scope2.length -1] ),
                                                   Scope3:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsRedExSinks.Scope3.length) ? actionData.uptakeModel.emissionsRedExSinks.Scope3[i] : actionData.uptakeModel.emissionsRedExSinks.Scope3[actionData.uptakeModel.emissionsRedExSinks.Scope3.length -1] ),
                                                   Total:       Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsRedExSinks.Total.length) ? actionData.uptakeModel.emissionsRedExSinks.Total[i] : actionData.uptakeModel.emissionsRedExSinks.Total[actionData.uptakeModel.emissionsRedExSinks.Total.length -1] )
                                            },
                                            reducedNaturalVolume:       actionData.uptakeModel.reducedNaturalVolume
                                        })                   
                                        // If a sink exists, push another wedge or a sink
                                        if(actionData.name === 'Renewable PPAs' || actionData.name === 'Solar Photovoltaics (PV)'  ) {
                                            vis.wedgesChart.actionWedgeData.sinks.push({
                                                class:                  'actionWedge negativeWedge sink',
                                                label:                  actionData.name,                                
                                                actionID:               actionID,
                                                emissions: {
                                                       Scope1:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsSinks.Scope1.length) ? actionData.uptakeModel.emissionsSinks.Scope1[i] : actionData.uptakeModel.emissionsSinks.Scope1[actionData.uptakeModel.emissionsSinks.Scope1.length -1] ),
                                                       Scope2:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsSinks.Scope2.length) ? actionData.uptakeModel.emissionsSinks.Scope2[i] : actionData.uptakeModel.emissionsSinks.Scope2[actionData.uptakeModel.emissionsSinks.Scope2.length -1] ),
                                                       Scope3:      Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsSinks.Scope3.length) ? actionData.uptakeModel.emissionsSinks.Scope3[i] : actionData.uptakeModel.emissionsSinks.Scope3[actionData.uptakeModel.emissionsSinks.Scope3.length -1] ),
                                                       Total:       Array(dataModel.schema.modelHorizon).fill(0).map((d,i) => (i < actionData.uptakeModel.emissionsSinks.Total.length) ? actionData.uptakeModel.emissionsSinks.Total[i] : actionData.uptakeModel.emissionsSinks.Total[actionData.uptakeModel.emissionsSinks.Total.length -1] )
                                                }, 
                                                reducedNaturalVolume:   actionData.uptakeModel.reducedNaturalVolume
                                            })
                                        }
                                    // OR Push a dummy positive action
                                    } else { 
                                        vis.wedgesChart.actionWedgeData.emissions.push({
                                            class:                  'emissionsWedge positiveWedge abatement dummy',
                                            label:                  'dummy',
                                            emissions: {
                                                Scope1:             Array(dataModel.schema.modelHorizon).fill(0),
                                                Scope2:             Array(dataModel.schema.modelHorizon).fill(0),
                                                Scope3:             Array(dataModel.schema.modelHorizon).fill(0),
                                                Total:              Array(dataModel.schema.modelHorizon).fill(0)
                                            }
                                        })
                                    }
                                })
                                break

                             case 'sitegroup':
                                break
                        }

                    // v. GUARD FOR EMPTY SERIES
                        if(vis.wedgesChart.actionWedgeData.emissions.length === 0){
                            // Push an empty sink as placeholder
                            vis.wedgesChart.actionWedgeData.emissions.push({
                                class:                  'actionWedge positiveWedge abatement dummy',
                                label:                  '',                                
                                actionID:               '',
                                emissions: {
                                    Scope1:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Scope2:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Scope3:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Total:              Array(dataModel.schema.modelHorizon).fill(0)
                                }, 
                                reducedNaturalVolume:   Array(dataModel.schema.modelHorizon).fill(0)
                            })
                        }
                             
                        if( vis.wedgesChart.actionWedgeData.sinks.length === 0){
                            // Push an empty sink as placeholder
                            vis.wedgesChart.actionWedgeData.sinks.push({
                                class:                  'actionWedge negativeWedge sink dummy',
                                label:                  '',                                
                                actionID:               '',
                                emissions: {
                                    Scope1:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Scope2:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Scope3:             Array(dataModel.schema.modelHorizon).fill(0),
                                    Total:              Array(dataModel.schema.modelHorizon).fill(0)
                                }, 
                                reducedNaturalVolume:   Array(dataModel.schema.modelHorizon).fill(0)
                            })
                        }

                    // iv. CREATE SERIES DATA
                        // 1. Create series for emissions sources  and emissions actions
                        vis.wedgesChart.layerOrderEmissions = vis.wedgesChart.actionWedgeData.emissions.map( d => d.label)
                        vis.wedgesChart.layerOrderSinks = vis.wedgesChart.actionWedgeData.sinks.map( d => d.label)
                        vis.wedgesChart.seriesData.wedgesData.emissions = {}    
                        vis.wedgesChart.seriesData.wedgesData.sinks = {}    
                        vis.wedgesChart.timeVector.forEach( (time, i) => {
                            vis.wedgesChart.seriesData.wedgesData.emissions[time] = {}    
                            vis.wedgesChart.seriesData.wedgesData.sinks[time] = {}   
                            vis.wedgesChart.layerOrderEmissions.forEach( (layer, j) => {
                                vis.wedgesChart.seriesData.wedgesData.emissions[time][layer] = vis.wedgesChart.actionWedgeData.emissions[j].emissions.Total[i]
                            })
                            vis.wedgesChart.layerOrderSinks.forEach( (layer, j) => {
                                vis.wedgesChart.seriesData.wedgesData.sinks[time][layer] = vis.wedgesChart.actionWedgeData.sinks[j].emissions.Total[i]
                            })
                            // Create series data for layering
                            const emissionsData = Object.values(vis.wedgesChart.seriesData.wedgesData.emissions),
                                sinksData = Object.values(vis.wedgesChart.seriesData.wedgesData.sinks)
                            vis.wedgesChart.series.emissionsWedges =  d3.stack().keys(vis.wedgesChart.layerOrderEmissions)(emissionsData)
                            vis.wedgesChart.series.sinksWedges =  d3.stack().keys(vis.wedgesChart.layerOrderSinks)(sinksData)
                        })
                        // 2. Calculate net emissions lines
                        vis.wedgesChart.stockTotal.referenceWorld.netEmissions  = vis.wedgesChart.stockTotal.referenceWorld.emissions.Total.map( (d,i) => d + vis.wedgesChart.stockTotal.referenceWorld.emissionsSinks.Total[i])
                        vis.wedgesChart.stockTotal.actionWorld.netEmissions     = vis.wedgesChart.stockTotal.actionWorld.emissions.Total.map( (d,i) => d + vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total[i])
                        vis.wedgesChart.stockTotal.actionWorld.totalSinks       = vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total
                        vis.wedgesChart.stockTotal.actionWorld.grossEmissions   = vis.wedgesChart.stockTotal.actionWorld.emissions.Total
                }; // end createWedgesData()

                // Set axis domains
                vis.wedgesChart.methods.setAxisDomains = async(stockName) => {
                    const minSink = d3.min(Object.values(vis.wedgesChart.seriesData.wedgesData.sinks).map(d => d3.sum(Object.values(d)))) 
                    vis.wedgesChart.scales.xScale.domain([dataModel.schema.baselineYear, timeHorizon])
                    vis.wedgesChart.scales.yScale.domain([minSink, d3.max(vis.wedgesChart.stockTotal.referenceWorld.netEmissions) * 1.05 ]);  
                }; // end setAxisDomains()

                // Set shape generators
                vis.wedgesChart.methods.setShapeGenerators = async () => {
                    // a. Line generator
                    vis.wedgesChart.methods.line = d3.line().curve(vis.wedgesChart.curve)
                        .x((d,i) => vis.wedgesChart.scales.xScale(i + dataModel.schema.baselineYear))
                        .y((d) => vis.wedgesChart.scales.yScale(d)) 
                    // b. Stacked area generator
                    vis.wedgesChart.methods.stackedArea = d3.area().curve(vis.wedgesChart.curve)
                        .x( (d, i) => vis.wedgesChart.scales.xScale(i + dataModel.schema.baselineYear))
                        .y0( (d, i) => vis.wedgesChart.scales.yScale(d[0]))
                        .y1( (d, i) => vis.wedgesChart.scales.yScale(d[1])) 
                    // c. Positive area generator (from x-axis)
                    vis.wedgesChart.methods.areaPositive = d3.area().curve(vis.wedgesChart.curve)
                        .x( (d, i) => vis.wedgesChart.scales.xScale(i + dataModel.schema.baselineYear))
                        .y0(vis.wedgesChart.scales.yScale(0))
                        .y1( (d, i) => vis.wedgesChart.scales.yScale(d))  
                    // d. Negative area generator (from x-axis)
                    vis.wedgesChart.methods.areaNegative = d3.area().curve(vis.wedgesChart.curve)
                        .x( (d, i) => vis.wedgesChart.scales.xScale(i + dataModel.schema.baselineYear))
                        .y0(vis.wedgesChart.scales.yScale(0))
                        .y1( (d, i) => vis.wedgesChart.scales.yScale(-d))  
                }; // end setShapeGenerators()

                // ToggleWedgeComponents
                vis.wedgesChart.methods.toggleWedgeComponents = function(duration = 500){
                    d3.selectAll('.actionWedge.abatement, .emissionsWedge.source').transition().duration(duration)
                        style('stroke-width', d => vis.wedgesChart.view.wedgeOutlines ? 0 : null)
                    vis.wedgesChart.view.wedgeOutlines = !vis.wedgesChart.view.wedgeOutlines                   
                }; 

                // Animate the net emissions
                vis.wedgesChart.methods.animatePath = function(id, duration = 2500){
                    const pathLength = d3.select('#'+id).node().getTotalLength()
                    d3.select('#'+id).style('opacity', 1)  
                        .style('stroke-dasharray', pathLength)
                        .style('stroke-dashoffset', pathLength)
                        .transition().duration(duration)
                        .style('stroke-dashoffset', 0)

                    setTimeout(function(){
                        d3.select('#'+id).style('stroke-dasharray', null)
                    }, duration)
                }; // end animatePath()

                // Animate the marker position
                vis.wedgesChart.methods.animateMarker = function(markerID, pathID, duration = 2500){
                    d3.select('#'+markerID).style('opacity', 1)
                        .transition().duration(duration)
                        .attrTween("transform", translateAlong(d3.select('#'+pathID).node()))

                    function translateAlong(path) {
                        const l = path.getTotalLength();
                        return d => {
                            return t => {
                                const p = path.getPointAtLength(t * l);
                                return "translate(" + p.x + "," + p.y + ")"; //Move marker
                            }
                        }
                    }
                }; // end animatePath()

                // Wedge tooltip
                vis.wedgesChart.methods.showWedgeInfo = function(){
                    const  wedgeName = this.id.slice(0, this.id.indexOf("_"))                   
                    d3.select(this).transition().duration(200).style('fill', d3.select(this).classed('source') ? 'var(--complementary-yellow)' : 'var(--complementary-green)')
                    d3.select('#'+wedgeName+'_label').transition().duration(200).style('opacity', 1)
                    d3.selectAll('#'+ref+'-wedge-summarylabels-group, #'+ref+'-stock-labels-group').transition().duration(0).style('opacity', 0)
                };

                vis.wedgesChart.methods.hideWedgeInfo = function(){
                    d3.select(this).transition().duration(0).style('fill', null)
                    d3.selectAll('.wedgeLabel').transition().duration(0).style('opacity', 0)
                    d3.selectAll('#'+ref+'-wedge-summarylabels-group, #'+ref+'-stock-labels-group').transition().duration(0).style('opacity', null)
                };    

                vis.wedgesChart.methods.showDetailedLabel = async function(chartRef = 'main'){
                    // For showing most wedge labels
                    d3.selectAll('#'+chartRef+'-wedge-summarylabels-group, #'+chartRef+'-referenceStock-targetLabel, #'+chartRef+'-actionStock-targetLabel').style('opacity', 0)
                    const wedgePixelSources = vis.wedgesChart.actionWedgeData.emissions.map(d => vis.wedgesChart.scales.yScale(0) - vis.wedgesChart.scales.yScale(d.emissions.Total[vis.wedgesChart.timeVector.length - 1])),
                        wedgePixelSinks = vis.wedgesChart.actionWedgeData.sinks.map(d =>  vis.wedgesChart.scales.yScale(d.emissions.Total[vis.wedgesChart.timeVector.length - 1]) - vis.wedgesChart.scales.yScale(0)),
                        wedgePixel = wedgePixelSources.concat(wedgePixelSinks)

                    d3.selectAll('#'+chartRef+'-wedge-labels-group .wedgeLabel')
                        .data(wedgePixel)
                        .style('opacity', (d, i) => wedgePixel[i] > 8 ? null : 0)
                };


            }; // end addMethods()
        
        // Rendering and data preparation function
            function drawWedges(svgID, stockName, timeHorizon, layout, mode){
                // 1.PREPARE CANVAS 
                    // a. Calculate dimensions and set SVG
                    vis.wedgesChart.dims.width = vis.wedgesChart.dims.canvasWidth - vis.wedgesChart.dims.margin.left - vis.wedgesChart.dims.margin.right
                    vis.wedgesChart.dims.height = vis.wedgesChart.dims.canvasHeight - vis.wedgesChart.dims.margin.top - vis.wedgesChart.dims.margin.bottom
                    d3.select('#'+svgID).attr('viewBox', '0 0 '+vis.wedgesChart.dims.canvasWidth+' '+vis.wedgesChart.dims.canvasHeight)

                    // b. Setup scales and axes
                    vis.wedgesChart.scales.xScale  = d3.scaleLinear().range([0, vis.wedgesChart.dims.width])
                    vis.wedgesChart.scales.yScale  = d3.scaleLinear().range([vis.wedgesChart.dims.height, 0])
                    vis.wedgesChart.scales.xAxis   = d3.axisBottom().scale(vis.wedgesChart.scales.xScale).ticks(10).tickFormat( d => (d > timeHorizon) ? '' : vis.numberFormatters.formatInteger(d))
                    vis.wedgesChart.scales.yAxis   = d3.axisLeft().scale(vis.wedgesChart.scales.yScale).ticks(10).tickFormat( d => (d === 0) ? 'Zero emissions' : vis.numberFormatters.formatComma(d))

                    // c. Append group for chart      
                    vis.wedgesChart.svg = d3.select("#"+svgID).append("g")
                        .attr('id', 'wegdesChartGroup')
                        .attr("width", vis.wedgesChart.dims.width + vis.wedgesChart.dims.margin.left + vis.wedgesChart.dims.margin.right)
                        .attr("height", vis.wedgesChart.dims.height + vis.wedgesChart.dims.margin.top + vis.wedgesChart.dims.margin.bottom)
                        .append("g")
                            .attr("transform", "translate(" + vis.wedgesChart.dims.margin.left + "," + vis.wedgesChart.dims.margin.top + ")")
                         
                // 2. DOMAINS AND AXES: Set domains for axes from abatement and levelised cost data
                    vis.wedgesChart.methods.setAxisDomains(stockName)

                // 3. GENERATORS: Define shape generators (addded to methods to recall on update)
                    vis.wedgesChart.methods.setShapeGenerators()

                // 4. ADD WEDGES
                    const wedgesGroup   = vis.wedgesChart.svg.append("g").attr('class', 'allWedges-group'),   
                        wedgesAxes = vis.wedgesChart.svg.append("g").attr('class', 'wedgesChartAxes-group'), 
                        emissionsWedges = wedgesGroup.append("g").attr('class', 'emissionsWedges-group').classed('actionWedges-group', true),
                        sinksWedges     = wedgesGroup.append("g").attr('class', 'sinksWedges-group').classed('actionWedges-group', true),
                        lines           = wedgesGroup.append("g").attr('class', 'lines-group').classed('actionWedges-group', true),  
                        labels          = wedgesGroup.append("g").attr('class', 'labels-group').classed('actionWedges-group', true)

                    // a. Add emissions wedges     
                    emissionsWedges.selectAll("path")
                        .data(vis.wedgesChart.series.emissionsWedges)
                        .join("path")
                            .attr("d", vis.wedgesChart.methods.stackedArea)
                            .attr('id', d => vis.helpers.camelize(d.key).replace(/([^A-Za-z0-9[\]{}_.:-])\s?/g, '')+'-'+ref+'-emissions_wedge')                            
                            .attr('class', (d, i) => {
                                const noSources = [].concat.apply([], vis.wedgesChart.sectorSourceOrder.map(d => Object.values(d)[0])).length,
                                    classes = vis.wedgesChart.actionWedgeData.emissions[i].class.includes('source') ? 'source'+i : 'action_'+(i-noSources + 1) 
                                    return vis.helpers.camelize(d.key)+' '+vis.wedgesChart.actionWedgeData.emissions[i].class 
                            }) 
                            // .on('mouseover', d => d.key === 'renewablePPAs' ? null : vis.wedgesChart.methods.showWedgeInfo)      
                            .on('mouseover', mode === 'interactive' ? vis.wedgesChart.methods.showWedgeInfo : null)                         
                            .on('mouseout', mode === 'interactive' ? vis.wedgesChart.methods.hideWedgeInfo : null)                            

                    // b. Add sinks wedges    
                    sinksWedges.selectAll("path")
                        .data(vis.wedgesChart.series.sinksWedges)
                        .join("path")
                            .attr("d", vis.wedgesChart.methods.stackedArea)
                            .attr('id', d =>vis.helpers.camelize(d.key).replace(/([^A-Za-z0-9[\]{}_.:-])\s?/g, '')+'-'+ref+'-sink_wedge')                           
                            .attr('class', (d, i) => +vis.helpers.camelize(d.key)+' '+vis.wedgesChart.actionWedgeData.sinks[i].class+' sinkWedge sink_'+i )
                            .on('mouseover', mode === 'interactive' ? vis.wedgesChart.methods.showWedgeInfo : null)                                
                            .on('mouseout', mode === 'interactive' ? vis.wedgesChart.methods.hideWedgeInfo : null)    

                // 5. ADD TOTALS LINES AND MARKERS 
                    // a. Add Total stock lines for action and reference case  
                    lines.append("path").attr('id', ref+'-actionEmissionsPath')
                        .datum(Object.values(vis.wedgesChart.stockTotal.actionWorld.netEmissions.slice(0,vis.wedgesChart.timeVector.length) ))
                        .attr("d", vis.wedgesChart.methods.line)    
                        .classed('actionWorld line', true)

                    lines.append("path").attr('id', ref+'-referenceEmissionsPath')
                        .datum(Object.values(vis.wedgesChart.stockTotal.referenceWorld.netEmissions.slice(0,vis.wedgesChart.timeVector.length)))
                        .attr("d", vis.wedgesChart.methods.line)
                        .classed('referenceWorld line', true)

                    lines.append('circle').attr('id', ref+'-referenceEmissionsPathMarker')
                        .classed('referenceEmissionsPathMarker', true)
                        .attr('cx', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1))
                        .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length - 1]))
                        .attr('r',  8)

                    lines.append('circle').attr('id', ref+'-actionEmissionsPathMarker')
                        .classed('actionEmissionsPathMarker', true)
                        .attr('cx', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1))
                        .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length - 1]))
                        .attr('r',  8)    

                    lines.append('circle').attr('id', ref+'-baselineEmissionsPathMarker')
                        .classed('baselineEmissionsPathMarker', true)
                        .attr('cx', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear1))
                        .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0]))
                        .attr('r',  8)

                  // 6. ADD TARGETS
                const targets  = vis.wedgesChart.svg.append("g").attr('class', 'targets-group'),
                    agencyTarget = (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetGHG) ? null 
                        : settings.targets.byAgency[ui.state.agencyName].targetGHG
                    agencyTargetPct = (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetPct_S12) ? null 
                        : settings.targets.byAgency[ui.state.agencyName].targetPct_S12,
                    agencyTargetYear =  (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetYear) ? 0 
                        : settings.targets.byAgency[ui.state.agencyName].targetYear

                    targets.append("line").attr('id', ref+'-targetLine').classed('target line', true)
                        .attr('x1', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear) )
                        .attr('x2', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) )
                        .attr('y1', vis.wedgesChart.scales.yScale(agencyTarget) )
                        .attr('y2', vis.wedgesChart.scales.yScale(agencyTarget) )
                        .classed('hidden', !agencyTarget)

                    targets.append("text").attr('id', ref+'-targetLabel1')
                        .attr("class", "label wedgesChart target")
                        .attr('x', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) - 5)
                        .attr('y', vis.wedgesChart.scales.yScale(agencyTarget))
                        .attr('dy', -5)
                        .text(agencyTargetYear+' target of')
                        .classed('hidden', !agencyTarget)

                    targets.append("text").attr('id', ref+'-targetLabel2')
                        .attr("class", "label wedgesChart target")
                        .attr('x', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) -5)
                        .attr('y', vis.wedgesChart.scales.yScale(agencyTarget))
                        .attr('dy', 10)
                        .text(`a ${helpers.numberFormatters.formatPct(1 - agencyTargetPct)} reduction from baseline`)
                        .classed('hidden', !agencyTarget)

                // 6. ADD AXIS
                    // a. Add x axis and label
                    const xAxisGroup = wedgesAxes.append("g")
                        .attr("class", "x axis wedgesChart")
                        .attr("transform", "translate(0,"+ vis.wedgesChart.scales.yScale(0) +")")
                        .call(vis.wedgesChart.scales.xAxis)

                    // b. Add y axis and label
                    const yAxisGroup = wedgesAxes.append("g")
                        .attr("class", "y axis wedgesChart")
                        .call(vis.wedgesChart.scales.yAxis)
                    yAxisGroup.append("text")
                        .attr("class", "label wedgesChart")
                        .attr("transform", "rotate(-90)")
                        .attr("y", -78)
                        .style("text-anchor", "end")
                        .text("Scope 1, 2 and 3 emissions")           
                    yAxisGroup.append("text")
                        .attr("class", "subLabel wedgesChart")
                        .attr("transform", "rotate(-90)")
                        .attr("y", -65)
                        .style("text-anchor", "end")
                        .text("tonnes of carbon dioxide equivalent")   

                // 7. ADD LABELS
                    // i. Action/source wedge labels
                        const wedgeLabels = labels.append('g').attr('id', ref+'-wedge-labels-group')     
                        wedgeLabels.selectAll('.wedgeLabel.nonSink').data(vis.wedgesChart.series.emissionsWedges).enter()
                            .append('text')
                            .attr('id', d => vis.helpers.camelize(d.key).replace(/([^A-Za-z0-9[\]{}_.:-])\s?/g, '')+'-'+ref+'-emissions_label') 
                            .attr('class', (d, i) => {
                                const noSources = [].concat.apply([], vis.wedgesChart.sectorSourceOrder.map(d => Object.values(d)[0])).length,
                                    classes = vis.wedgesChart.actionWedgeData.emissions[i].class.includes('source') ? 'source' : 'action' 
                                    return classes+' wedgeLabel nonSink'
                            }) 
                            .attr('x', (d, i) => vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 10)
                            .attr('y', (d, i) => vis.wedgesChart.scales.yScale(d[vis.wedgesChart.timeVector.length - 1][1] - (d[vis.wedgesChart.timeVector.length - 1][1] - d[vis.wedgesChart.timeVector.length - 1][0])/2) )                         
                            .attr('dy', 4)
                            .text(d =>  d.key)

                        wedgeLabels.selectAll('.sink.wedgeLabel').data(vis.wedgesChart.series.sinksWedges).enter()
                            .append('text')
                            .attr('id', d =>  vis.helpers.camelize(d.key).replace(/([^A-Za-z0-9[\]{}_.:-])\s?/g, '')+'-'+ref+'-sink_label') 
                            .attr('class', 'sink wedgeLabel') 
                            .attr('x', (d, i) => vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 10)
                            .attr('y', (d, i) => vis.wedgesChart.scales.yScale(d[vis.wedgesChart.timeVector.length - 1][1] - (d[vis.wedgesChart.timeVector.length - 1][1] - d[vis.wedgesChart.timeVector.length - 1][0])/2) )                         
                            .attr('dy', 4)
                            .text(d => d.key === 'Solar Photovoltaics (PV)' ? 'Solar PV exported' : d.key )

                    // ii. Summary Action/source wedge labels
                        const summaryWedgeLabels = labels.append('g').attr('id', ref+'-wedge-summarylabels-group')  , 
                            grossLabel = summaryWedgeLabels.append('g').attr('id', ref+'-grossEmissions-label') 
                                .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( (vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length] - vis.wedgesChart.stockTotal.actionWorld.totalSinks[vis.wedgesChart.timeVector.length]) /2 ) +')' ),
                            emissionsReductionLabel = summaryWedgeLabels.append('g').attr('id', ref+'-emissionReduction-label') 
                                .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length] -  (vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length] - vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length]) /2 )+')' ),
                            sinksLabel = summaryWedgeLabels.append('g').attr('id', ref+'-sinks-label') 
                                .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( vis.wedgesChart.series.sinksWedges[vis.wedgesChart.series.sinksWedges.length-1][vis.wedgesChart.timeVector.length-1][1] /2 ) +')' )

                        grossLabel.append('text').classed('source wedgeLabel-summary', true).attr('dy', -4)
                            .text('Gross emissions')
                        grossLabel.append('text').attr('id', ref+'-grossEmissionsLabel')
                            .classed('source wedgeLabel-summary small', true).attr('dy', 10 )
                            .text(`${vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length - 1])} tCO2-e`)

                        emissionsReductionLabel.append('text').classed('action wedgeLabel-summary', true).attr('dy', -10 )  
                            .text('Emissions')                                           
                        emissionsReductionLabel.append('text').classed('action wedgeLabel-summary', true).attr('dy', 8 )
                            .text('Reduction')
                        emissionsReductionLabel.append('text').attr('id', ref+'-reductionEmissionsLabel')
                            .classed('action wedgeLabel-summary small', true).attr('dy', 20 )
                            .text(`${vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.referenceWorld.emissions.Total[vis.wedgesChart.timeVector.length - 1] - vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length - 1])} tCO2-e`)
                        sinksLabel.append('text').classed('sink wedgeLabel-summary', true)
                            .text('Renewables')                         
                            .attr('dy', 6  )                          
                        sinksLabel.append('text').attr('id', ref+'-sinksLabel')
                            .classed('sink wedgeLabel-summary small', true)
                            .attr('dy', 17  )   
                            .text(`${vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.actionWorld.totalSinks[vis.wedgesChart.timeVector.length - 1])} tCO2-e`)

                     // ii. Stockline labels
                        const stockLabels = labels.append('g').attr('id', ref+'-stock-labels-group'),   
                            referenceStockLabelgroup = stockLabels.append('g').attr('id', ref+'-referenceStock-targetLabel')  
                                .attr('transform',  'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length])+')' )
                            actionStockLabelgroup    = stockLabels.append('g').attr('id', ref+'-actionStock-targetLabel')     
                                .attr('transform',  'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length])+')' ),
                            baselineStockLabelgroup  = stockLabels.append('g').attr('id', ref+'-referenceStock-baselineLabel')     
                                .attr('transform',  'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear) + 20)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0])+')' ),
                            referenceStockPathLabel  = stockLabels.append('g').attr('id', ref+'-referenceStock-lineLabel'), 
                            actionStockPathLabel     = stockLabels.append('g').attr('id', ref+'-actionStock-lineLabel')

                        referenceStockLabelgroup.append('text')
                            .classed('referenceCase target stockLabel', true)
                            .attr('x', 0)
                            .attr('y', -6)
                            .text('BaU emissions')
                        referenceStockLabelgroup.append('text').attr('id', ref+'-referenceCaseTargetLabel')
                            .classed('referenceCase target stockLabel', true)
                            .attr('x', 0)
                            .attr('y', 6)
                            .attr('value', vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length])
                            .text(vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length - 1])+' tCO2-e')

                        baselineStockLabelgroup.append('text')
                            .classed('referenceCase baseline stockLabel', true)
                            .attr('x', 0)
                            .attr('y', -40)
                            .text('Emissions in '+dataModel.schema.baselineYear)
                        baselineStockLabelgroup.append('text').attr('id', ref+'-referenceCaseBaselineLabel')
                            .classed('referenceCase baseline stockLabel', true)
                            .attr('x', 0 )
                            .attr('y', -26)
                            .attr('value', vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0])
                            .text(vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0])+' tCO2-e')

                        actionStockLabelgroup.append('text')
                            .classed('actionCase target stockLabel', true)
                            .attr('x', 0)
                            .attr('y', -6)
                            .text('Net emissions')
                        actionStockLabelgroup.append('text').attr('id', ref+'-actionCaseTargetLabel')
                            .classed('actionCase target stockLabel', true)
                            .attr('x', 0)
                            .attr('y', 6)
                            .attr('value', vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length])
                            .text(vis.numberFormatters.formatComma(vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length - 1])+' tCO2-e')

                        referenceStockPathLabel.append('text').attr('id', ref+'-referenceStockPathLabel')
                            .classed('stockLabel textOnPath referenceCase', true)
                            .style('transform', 'translate(0px, -6px)')                            
                            .append('textPath').attr('link:href', '#'+ref+'-referenceEmissionsPath')
                                .attr('startOffset',     '80%')                                  
                                .text('Business as usual pathway')      

                        actionStockPathLabel.append('text').attr('id', ref+'-actionStockPathLabel')
                            .classed('stockLabel textOnPath actionCase', true)
                            .style('transform', 'translate(0px, -6px)')                            
                            .append('textPath').attr('link:href', '#'+ref+'-actionEmissionsPath')
                                .attr('startOffset',     '80%')                                  
                                .text('Net emissions pathway with actions')     

                    // LABELLING DISPLAY LOGIC 
                        if(Math.round(d3.sum(vis.wedgesChart.stockTotal.referenceWorld.netEmissions) * 100 )/100 === Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.netEmissions) * 100) /100 )  {
                            d3.selectAll('#emissionReduction-label, #actionStock-targetLabel, #actionStock-lineLabel').style('opacity', 0)
                        } else {
                            d3.selectAll('#emissionReduction-label, #actionStock-targetLabel, #actionStock-lineLabel').style('opacity', null)
                        }
                        if(Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total)) === 0 ) {
                            d3.selectAll('#sinks-label').style('opacity', 0)
                        } else {
                            d3.selectAll('#sinks-label').style('opacity', null)
                        }
            }; // end drawWedges
    }; // end renderWedgesChart()


    // Update the wedges chart (called for changes)
    async function updateWedgesChart(ref, stockName = 'emissions', timeHorizon = vis.wedgesChart.timeHorizon, duration = 1500, mode = 'interactive'){    
        // const actionImpact = Math.round(d3.sum(vis.wedgesChart.stockTotal.referenceWorld.netEmissions) *100 )/100 !== Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.netEmissions) * 100) /100,
        //     sinkImpact =  Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total)) !== 0 

        console.log('**** Updating wedges chart')
        // 1. Recalculate the stock and wedge data, update domains for axes and redefine shape generators
            await vis.wedgesChart.methods.createWedgesData()
            await vis.wedgesChart.methods.setAxisDomains(stockName)
            await vis.wedgesChart.methods.setShapeGenerators()
        // Async call fall transitions
            await chartTransitions()

        async function  chartTransitions(){
            const actionImpact = Math.round(d3.sum(vis.wedgesChart.stockTotal.referenceWorld.netEmissions) *100 )/100 !== Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.netEmissions) * 100) /100,
                sinkImpact =  Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.emissionsSinks.Total)) !== 0             

            // 2. Update the emission, action and sink wedges   
                d3.selectAll(".positiveWedge").data(vis.wedgesChart.series.emissionsWedges)
                    .style('pointer-events', 'none')
                    .classed('dummy', d => d3.sum(d.map(e => e[1] - e[0])) === 0 ? true : false)
                    .transition().duration(duration)
                        .attr("d", vis.wedgesChart.methods.stackedArea)

                d3.selectAll(".negativeWedge").data(vis.wedgesChart.series.sinksWedges)
                    .style('pointer-events', 'none')
                    .transition().duration(duration)
                        .attr("d", vis.wedgesChart.methods.stackedArea)
                setTimeout( () => {  d3.selectAll(".positiveWedge, .negativeWedge").style('pointer-events', null) }, duration)

            // 3. Update the axis position
                d3.select('g.x.axis.wedgesChart').transition().duration(duration)     
                    .attr("transform", "translate(0,"+ vis.wedgesChart.scales.yScale(0) +")")
                    .call(vis.wedgesChart.scales.xAxis)
                d3.select('g.y.axis.wedgesChart').transition().duration(duration)  
                    .call(vis.wedgesChart.scales.yAxis)

            // 4. Update the totals lines for action and reference case
                d3.select('#'+ref+'-actionEmissionsPath').transition().duration(duration)                   
                    .attr("d", vis.wedgesChart.methods.line(Object.values(vis.wedgesChart.stockTotal.actionWorld.netEmissions).slice(0,vis.wedgesChart.timeVector.length) ))
                d3.select('#'+ref+'-referenceEmissionsPath').transition().duration(duration)  
                    .attr("d", vis.wedgesChart.methods.line(Object.values(vis.wedgesChart.stockTotal.referenceWorld.netEmissions).slice(0,vis.wedgesChart.timeVector.length) )) 

            // 5. Update the markers lines for action and reference case
                d3.select('#'+ref+'-referenceEmissionsPathMarker').transition().duration(duration)                   
                    .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length - 1]))
                d3.select('#'+ref+'-actionEmissionsPathMarker').transition().duration(duration)  
                    .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length - 1]))
                d3.select('#'+ref+'-baselineEmissionsPathMarker').transition().duration(duration)  
                    .attr('cy', vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0]))

                const agencyTarget = (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetGHG) ? null 
                        : settings.targets.byAgency[ui.state.agencyName].targetGHG
                    agencyTargetPct = (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetPct_S12) ? null 
                        : settings.targets.byAgency[ui.state.agencyName].targetPct_S12,
                    agencyTargetYear =  (typeof(settings.targets.byAgency[ui.state.agencyName]) === 'undefined' || !settings.targets.byAgency[ui.state.agencyName].targetYear) ? null 
                        : settings.targets.byAgency[ui.state.agencyName].targetYear

                    d3.select('#'+ref+'-targetLine').classed('hidden', !agencyTarget)
                        .transition().duration(duration)  
                        .attr('x1', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear) )
                        .attr('x2', vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) )
                        .attr('y1', vis.wedgesChart.scales.yScale(agencyTarget) )
                        .attr('y2', vis.wedgesChart.scales.yScale(agencyTarget) )
                    
            // 6. Update labels
                // i. Wedge labels
                d3.selectAll('.wedgeLabel.nonSink').data(vis.wedgesChart.series.emissionsWedges)
                    .transition().duration(duration)
                    .attr('y', (d, i) => vis.wedgesChart.scales.yScale(d[vis.wedgesChart.timeVector.length - 1][1] - (d[vis.wedgesChart.timeVector.length - 1][1] - d[vis.wedgesChart.timeVector.length - 1][0])/2) )                         
                
                d3.selectAll('.sink.wedgeLabel').data(vis.wedgesChart.series.sinksWedges)
                    .transition().duration(duration)
                    .attr('y', (d, i) => vis.wedgesChart.scales.yScale(d[vis.wedgesChart.timeVector.length - 1][1] - (d[vis.wedgesChart.timeVector.length - 1][1] - d[vis.wedgesChart.timeVector.length - 1][0])/2) )   

                // ii. Summary wedge labels
                d3.select('#'+ref+'-grossEmissions-label').transition().duration(duration)
                    .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( (vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length] - vis.wedgesChart.stockTotal.actionWorld.totalSinks[vis.wedgesChart.timeVector.length]) /2 ) +')' )
                d3.select('#'+ref+'-emissionReduction-label').transition().duration(duration)
                    .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length] -  (vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length] - vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length]) /2 )+')' )
                    .style('opacity', actionImpact ? null ||    Math.round(d3.sum(vis.wedgesChart.stockTotal.actionWorld.netEmissions)) === Math.round(d3.sum(vis.wedgesChart.stockTotal.referenceWorld.netEmissions))  : 0 )
                d3.select('#'+ref+'-sinks-label').transition().duration(duration)
                    .attr('transform', 'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale( vis.wedgesChart.series.sinksWedges[vis.wedgesChart.series.sinksWedges.length-1][vis.wedgesChart.timeVector.length-1][1] /2 ) +')' )
                    .style('opacity', sinkImpact ? null : 0  )
                
                // iii. Stockline markers and labels         
                d3.select('#'+ref+'-referenceStock-targetLabel').transition().duration(duration)
                    .attr('transform',  'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length - 1) + 20)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length])+')' )
                d3.select('#'+ref+'-actionStock-targetLabel').transition().duration(duration)
                    .attr('transform',  'translate('+(vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear + vis.wedgesChart.timeVector.length -1) + 20)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length])+')' ) 
                    .style('opacity', actionImpact ? null : 0  )
                d3.select('#'+ref+'-referenceStock-baselineLabel').transition().duration(duration)
                    .attr('transform',  'translate('+vis.wedgesChart.scales.xScale(dataModel.schema.baselineYear)+' , '+vis.wedgesChart.scales.yScale(vis.wedgesChart.stockTotal.actionWorld.netEmissions[0])+')' ) ,
                d3.select('#'+ref+'-actionStock-lineLabel').transition().duration(duration)
                    .style('opacity', actionImpact ? null : 0  )

                d3.select('#'+ref+'-referenceCaseTargetLabel')
                    .transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length - 1] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                    // .attr('value', vis.wedgesChart.stockTotal.referenceWorld.netEmissions[vis.wedgesChart.timeVector.length])        
                d3.select('#'+ref+'-actionCaseTargetLabel').transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.actionWorld.netEmissions[vis.wedgesChart.timeVector.length - 1] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                    .style('opacity', actionImpact ? null : 0  )
                d3.select('#'+ref+'-referenceCaseBaselineLabel').transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.referenceWorld.netEmissions[0] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                d3.select('#'+ref+'-grossEmissionsLabel').transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length - 1] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                d3.select('#'+ref+'-reductionEmissionsLabel').transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.referenceWorld.emissions.Total[vis.wedgesChart.timeVector.length - 1] - vis.wedgesChart.stockTotal.actionWorld.grossEmissions[vis.wedgesChart.timeVector.length - 1] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                d3.select('#'+ref+'-sinksLabel').transition().duration(duration)
                    .tween("text", function() {
                        let that = d3.select(this),
                            i = d3.interpolateNumber(parseFloat(that.html().slice(0, -6).replace(/,/g, '')), vis.wedgesChart.stockTotal.actionWorld.totalSinks[vis.wedgesChart.timeVector.length - 1] );
                        return function(t) {  that.text(vis.numberFormatters.formatComma(i(t))+' tCO2-e')  };
                    })
                d3.select('#'+ref+'-targetLabel1').classed('hidden', !agencyTarget)
                    .text(agencyTargetYear+' target').transition().duration(duration) 
                        .attr('y', vis.wedgesChart.scales.yScale(agencyTarget) )
                d3.select('#'+ref+'-targetLabel2').classed('hidden', !agencyTarget)
                    .html(vis.numberFormatters.formatPct((1 - agencyTargetPct))+' reduction from baseline')
                    .transition().duration(duration)
                    .attr('y', vis.wedgesChart.scales.yScale(agencyTarget) )
            }
    }; // end updateWedgesChart()


////////////////////////////////////////////////////////////////////
////////////// DATA VISUALISATION HELPER METHODS  /////////////////      
////////////////////////////////////////////////////////////////////

    // Helper to wrap text labels
    vis.helpers.wrap = function(text, width, lineHeight, centerVertical = false) {
        text.each(function() {
            let text = d3.select(this),
                words = text.text().split(/\s+/).reverse(),
                word,
                line = [],
                lineNumber = 0,
                y = text.attr("y"),
                x = text.attr("x"),
                fontSize = parseFloat(text.style("font-size")),
                dy = parseFloat(text.attr("dy")),
                tspan = text.text(null).append("tspan").attr("x", x).attr("y", y).attr("dy", dy + "em");

            while (word = words.pop()) {
                line.push(word);
                tspan.text(line.join(" "));

                if (tspan.node().getComputedTextLength() > width) {
                    line.pop();
                    tspan.text(line.join(" "));
                    line = [word];
                    tspan = text.append("tspan")
                        .attr("x", x)
                        .attr("y",  y)
                        .attr("dy", ++lineNumber * lineHeight + dy + "em").text(word);
                }                    
            }            
            if(centerVertical){
                text.style("transform",  "translateY(-"+(10 * (lineNumber))+"px)")
            }
        })
    }; // end wrap()

    // String to camelCase
    vis.helpers.camelize = function(str) {
        return str.replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, function(match, index) {
            if (+match === 0) return ""; // or if (/\s+/.test(match)) for white spaces
            return index == 0 ? match.toLowerCase() : match.toUpperCase();
        });
    }; // end camelize

    // Filter for unique values
    vis.helpers.onlyUnique = function(value, index, self) { return self.indexOf(value) === index; };

        // Check if an objet is empty
    function isEmpty(obj) {
        for(var key in obj) {
            if(obj.hasOwnProperty(key))
                return false;
        }
        return true;
    }; // end isEmpty()
