///////////////////////////////////////////////////
/// EMISSIONS PATHWAY TOOL FOR DPIE   	  		///
///   Prototype v1.3.x - Enhancement Tranche I  ///
/// 			Updates made April 2021 		///
///////////////////////////////////////////////////


///////////////////////////////////////////////////////////
///////  MODEL DATA (SCHEMA) AND SETTINGS OBJECTS  /////// 
///////////////////////////////////////////////////////////


	// DATA OBJECT: Stores all input data
    const data = { 
		configTables:	{},
    	consumption: {
    		bySiteId: 				{},
    		sourcesBySiteId: 		{}
    	},
		grepProjects: 				{},    	
		grepProjectsBy: 			{},    	
    	siteConsumptionBySource: 	{}
    }   

	// OBJECT FOR USER SETTINGS: this is the object used in the 
	let settings =  {
		targets: {
			byAgency:			{},
			byCluster:			{},		
			wholeOfGov:			{}		
		},
		parameters: {
			financial: 			{},
			general: 			{},
			emissionFactors: 	{
				agencyGridEF: 	{} 				// Stores grid factors used at agency level to account for GreenPower purchases
			},
			activityGrowth: 	{},
			horizon: 			2030,
			years: 				[]
		},
		action: {
			byAgency_sitegroup: 	{}
		}
	}

	// Model data object: input data
	const dataModel = {
		schema: {
			baselineYear: 			casperBaselineYear, 		// Extracted from the CASPER data (from data.js)
			consumption: 			{
				agencyLevelSources: 	[], 					// List filled from data parsing sources from the agencyConsumption Google Sheet
			},
			inventory: 				{},							// Used to store inventory data
			grepProjects: 			{},
			sourceMap: {										// Set of  mapped utility codes and desc 
				ELEC: 			{name: "Grid electricity",					unit: 	"kWh", 		desc: "Small sites electricity (776) and Large sites electricity (777),  Whole of Agency (WOA/ELEC) and off contract (OFF/ELEC)"	},
				NG: 			{name: "Natural gas (reticulated)",			unit: 	"MJ", 		desc: "Natural gas contract (C4000 and WOA/NG) and off contract (OFF/NG) "	},
				LPG: 			{name: "Natural gas (bottled LPG)",			unit: 	"litres",	desc: "Stationary energy LPG gas contracts (C349 and WoA LPG) and off contract (OFF/LPG) "	},
				WATER: 			{name: "Water supply (reticulated)",		unit: 	"kL", 		desc: "Water contracts from Sydney/Hunter water (SW/HW), Sydney water (SW/SW), Whole of Agency (WOA/WATER), and off contract (OFF/WATER)"},
				CI_WASTE: 		{name: "Commercial and industrial waste",	unit: 	"tonnes", 	desc: "General and landfill components of various waste contractors (OFF/WASTE-XXX) and Whole of agency (WOA/WASTE)"},
			},
			unitConversion:{		// Unit conversion tables: covers known units used in CASPER at the time of development (early 2020). 
				MWh: {
						"MWh": 		1,
						"kWh": 		0.001
				},
				GJ: {
						"GJ": 		1,			
						"MJ": 		0.001						
				},
				kL: {
						"kL": 		1,						
						"kl": 		1,						
						"l": 		0.001,							
						"L": 		0.001,							
						"litres": 	0.001,							
				},
				tonnes: { 			// Unit keys are from CASPER (as of early 2020). 
					"General waste-Cubic metres": 		1, 
					"General waste-Litres": 			0.001,
					"General waste-Tonnes": 			1,
					"Landfill-Cubic metres": 			1.2 / 3, 		// Conversion factor applied
					"Landfill-Litres": 					0.001,
					"Landfill-Tonnes": 					1,
					"tonnes": 							1
				}	
			},
			clusterMapping: {
				clusterList: 					[],
				agencyByCluster: 				{},
				agencyToCluster: 				{}
			},
			typologyMapping: {
				modelSitetypeByAgencies: 		{},
				modelSitetypeToSitegroup: 		{}
			},
			actions: 			{},
			interface: {
				agencyList: 					[],
				clusterList: 					[],
				sitegroupByAgency: 				{},
				sitetypeByAgency: 				{}
			},
			agencyGreenPowerMap: 				{}
		},
		uptake: { 		//Generalised uptake curve functions
			sigmoid: 			function(t, curviness = 500, takeoverTime = (settings.parameters.horizon - dataModel.schema.baselineYear)/2, startPct = 0,  endPct = 1, growthStart = 1) {
									return startPct + ((endPct - startPct) / (1 + Math.pow(curviness, (growthStart - t + takeoverTime / 2) / takeoverTime)) )
								},
			updatePresets:  	function(){
									dataModel.uptakePresets["sigmoidMid"].values 		= [...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 500, (settings.parameters.horizon - dataModel.schema.baselineYear) / 2 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)
									dataModel.uptakePresets["sigmoidEarly"].values 		= [...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 100, (settings.parameters.horizon - dataModel.schema.baselineYear) *0.35 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)
									dataModel.uptakePresets["sigmoidLate"].values 		= [...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 500, (settings.parameters.horizon - dataModel.schema.baselineYear) *0.85 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)	
									dataModel.uptakePresets["squareRoot"].values 		= [...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => t / (settings.parameters.horizon - dataModel.schema.baselineYear)).map(d => Math.sqrt(d))	
									dataModel.uptakePresets["linear"].values 			= [...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => t / (settings.parameters.horizon - dataModel.schema.baselineYear))
								}
		}
	}
		// Preset pathways for modelling uptake curves: This is no longer used in the UI and instead is only used to set the default uptake rate of actions(i.e. set as part of the generic action specification)
		dataModel.uptakePresets = {
			"sigmoidMid": {
				label: 				"S-curve uptake",
				description: 		'Assumes a standard sigmoid ("S-shaped") implementation with slow early uptake, followed by an accelration in mid-horizon years and tapering off with saturation in later years.',
				values: 			[...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 500, (settings.parameters.horizon - dataModel.schema.baselineYear) / 2 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)
			}, 
			"sigmoidEarly": {
				label: 				"S-curve with early accelration",
				description: 		'Assumes a standard sigmoid ("S-shaped") implementation with slow early uptake, followed by an accelration in mid-horizon years and tapering off with saturation in later years.',
				values: 			[...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 100, (settings.parameters.horizon - dataModel.schema.baselineYear) *0.35 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)
			},
			"sigmoidLate": {
				label: 				"S-curve with late accelration",
				description: 		'Assumes a standard sigmoid ("S-shaped") implementation with slow early uptake, followed by an accelration in mid-horizon years and tapering off with saturation in later years.',
				values: 			[...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => dataModel.uptake.sigmoid(t, 500, (settings.parameters.horizon - dataModel.schema.baselineYear) *0.85 )).map( (d, i) => i === 0 ? 0 : i === (settings.parameters.horizon - dataModel.schema.baselineYear) ? 1 : d)	
			},			
			"squareRoot": {
				label: 				"Early uptake and tapering",
				description: 		'Assumes a standard sigmoid ("S-shaped") implementation with slow early uptake, followed by an accelration in mid-horizon years and tapering off with saturation in later years.',
				values: 			[...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => t / (settings.parameters.horizon - dataModel.schema.baselineYear)).map(d => Math.sqrt(d))	
			},
			"linear": {
				label: 				"Linear uptake",
				description: 		'Assumes a standard sigmoid ("S-shaped") implementation with slow early uptake, followed by an accelration in mid-horizon years and tapering off with saturation in later years.',
				values: 			[...Array(settings.parameters.horizon - dataModel.schema.baselineYear + 1).keys()].map( t => t / (settings.parameters.horizon - dataModel.schema.baselineYear))
			}	
		}
								
	// MODEL OBJECT: contains key parameters and the modelled data 
	const model = {
		settings: {
			actionModelLevel: 			'sitegroup', 		// This applies to CASPER data. Only 'sitegroup' level modelling is available in this version
			filterByTypology: 			true
		},
		parameters: {
			grep: {
				solarExportPct: 			0.3 			// Sets an assumed overall export rate for existing GREP solar installations
			},
			general: 			{},  			// Stores price assumptions and conversion factors specified in and loaded from the global assumptions backend tables. Time vectors are applied to all of these variables 
			emissionFactors: 	{
				agencyGridEF: 	{} 				// Stores grid factors used at agency level to account for GreenPower purchases
			},				// Stores emissions factors for all sources and scopes, from baseline year and across model horizon (i.e. with temporal vectors applied)
			temporal: 			{}, 			// Stores temporal vectors  (aka growth mulltipliers) specified in the backend tables
			typology: 			{}, 			// Stores the (backend table specified) activity/energy breakdowns by building/asset typology
			financial: 			{}, 			// Stores any financial variable parameters over time (e.g. Discount factor)
		},
		inventory: 	{							// Stores calculated inventory projections and costs. Each case has the same structure which is designed to support interim (and dynamic re-) calcs, visual outputs and reporting
			referenceCase: {						// Baseline inventory projected forward with agency-sitegroup level growth rates and projected emissions factors and prices	 		
				bySite: 							{},
				bySitegroup: 						{},
				byAgency: 							{},
				byAgency_sitegroup: 		 		{},
				byCluster: 							{},
				byCluster_agency_sitegroup: 		{},
				bySectorSource: 					{},
				summaryTotal: 						{}
			},
			actionCase: { 							// The case where modelled action impacts (natural volume, emission and costs) are applied.  This the reference case minus each action impact
				bySite: 							{},
				bySitegroup: 						{},
				byAgency: 							{},				
				byAgency_sitegroup: 				{},
				byCluster: 							{},
				byCluster_agency_sitegroup: 		{},				
				bySectorSource: 					{},
				summaryTotal: 						{}				
			}, 
			switchToCase: { 						// Holds the impact of fuel switches that still generate emissions (e.g. electrification). This is required as an interim holding step to calculate the action case after fuel switching
				bySite: 							{},
				bySitegroup: 						{},
				byAgency: 							{},				
				byAgency_sitegroup: 				{},
				byCluster: 							{},
				byCluster_agency_sitegroup: 		{},				
				bySectorSource: 					{},
				summaryTotal: 						{}		
			}
		},
		action: {								// Holds all modelled action business cases (made at the byAgency_sitegroup) and their aggregation to other reportable levels
			businessCase:{
				byAgency_sitegroup: 				{},							
				byAgency_action: 					{},							
				byCluster_sitegroup: 				{},				
				byCluster_action: 					{},				
				byCluster_sitegroup_action: 		{},				
				byWholeOfGov_sitegroup: 			{},			
				byWholeOfGov_action: 				{},
				byWholeOfGov_sitegroup_action: 		{}
			},
			summaryCount:{
				modelledActions: 					0,
			},	
			parameters: 							{}
		},
		methods: 	{}
	}

	// TEXT CONTENT: loaded from editable Google sheet
	const content = {
		infoPane: 						{},
		sitegroupConsiderations: 		{},
		loadProfile: 					{},
		about: 							[],
	}	

	// UI / STATE MANAGEMENT: Object to monitor changes to the app state 
    const ui = {
    	state: {
    		focus: 						'', 				// "centralPane", "mainMenu", "studioControls", "contextControls", "settings", "modal"
    		scene: 						'menu',
    		clusterID: 					'allClusters',			
    		clusterName: 				'Whole of Government',			
    		agencyID: 					'allAgency', 		// "allAgency" , "multiAgency" xxx", 
    		agencyName: 				'All agencies', 		 
    		sitegroup: 					'none', 			// "none", "xxxsitegroupxxx",
    		actionID: 					'none', 			// "none", "ACTION_1" etc,
    		dataMode: 					'', 				// "aggregate" OR  "agency"
    		multiAgencySelectiom: 		[],
    		pendingRefCaseRecalc: 		false, 				// Flag to trigger update
    		pendingActionCaseRecalc: 	false,
    		pendingChartUpdate: 		false,
    		loadType: 					'aggregate',
			pendingLoad: 				false,
			reloadWarning: 				true
    	},
        dynamics: {
			changedParameter: {
				elementId: 				'',
				parameterType: 			'', 			// "emissionsFactors", "general", "activity"
				parameterName: 			'',
			}
		},
        elements: {
            contentPane:   				document.getElementById('content'),
            centralPane:   				document.getElementById('central-pane'),
            indexButton:   				document.getElementById('icon-menu-container'),
            informationButton:   		document.getElementById('icon-help-container'),
            clusterSelector:   			document.getElementById('viewLevel-selector') ,   
            clusterHeader:   			document.getElementById('header-clusterSelector'), 
            emissionsAgencySelector:   	document.getElementById('emissions-agencySelector'),   
            actionAgencySelector:  		document.getElementById('action-agencySelector'),     
            pathwaysAgencySelector:   	document.getElementById('pathways-agencySelector'),    
            costCurveAgencySelector:   	document.getElementById('costCurve-agencySelector'), 
            reportAgencySelector:   	document.getElementById('report-agencySelector'), 
            mainMenu:   				document.getElementById('mainMenu-container'), 
            infoPane:   				document.getElementById('infoPane-container'), 
            detailsPane:   				document.getElementById('detailsPane-container'),
            reportSelector:   			document.getElementById('report-agencySelector-container'),
        },
        scenes: 						['emissions', 'action', 'pathways', 'costCurve', 'report'],
        inventoryOrder: [
			{"Stationary energy": 		["Grid electricity", "Natural gas (reticulated)", "Natural gas (bottled LPG)", "EV charging stations"]},
		 	{"Transport": 				["Petrol", "Diesel (transport)", "LPG (transport)", "LNG (transport)", "CNG (transport)","Air travel (short haul)", "Air travel (medium haul)", "Air travel (long haul)"]},
		 	{"Waste": 					["Commercial and industrial waste", "Organic waste", "Recycled waste", "Clinical waste" ]},
		 	{"Supply chain": 			["Water supply (reticulated)", "Accommodation (domestic)", "Accommodation (international)", "Paper supply"]}
		],
		userSettings: {
			financial: 		[],
			emissions: 		[],
			conversion: 		[]
		},
        methods: {
            nav:        	{},
            dataView: 		{}
        }
    }


/////////////////////////////
// 0. INITIATE APP BUILD  //
/////////////////////////////

	buildApp()

	async function buildApp(){
		await parseData(configData)  					// 1.
		await buildReferenceCase() 								// 2A.
		await buildSwitchToCase() 								// 2B.
		await setAgencyTargets() 								// 2C.
		await buildActionModels() 								// 3A. 
		await buildActionAndSwitchToCase() 						// 3B. 
		await addUserInterface() 								// 4. 
		await addFileManagement() 		 						// 5.
		await renderWedgesChart('pathways-vis', 'main') 		// 6A.
		await renderCostCurve('costCurve-vis') 					// 6B.
		await toolReady() 										// 7.
		console.log('**** TOOL IS READY!!! ****')
	};


	// Deprecated Tabletop load method for GSheet tables
    function buildAppFromGSTableTop() {
		Tabletop.init({
			key: 			"https://docs.google.com/spreadsheets/d/1egSO6KE0OHs3a4BLTMAVNso7o2Ffhn1JjBgl_YLqNCE/",
			callback: 	async data => {												// Async execution of functions
							await parseData(data)  									// 1.
							await buildReferenceCase() 								// 2A.
							await buildSwitchToCase() 								// 2B.
							await setAgencyTargets() 								// 2C.
							await buildActionModels() 								// 3A. 
							await buildActionAndSwitchToCase() 						// 3B. 
							await addUserInterface() 								// 4. 
							await addFileManagement() 		 						// 5.
							await renderWedgesChart('pathways-vis', 'main') 		// 6A.
							await renderCostCurve('costCurve-vis') 					// 6B.
							await toolReady() 										// 7.
							console.log('**** TOOL IS READY!!! ****')
		 	},					
		    simpleSheet: 	false,
		    wanted: 	[	// Specifies all backend data tables collected for use in building the tool (see above GSheet for documentation)
			    			'globalParameters', 
			    			'temporalParameters', 
			    			'emissionParameters', 
			    			'actionParameters', 
			    			'activityParameters', 
			    			'typologySchema', 
			    			'inventorySchema', 
			    			'siteData', 
			    			'content',
			    			'contentAbout',
			    			'agencyConsumption',
			    			'greenPowerData',
			    			'agencyTargets',
			    		] 				
		});															
	}; // end buildAppFromGSTableTop()

	// Papa parse load method for GSheet tables (requires server)
	// buildAppFromPapaParse()
    function buildAppFromPapaParse() {
		gsTableLinks = {
			'globalParameters' : 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=1487208546&single=true&output=tsv', 
			'temporalParameters': 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=719115374&single=true&output=tsv',
			'emissionParameters': 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=2020752403&single=true&output=tsv',
			'actionParameters': 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=1587413708&single=true&output=tsv',
			'activityParameters': 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=1000197632&single=true&output=tsv',
			'typologySchema': 			'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=47239118&single=true&output=tsv',
			'inventorySchema': 			'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=695019938&single=true&output=tsv',
			'siteData': 				'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=1010190784&single=true&output=tsv',
			'content': 					'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=2082848666&single=true&output=tsv',
			'contentAbout': 			'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=851266421&single=true&output=tsv',
			'agencyConsumption': 		'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=487336511&single=true&output=tsv',
			'greenPowerData': 			'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=616955311&single=true&output=tsv',
			'agencyTargets': 			'https://docs.google.com/spreadsheets/d/e/2PACX-1vSeBcs4QqJvlTntRk1vS5kAnhGh9hjqr_T6bqR4JTEYIVITp6leQ6mZmtqdwWgE8jxRF1Q4Def1QIH4/pub?gid=477274966&single=true&output=tsv',
		}

		let noLoadedTables = 0
		const tablesToLoad = Object.keys(gsTableLinks)
		for (const [tableName, tableURL] of Object.entries(gsTableLinks))   {
			Papa.parse(tableURL,  {
				delimiter: '\t',
				download: true,
				header: true,
				complete: async (results) => {
					data.configTables[tableName] = results.data
					noLoadedTables++
					if(noLoadedTables === tablesToLoad.length){
						await parseData(data.configTables)  					// 1.
						await buildReferenceCase() 								// 2A.
						await buildSwitchToCase() 								// 2B.
						await setAgencyTargets() 								// 2C.
						await buildActionModels() 								// 3A. 
						await buildActionAndSwitchToCase() 						// 3B. 
						await addUserInterface() 								// 4. 
						await addFileManagement() 		 						// 5.
						await renderWedgesChart('pathways-vis', 'main') 		// 6A.
						await renderCostCurve('costCurve-vis') 					// 6B.
						await toolReady() 										// 7.
						console.log('**** TOOL IS READY!!! ****')
						console.log(data.configTables)
					}
				}
			})
		}     

	}; // end renderFromGS()



/////////////////////////////////////////
// 1. DATA PARSING AND SCHEMA CREATION //
/////////////////////////////////////////

	async function parseData(configData){
		console.log('*** 1. PARSING DATA AND BUILDING DATA SCHEMA ***')
		// 1. LINK TO BACKEND GSHEET TABLES
			data.actionParameters 		= parseTable(configData.actionParameters)
			data.globalParameters 		= parseTable(configData.globalParameters)
			data.temporalParameters		= parseTable(configData.temporalParameters)
			data.emissionParameters 	= parseTable(configData.emissionParameters)
			data.activityParameters 	= parseTable(configData.activityParameters)
			data.inventorySchema 		= parseTable(configData.inventorySchema).filter(d => d.toolBoundary.toUpperCase() === "YES")
			data.typologySchema 		= parseTable(configData.typologySchema)
			data.siteData 				= parseTable(configData.siteData)
			data.content 				= parseTable(configData.content)
			data.contentAbout 			= parseTable(configData.contentAbout)
			data.agencyConsumption 		= parseTable(configData.agencyConsumption)
			data.greenPowerData 		= parseTable(configData.greenPowerData)
			data.agencyTargets 			= parseTable(configData.agencyTargets)

console.log(data)

            function parseTable(tableData){
                return tableData.map(row => {
                    const parsedRow = {}
                    Object.entries(row).forEach(([key, value]) => { 
                        parsedRow[key] = (!isNaN(value) || isNaN(parseFloat(value.replace(/\$|,/g, ''))))  ? value : parseFloat(value.replace(/\$|,/g, '')) 
                        // console.log(key,': ',value,'|',isNaN(parseFloat(value.replace(/\$|,/g, ''))), '=> ' ,parsedRow[key]  )    
                    })
                    return parsedRow
                })
            };        


		// 2. EXTRACT SITE GROUP TYPOLOGY SCHEMA
			dataModel.schema.typologyMapping.siteTypesAll  	 	 = [...new Set(data.typologySchema.map(d => d.siteType) )]
			dataModel.schema.typologyMapping.modelSitetypeList 	 = [...new Set(data.typologySchema.filter( d => d.siteGroup !== '').map(d => d.siteType) )]
			dataModel.schema.typologyMapping.modelSitegroupsList = [...new Set(data.typologySchema.filter( d => d.siteGroup !== '').map(d => d.siteGroup) )]
			dataModel.schema.typologyMapping.sitetypeBySitegroup = d3.nest()
				.key(d => d.siteGroup)
				.rollup(v => v.map(d => d.siteType) )				
				.entries(data.typologySchema.filter( d => d.siteGroup !== ''))

		// 3. EXTRACT CONSUMPTION SCHEMA AND MEASURES FROM CASPER DATASET
			data.consumption.nested 	= consumptionData
			dataModel.schema.consumption = {			
				// Lists sorted and unique after creation
				cluster: 					[],
				agency: 					[],
				sites: 						[],
				sitegroups: 				[],
				sources: 					[],
				// Objects for lists by schema grouping all unsorted for search indexing
				agenciesByCluster: 	 			{}, 
				sitegroupsByAgency: 		 	{},  
				sitesByAgencySitegroup: 		{},  
				sourcesBySiteAgencySitegroup: 	{},	 				
				sitegroupsByCluster: 			{},		
				sitesByCluster:  				{},
				sourcesByCluster:  				{},
				sitesByAgency: 					{},				
				sourcesByAgency: 				{}, 
				sitesByAgencySitegroup: 		{},
				sourcesByAgencySitegroup: 		{},
				sourcesByAgencySitegroupSiteId: {},
				sitesByAgencySitegroupSource: 	{}			
			}

			const count = {
				ELEC: 0,
				CI_WASTE: 0,
				WATER: 0,
				NG: 0,
				LPG: 0
			}

			data.consumption.sourcesBySiteId = {
				'Grid electricity': 				{ vol: 0, cost: 0},
				'Natural gas (reticulated)': 		{ vol: 0, cost: 0},
				'Natural gas (bottled LPG)': 		{ vol: 0, cost: 0},
				'Water supply (reticulated)': 		{ vol: 0, cost: 0},
				'Commercial and industrial waste': 	{ vol: 0, cost: 0},
			}
			// Get and build consumption dataset
			await getConsumptionSchema()
				async function getConsumptionSchema(){
					data.consumption.nested.forEach( clusterObj => {
					 	const cluster = Object.keys(clusterObj)[0].replace('"', '').replace('"', '')
					 	dataModel.schema.consumption.agenciesByCluster[cluster] 	= []
					 	dataModel.schema.consumption.sitegroupsByCluster[cluster] 	= []
					 	dataModel.schema.consumption.sitesByCluster[cluster] 		= []
					 	dataModel.schema.consumption.sourcesByCluster[cluster] 		= []
					 	dataModel.schema.consumption.cluster.push(cluster)

					 	Object.values(clusterObj)[0].forEach(agencyObj => {
					 		const agency = Object.keys(agencyObj)[0]			 		
					 		dataModel.schema.consumption.sitegroupsByAgency[agency] 	= []
					 		dataModel.schema.consumption.sitesByAgency[agency] 			= []
							dataModel.schema.consumption.sourcesByAgency[agency] 		= []				 		
					 		dataModel.schema.consumption.sitesByAgencySitegroup[agency] 		= {}
					 		dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency] = {}					 		
					 		dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency] 	= {}
					 		dataModel.schema.consumption.sourcesByAgencySitegroup[agency] 		= {}
					 		dataModel.schema.consumption.agency.push(agency)
					 		dataModel.schema.consumption.agenciesByCluster[cluster].push(agency)

					 		Object.values(agencyObj)[0].forEach(sitegroupObj => {
						 		const sitegroup = Object.keys(sitegroupObj)[0]	
						 		dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup] 		 = []
								dataModel.schema.consumption.sourcesByAgencySitegroup[agency][sitegroup] 	 = []
						 		dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency][sitegroup] = {}
						 		dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency][sitegroup] = {}
								dataModel.schema.consumption.sitegroupsByAgency[agency].push(sitegroup)
								dataModel.schema.consumption.sitegroupsByCluster[cluster].push(sitegroup)
								dataModel.schema.consumption.sitegroups.push(sitegroup)

						 		Object.values(sitegroupObj)[0].forEach(siteIdObj => {
						 			const siteId = Object.keys(siteIdObj)[0]	
						 			dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency][sitegroup][siteId] = [] 
						 			dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency][sitegroup][siteId] = []
						 			dataModel.schema.consumption.sitesByCluster[cluster].push(siteId)
									dataModel.schema.consumption.sitesByAgency[agency].push(siteId) 
						 			dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup].push(siteId) 
						 			dataModel.schema.consumption.sites.push(siteId)
						 			data.consumption.bySiteId[siteId] = {}

						 			Object.values(siteIdObj)[0].forEach(soureObj => {
						 				const source = dataModel.schema.sourceMap[Object.keys(soureObj)[0]].name		 				
						 				dataModel.schema.consumption.sourcesByCluster[cluster].push(source)
						 				dataModel.schema.consumption.sourcesByAgency[agency].push(source)
						 				dataModel.schema.consumption.sourcesByAgencySitegroup[agency][sitegroup].push(source)				 				
						 				dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency][sitegroup][siteId].push(source)		 
										dataModel.schema.consumption.sources.push(source)
										dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency][sitegroup][siteId].push(source)

				 						data.consumption.bySiteId[siteId][source] = { vol: 0, cost: 0}  			// Initialise object to add to (see note below)
										data.consumption.sourcesBySiteId[source].vol += Object.values(soureObj)[0].vol
										data.consumption.sourcesBySiteId[source].cost += Object.values(soureObj)[0].cost
						 				count[Object.keys(soureObj)[0]] += Object.values(soureObj)[0].vol
						 			})
						 			dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency][sitegroup][siteId] = [...new Set([].concat.apply([], dataModel.schema.consumption.sourcesBySiteAgencySitegroup[agency][sitegroup][siteId]))].sort()
						 		})
						 		dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup] = [...new Set([].concat.apply([], dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup]))].sort()
						 		dataModel.schema.consumption.sourcesByAgencySitegroup[agency][sitegroup] = [...new Set([].concat.apply([], dataModel.schema.consumption.sourcesByAgencySitegroup[agency][sitegroup]))].sort()
					 		})
					 		dataModel.schema.consumption.sitesByAgency[agency] 	= [...new Set([].concat.apply([], dataModel.schema.consumption.sitesByAgency[agency]))].sort()
					 		dataModel.schema.consumption.sourcesByAgency[agency] = [...new Set([].concat.apply([], dataModel.schema.consumption.sourcesByAgency[agency]))].sort()
					 	})

						dataModel.schema.consumption.agenciesByCluster[cluster].sort()					 	
					 	dataModel.schema.consumption.sourcesByCluster[cluster] = [...new Set([].concat.apply([], dataModel.schema.consumption.sourcesByCluster[cluster]))].sort()
					 	dataModel.schema.consumption.sitesByCluster[cluster]  = [...new Set([].concat.apply([], dataModel.schema.consumption.sitesByCluster[cluster]))].sort()
					 	dataModel.schema.consumption.sitegroupsByCluster[cluster] = [...new Set([].concat.apply([], dataModel.schema.consumption.sitegroupsByCluster[cluster]))].sort()
					})

					// Create the dataModel.schema.consumption.sitesByAgencySitegroupSource count
					Object.keys(dataModel.schema.consumption.sourcesByAgencySitegroupSiteId).forEach(agency => {
						dataModel.schema.consumption.sitesByAgencySitegroupSource[agency] = {}
						Object.keys(dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency]).forEach(sitegroup => {
							dataModel.schema.consumption.sitesByAgencySitegroupSource[agency][sitegroup] = {}

							Object.keys(data.consumption.sourcesBySiteId).forEach(source => {
								dataModel.schema.consumption.sitesByAgencySitegroupSource[agency][sitegroup][source] = 0
								Object.values(dataModel.schema.consumption.sourcesByAgencySitegroupSiteId[agency][sitegroup]).forEach( sourceArray => {
									if(sourceArray.indexOf(source) > -1){
										dataModel.schema.consumption.sitesByAgencySitegroupSource[agency][sitegroup][source]++
									}
								})
							})
						})
					})
				};

			// Get unique and sorted lists
			dataModel.schema.consumption.agency 	 = [...new Set([].concat.apply([], dataModel.schema.consumption.agency))].sort()
			dataModel.schema.consumption.sitegroups  = [...new Set([].concat.apply([], dataModel.schema.consumption.sitegroups))].sort()
			dataModel.schema.consumption.sources 	 = [...new Set([].concat.apply([], dataModel.schema.consumption.sources))].sort()
			dataModel.schema.consumption.sectors 	 = [...new Set(data.inventorySchema.map(d => d.sector) )].sort()

		// 4. SHAPE CONSUMPTION DATA
			await shapeConsumption()	
				async function shapeConsumption(){		
					data.consumption.nested.forEach( clusterObj => {
						const cluster = Object.keys(clusterObj)[0]
						Object.values(clusterObj)[0].forEach(agencyObj => {
							const agency = Object.keys(agencyObj)[0]			 		
							Object.values(agencyObj)[0].forEach(sitegroupObj => {
								const sitegroup = Object.keys(sitegroupObj)[0]	
								Object.values(sitegroupObj)[0].forEach(siteIdObj => {
									const siteId = Object.keys(siteIdObj)[0]	
									Object.values(siteIdObj)[0].forEach(soureObj => {
										const source = dataModel.schema.sourceMap[Object.keys(soureObj)[0]].name
										if(typeof data.consumption.bySiteId[siteId][source] !== 'undefined'){
											data.consumption.bySiteId[siteId][source].vol  += Object.values(soureObj)[0].vol
											data.consumption.bySiteId[siteId][source].cost += Object.values(soureObj)[0].cost					 					
										} else {
											data.consumption.bySiteId[siteId][source] = Object.values(soureObj)[0] 			//  For some reason not all objects get initalised: Adding this catch seems to initilias everything thats missed in getConsumptionSchema 
										}				
									})
								})
							})
						})
					})
				};

			for( const source of dataModel.schema.consumption.sources){
				data.consumption.sourcesBySiteId[source] = {}
				for( const siteId of Object.keys(data.consumption.bySiteId)){ 
					if(typeof data.consumption.bySiteId[siteId][source] !== 'undefined'){
						if(typeof data.consumption.sourcesBySiteId[source][siteId] === 'undefined'){ 
							data.consumption.sourcesBySiteId[source][siteId]  = {vol: 0, cost: 0}
						} 
						data.consumption.sourcesBySiteId[source][siteId].vol += data.consumption.bySiteId[siteId][source].vol 
						data.consumption.sourcesBySiteId[source][siteId].cost += data.consumption.bySiteId[siteId][source].cost
					}	
				}
			}
			dataModel.schema.siteMeta  = siteMeta

		// 5. EXTRACT INVENTORY SCHEMA (ALL DATA)
			for( const sector of dataModel.schema.consumption.sectors){ dataModel.schema.inventory[sector] = {} }
			for( const d of data.inventorySchema){	
				dataModel.schema.inventory[d.sector][d.source] = {
					description: 		d.description,
					factorDescription: 	d.factorDescription,
					unit: 				d.unit,
					type: 				d.type
				}
			}

		// 6. EXTRACT SITE GROUP / BUILDING TYPOLOGIES 
			// i. Make typologies Sitetype > Group map
				dataModel.schema.typologyMapping.modelSitetypeList.forEach( sitetype => {
					let group 
					dataModel.schema.typologyMapping.sitetypeBySitegroup.forEach(obj => {
						if(obj.value.indexOf(sitetype) > -1) { group = obj.key }
					})
					dataModel.schema.typologyMapping.modelSitetypeToSitegroup[sitetype] = group
				})

			// ii. Set interface lists
				dataModel.schema.consumption.agency.forEach( agency => {
					unassignedIndex = dataModel.schema.consumption.sitegroupsByAgency[agency].indexOf('Unassigned')
					if(unassignedIndex > -1){
						dataModel.schema.interface.sitegroupByAgency[agency] = dataModel.schema.consumption.sitegroupsByAgency[agency].filter(item => item.indexOf('Unassigned') > -1)
					}
				})
				dataModel.schema.interface.agencyList = dataModel.schema.consumption.agency.filter( agency => dataModel.schema.consumption.sitegroupsByAgency[agency].length > 0)

		// 7. SHAPE SYSTEM EXTRACT CONSUMPTION DATA (All by year and source)
			// i. Consumption by site, grouped by source
				dataModel.schema.consumption.sources.forEach( source => {
					data.siteConsumptionBySource[source] = []
					let unit
					Object.values(dataModel.schema.sourceMap).forEach( mapObj=> { if(mapObj.name === source){ unit = mapObj.unit } })
					Object.keys(data.consumption.bySiteId).forEach(siteId => {
						const sourceIndex = Object.keys(data.consumption.bySiteId[siteId]).indexOf(source)
						if(sourceIndex > -1 ){
							const siteMeta = dataModel.schema.siteMeta[siteId],
								obj = {
									...Object.values(data.consumption.bySiteId[siteId])[sourceIndex],
									...dataModel.schema.siteMeta[siteId]
								}
							obj.pc 			= +obj.pc
							obj.unit		= unit

							let cluster, sitegroup 
							Object.keys(dataModel.schema.consumption.agenciesByCluster).forEach(clusterName => {
								if(dataModel.schema.consumption.agenciesByCluster[clusterName].indexOf(obj.ag) > -1){ cluster = clusterName	}
							})
							obj.cluster		= cluster
							obj.sitegroup	= typeof dataModel.schema.typologyMapping.modelSitetypeToSitegroup[obj.type] !== 'undefined' ? dataModel.schema.typologyMapping.modelSitetypeToSitegroup[obj.type] : "Unassigned"
							data.siteConsumptionBySource[source].push({ [siteId]: obj })
						}
					})
				})

		// 8. EXTRACT CLUSTER-AGENCY SCHEMA
			dataModel.schema.interface.clusterList 			= dataModel.schema.consumption.cluster.sort()
			dataModel.schema.clusterMapping.clusterList 	= dataModel.schema.consumption.cluster.sort()
			dataModel.schema.clusterMapping.agencyByCluster = dataModel.schema.consumption.agenciesByCluster
			dataModel.schema.consumption.agency.forEach(agency => {
				Object.keys(dataModel.schema.clusterMapping.agencyByCluster).forEach( cluster => {
					if(dataModel.schema.clusterMapping.agencyByCluster[cluster].indexOf(agency) > -1){
						dataModel.schema.clusterMapping.agencyToCluster[agency] = cluster
					}
				})
			})
			
		// 9. EXTRACT ACTIVITY PARAMETERS BY SITE CLASS DATA
			const fieldsExID = Object.keys(data.activityParameters[0]).filter(d => d !== "sitegroup" && d !== "loadDescription"  && d !== "sitegroupUnit")
			for( const obj of data.activityParameters) {
				model.parameters.typology[obj.sitegroup] = {}
				fieldsExID.forEach(name => {
					model.parameters.typology[obj.sitegroup][name] = isNaN(+obj[name]) ? obj[name] : +obj[name]
				})
				// Extract load profile description to content 
				content.loadProfile[obj.sitegroup] = {
					description: 	obj.loadDescription,
					unitName: 		obj.unitName
				}
			}

		// 10. SETUP DEFAULT FORECAST PARAMETERS AND DATA SCHEMA
			dataModel.schema.dataYears = Object.keys(data.temporalParameters[0]).map(d => +d).filter(d => !isNaN(d))
			// i.  Make temporal parameters
				for( const obj of data.temporalParameters){
					model.parameters.temporal[obj.id] = {
						description: 	obj.description,
						type: 			obj.type,
						values: 		( () => { const vectorObj = {}
											dataModel.schema.dataYears.forEach( year => { vectorObj[year] = +obj[year] })
											return vectorObj
										})()
					}
				}

			// ii. Update model schema
				for( const d of data.globalParameters){ if(d.id === "baselineYear") {dataModel.schema.baselineYear =  +d.value }}
				dataModel.schema.modelYears = Object.keys(data.temporalParameters[0]).map(d => +d).filter(d => !isNaN(d)).slice(dataModel.schema.dataYears.indexOf(dataModel.schema.baselineYear))
				dataModel.schema.modelHorizon = dataModel.schema.modelYears.length

			// iii. Apply 'temporal growth vectors' to global params			
				for( const d of data.globalParameters){
					model.parameters.general[d.id] = {
						name: 				d.label,	
						description: 		d.description,	
						userEditable: 		d.userEditable.toUpperCase() === "YES" ? true : false,									
						sector: 			d.sector,					
						source: 			d.source,					
						type: 				d.type,					
						value: 				d.linkedTemporalID.toLowerCase() === 'none' ? +d.value : dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID]['values'][year] * (model.parameters.temporal[d.linkedTemporalID].type === 'absolute') ? 1 : +d.value) ,
						unit: 				d.unit +(d.unitRate !== "")  ? " per "+d.unitRate : "",
						unitMultiplier: 	+d.unitMultiplier
					}
					// Initialise user editable settings
					if(d.userEditable.toUpperCase() === "YES" ){
						settings.parameters.general[d.id] = {
							sector: 		d.sector,	
							source: 		d.source,	
							value: 			d.linkedTemporalID.toLowerCase() === 'none' ? +d.value : dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID]['values'][year] * (model.parameters.temporal[d.linkedTemporalID].type === 'absolute') ? 1 : +d.value) 
						}
						if(d.type === 'price'){
							ui.userSettings.financial.push(d.id)
						}
						if(d.type === 'conversion'){
							ui.userSettings.conversion.push(d.id)
						}

					}			
				}
			
			// iv. Apply temporal vectors to emission factors
				for( const d of data.emissionParameters) {
					model.parameters.emissionFactors[d.id] = {
						name: 			d.label,	
						description: 	d.description,	
						userEditable: 	d.userEditable.toUpperCase() === "YES" ? true : false,	
						sector: 		d.sector,					
						source: 		d.source,						
						scope1: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope1]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope1].type === 'absolute' ? 1 : +d.scope1) ) ,
						scope2: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope2]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope2].type === 'absolute' ? 1 : +d.scope2) ) ,
						scope3: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope3]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope3].type === 'absolute' ? 1 : +d.scope3) ) ,
						unit: 			d.unit +(d.unitRate !== "")  ? " per "+d.unitRate : ""
					}
					// Initialise user editable settings
					if(d.userEditable.toUpperCase() === "YES" ){
						settings.parameters.emissionFactors[d.id] = {
							sector: 		d.sector,					
							source: 		d.source,							
							scope1: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope1]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope1].type === 'absolute' ? 1 : +d.scope1) ) ,
							scope2: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope2]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope2].type === 'absolute' ? 1 : +d.scope2) ) ,
							scope3: 		dataModel.schema.modelYears.map(year => model.parameters.temporal[d.linkedTemporalID_scope3]['values'][year] * (model.parameters.temporal[d.linkedTemporalID_scope3].type === 'absolute' ? 1 : +d.scope3) ) 
						}
						ui.userSettings.emissions.push(d.id)
					}
				}

			// v. Add Discount factor vector for model and initialise settings
				model.parameters.financial["Discount factor"] = Array(dataModel.schema.modelHorizon).fill(0).map( (d, i) => Math.pow((1 + model.parameters.general.wacc.value), i) ) 
				settings.parameters.financial["Discount factor"] = Array(dataModel.schema.modelHorizon).fill(0).map( (d, i) => Math.pow((1 + model.parameters.general.wacc.value), i) ) 

		// 11. EXTRACT & ANALYSE GREP DATA INCL. estimated OF CURRENT SOLAR INSTALLATIONS
			// i. Copy schema from data.js variables
				data.grepProjects = grepData
				dataModel.schema.grepProjects.projectTypes = grepMeta.projectTypes.filter(d => d !=='' && d !== null)
				dataModel.schema.grepProjects.years = grepMeta.years 

			// ii. Add meta-data to grepProjects
				for(const d of data.grepProjects){
					d.year						= +d.year			
					d.sitegroup  				= typeof dataModel.schema.typologyMapping.modelSitetypeToSitegroup[d.sitetype] !== 'undefined' ? dataModel.schema.typologyMapping.modelSitetypeToSitegroup[d.sitetype] : null				
					d.solarExportkWh 			= +d.eleckWh * (model.parameters.grep.solarExportPct / ( 1 - model.parameters.grep.solarExportPct) )
					d.cluster 					= dataModel.schema.clusterMapping.agencyToCluster[d.agency] 
					if(d.type === "Solar Photovoltaics (PV)"){
						d.solarKW = d.eleckWh / (model.parameters.general.CF_SolarIrradiance_MWh_per_kW.value[0] * 1000)
					}
				}

			// iii. Create groupings for accessing project data: FOR ALL PROJECTS 
				data.grepProjectsBy.projectsByYearAndType = d3.nest()
					.key( d => d.year)
					.key( d => d.type)
					.entries(data.grepProjects)
				data.grepProjectsBy.projectsBySite = d3.nest()
					.key( d => d.siteId)
					.key( d => d.type)
					.entries(data.grepProjects)
				data.grepProjectsBy.projectsByCluster = d3.nest()
					.key( d => d.cluster)
					.key( d => d.type)
					.entries(data.grepProjects)
				data.grepProjectsBy.projectsByAgency_sitegroup = d3.nest()
					.key( d => d.agency)
					.key( d => d.sitegroup)
					.key( d => d.type)
					.entries(data.grepProjects)
				data.grepProjectsBy.projectsByAgency = d3.nest()
					.key( d => d.agency)
					.key( d => d.type)
					.entries(data.grepProjects)
				data.grepProjectsBy.projectsByType = d3.nest()
					.key( d => d.type)
					.entries(data.grepProjects)

			// iv. Get additional baseline solar data: FOR ALL PROJECTS
				const grepSolarDataAll = data.grepProjects.filter(d => d.type === "Solar Photovoltaics (PV)")
				data.grepProjectsBy.solarProjectsAllAgency = d3.nest()
					.rollup(v => { 
						return {	
							"Elec saving (kWh)": 			d3.sum(v, d => d.eleckWh * d.baseImpact ),
							"Solar export (kWh)": 			d3.sum(v, d => d.solarExportkWh * d.baseImpact   ),
							"Solar installed (kW)": 		d3.sum(v, d => d.solarKW  * d.baseImpact   ),
							"No installations": 			d3.sum(v, d => 1 * d.baseImpact  )
						}
					})					
					.entries(grepSolarDataAll)

				data.grepProjectsBy.solarProjectsByCluster = d3.nest()
					.key( d => d.cluster)
					.rollup(v => { 
						return {	
							"Elec saving (kWh)": 		d3.sum(v, d => d.eleckWh * d.baseImpact   ),
							"Solar installed (kW)": 	d3.sum(v, d => d.solarKW * d.baseImpact  ),
							"Solar export (kWh)": 		d3.sum(v, d => d.solarExportkWh * d.baseImpact   ),
							"No installations": 		d3.sum(v, d => 1 * d.baseImpact  )
						}
					})					
					.entries(grepSolarDataAll)

				data.grepProjectsBy.solarProjectsByAgency = d3.nest()
					.key( d => d.agency)
					.rollup(v => { 
						return {	
							"Elec saving (kWh)": 		d3.sum(v, d => d.eleckWh * d.baseImpact ),
							"Solar installed (kW)": 	d3.sum(v, d => d.solarKW * d.baseImpact ),
							"Solar export (kWh)": 		d3.sum(v, d => d.solarExportkWh * d.baseImpact  ),
							"No installations": 		d3.sum(v, d => 1 * d.baseImpact )
						}
					})					
					.entries(grepSolarDataAll)

				data.grepProjectsBy.solarTotalBySitetype = d3.nest()
					.key( d => d.sitetype)
					.rollup(v => { 
						return {	
							"Elec saving (kWh)": 		d3.sum(v, d => d.eleckWh * d.baseImpact ),
							"Solar export (kWh)": 		d3.sum(v, d => d.solarKW * d.baseImpact ),
							"Solar installed (kW)": 	d3.sum(v, d => d.solarExportkWh * d.baseImpact  ),
							"No installations": 		d3.sum(v, d => 1 * d.baseImpact )
						}
					})				
					.entries(grepSolarDataAll)

				data.grepProjectsBy.solarTotalBySitetype_Agency = d3.nest()
					.key( d => d.sitetype)
					.key( d => d.agency)
					.rollup(v => { 
						return {
							"Elec saving (kWh)": 		d3.sum(v, d => d.eleckWh * d.baseImpact ),
							"Solar export (kWh)": 		d3.sum(v, d => d.solarKW * d.baseImpact ),
							"Solar installed (kW)": 	d3.sum(v, d => d.solarExportkWh * d.baseImpact  ),
							"No installations": 		d3.sum(v, d => 1 * d.baseImpact )
						}
					})				
					.entries(grepSolarDataAll)

				data.grepProjectsBy.solarTotal_Agency_sitegroup = d3.nest()
					.key( d => d.agency)
					.key( d => d.sitegroup)
					.rollup(v => { 
						return {
							"Elec saving (kWh)": 		d3.sum(v, d => d.eleckWh * d.baseImpact ),
							"Solar export (kWh)": 		d3.sum(v, d => d.solarKW * d.baseImpact ),
							"Solar installed (kW)": 	d3.sum(v, d => d.solarExportkWh * d.baseImpact ),
							"No installations": 		d3.sum(v, d => 1 * d.baseImpact )							
						}
					})				
					.entries(grepSolarDataAll)

		// 12. EXTRACT ACTION GENERAL MODELS
			dataModel.schema.actions.ids = data.actionParameters.map( d => d.id)
			for( const actionObj of data.actionParameters){
				model.action.parameters[actionObj.id]	= {
					meta: {
						label:  			actionObj.label,
						sector:  			actionObj.sector,
						description:  		actionObj.description,
						longDescription:   	actionObj.longDescription,
						techName:  			actionObj.techName,
						imageURL:  			actionObj.imgURL,
						life:  				+actionObj.economicLife,
						sitegroups:  		Object.keys(JSON.parse(actionObj.opportunityBySitegroup)),
						grepName: 			actionObj.grepName
					},
					impact: 				JSON.parse(actionObj.impact),
					opportunity: 			JSON.parse(actionObj.opportunityBySitegroup),
					cost: {
						capitalCost: 		JSON.parse(actionObj.capitalCost),
						omCost: 			JSON.parse(actionObj.omCost),		
					},
					uptake: 				Array(dataModel.schema.modelHorizon).fill(1).map((d,i) =>  i < dataModel.uptakePresets[actionObj.uptakePath].values.length ? dataModel.uptakePresets[actionObj.uptakePath].values[i] : d) ,
					uptakePreset: 			actionObj.uptakePath	
				}
			}

		// 13.  PARSE THE AGENCY CONSUMPTION DATA
			for( const d of data.agencyConsumption) {
				// d.number = isNaN(parseFloat(d.number.replace(/,/g, ''))) ? 0 : parseFloat(d.number.replace(/,/g, ''))
				// d.volume = isNaN(parseFloat(d.volume.replace(/,/g, ''))) ? 0 : parseFloat(d.volume.replace(/,/g, ''))
				// d.cost =   isNaN(parseFloat(d.cost.replace(/,/g, '')))   ? 0 : parseFloat(d.cost.replace(/,/g, ''))
				d.cluster = dataModel.schema.clusterMapping.agencyToCluster[d.agencyName]
			}
			data.agencyConsumption = data.agencyConsumption.filter(d => dataModel.schema.interface.agencyList.indexOf(d.agencyName) > -1)
			dataModel.schema.consumption.agencyLevelSources = [...new Set(data.agencyConsumption.map(d => d.source))].sort()
			//  Add the "All of agency" sitegroup
			Object.keys(dataModel.schema.consumption.sitegroupsByAgency).forEach(agency => dataModel.schema.consumption.sitegroupsByAgency[agency].push("All of agency") )


		// 14. EXTRACT CUSTOM SITE DATA 
			for( const d of data.siteData){
				for( const source of Object.values(dataModel.schema.sourceMap).map(d => d.name)){
					d[source] = d[source].toLowerCase() === 'yes' ? true : false
				}			
			}

			data.siteDataSitegroupByAgency = d3.nest()
				.key( d => d.agency)
				.rollup(v => { 
					const agencyObj = {},
					 	sitegroups = [...new Set(v.map(d => d.sitegroup))],
					 	sitenames = [...new Set(v.map(d => d.siteName))]
					for( const sitegroup of sitegroups) {
						agencyObj[sitegroup] = {
							sites: 	sitenames
						}
						for( const source of Object.values(dataModel.schema.sourceMap).map(d => d.name)){
							agencyObj[sitegroup][source] = 0
							for (const siteObj of v){
								if(siteObj[source]){ 
									agencyObj[sitegroup][source]++
								}
							}
						}
					}
					return agencyObj
				})					
				.entries(data.siteData)			

		// 15. PARSE THE GREENPOWER DATA AND CREATE AGENCY LEVEL GRID FACTORS
			data.greenPowerData.forEach(d => { 
				d.greenPowerProp = parseFloat(d.greenPowerProp)
				dataModel.schema.agencyGreenPowerMap[d.agency] =  { 
					proportion 	: parseFloat(d.greenPowerProp),
					description :  d.description
				}
			})
			const gridElecAgencies = [...new Set(data.siteConsumptionBySource['Grid electricity'].map(d => Object.values(d)[0].ag))].sort()
			for( const agency of gridElecAgencies){
				const gridEF = model.parameters.emissionFactors.EF_GridFactorNSW_CO2_per_MWH,
					agencyGreenPower = typeof(dataModel.schema.agencyGreenPowerMap[agency]) !== 'undefined' ? dataModel.schema.agencyGreenPowerMap[agency] : null
					model.parameters.emissionFactors.agencyGridEF[agency] = {
						description: 		agencyGreenPower ? agencyGreenPower.description : gridEF.description,
						name: 				gridEF.name,
						sector: 			gridEF.sector,
						source: 			gridEF.source,
						unit: 				gridEF.unit,
						userEditable: 		false,
						scope1: 			gridEF.scope1,
						scope2: 			gridEF.scope2.map(d => d * (agencyGreenPower ? (1 - agencyGreenPower.proportion) : 1)),
						scope3: 			gridEF.scope3.map(d => d * (agencyGreenPower ? (1 - agencyGreenPower.proportion) : 1))
					}
					settings.parameters.emissionFactors.agencyGridEF[agency] = {
						description: 		agencyGreenPower ? agencyGreenPower.description : gridEF.description,
						name: 				gridEF.name,
						sector: 			gridEF.sector,
						source: 			gridEF.source,
						unit: 				gridEF.unit,
						userEditable: 		false,
						scope1: 			gridEF.scope1,
						scope2: 			gridEF.scope2.map(d => d * (agencyGreenPower ? (1 - agencyGreenPower.proportion) : 1)),
						scope3: 			gridEF.scope3.map(d => d * (agencyGreenPower ? (1 - agencyGreenPower.proportion) : 1))
					}
			}

		// 17. EXTRACT TEXT CONTENT DATA
			data.content.forEach(contentObj => {
				if(typeof content[contentObj.type] !== 'undefined'){
					content[contentObj.type][contentObj.id] = contentObj.content
				}
			})
			data.contentAbout.forEach(contentObj => {
				content.about.push({
					section: 	contentObj.section,
					id: 		contentObj.id,
					content: 	contentObj.content,
					type: 		contentObj.type
				})				
			})			

		console.log('...Data parsed!')
	}; // end parseData


////////////////////////////////////////
// 2. BUIlD EMISSIONS REFERENCE CASE  //
////////////////////////////////////////

	// PART A. Build the reference case: called on load and when there are changes in the global settings that require a reference case re-calc (e.g. grid factor)
	async function buildReferenceCase(typologyFilter = true){
		console.log('*** 2A. BUILDING REFERENCE CASE FOR MODELLED SECTORS & SOURCE AT SITE LEVEL (AND FOR ALL OF AGENCY DATA) ***')

		// 1. BUILD REFERENCE CASE EMISSIONS PROFILE
			const baselineYear =  dataModel.schema.baselineYear,
	 			grepSolarData = data.grepProjects.filter(d => d.type == 'Solar Photovoltaics (PV)' && d.baseImpact > 0)

			Object.keys(dataModel.schema.inventory).forEach( sector => {
				model.inventory.referenceCase.bySite[sector] = {}
				switch(sector){
					// Note: dataModel.schema.consumption.sectors is an alphabetically sorted array. Adding new sectors will likely mean that these indexes would require review
					case dataModel.schema.consumption.sectors[0]: 	// "Stationary energy":
						console.log('...Building the '+sector+' reference case:')						
						Object.keys(dataModel.schema.inventory[sector]).forEach( source => {	
								model.inventory.referenceCase.bySite[sector][source] = {}								
							// A. Get contracts database source unit and datasets
							const unit = dataModel.schema.inventory[sector][source].unit,	
							 	electricityData 	= data.siteConsumptionBySource["Grid electricity"], 
								mainsGasData 		= data.siteConsumptionBySource["Natural gas (reticulated)"],
								bottledLpgData   	= data.siteConsumptionBySource["Natural gas (bottled LPG)"],
								evChargingData 		= data.agencyConsumption.filter(d => d.source === 'EV charging stations')

							switch(source.toLowerCase()){
								// CASES OF SITE-LEVEL LEVEL 
								case "grid electricity":
                                    if(!electricityData) break
									electricityData.forEach( siteDataObj => {	
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											emissionFactorObj 		= settings.parameters.emissionFactors.agencyGridEF[siteData.ag] ,
											unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											tariffMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal['eletricityPricePath'].values[year])

										// Only create object where consumption unit is valid								
										if(typeof dataModel.schema.unitConversion[unit][siteData.unit] !== 'undefined'){		
											// i. Add to referenceCase									
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => d *siteData.vol * unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope1[i] * unitConversionFactor),
												Scope2: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope2[i] * unitConversionFactor),
												Scope3: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope3[i] * unitConversionFactor),
												Total:  	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]) )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
												Total:  	Array(dataModel.schema.modelHorizon).fill(0)																						
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
											model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= activityMultiplier.map((d, i) => d * siteData.cost * tariffMultiplier[i])
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "MWh"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per MWh"									
										}							
									})
									console.log('.....'+source+" added")
									break

								case "natural gas (reticulated)":
                                    if(!mainsGasData) break
									mainsGasData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											emissionFactorObj 		= model.parameters.emissionFactors.EF_PipedGas_CO2_per_GJ,
											unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],											
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal[activityMultiplierName].values[year]),
											tariffMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal['naturalGasPricePath'].values[year])

										// Only create object where consumption unit is valid								
										if(typeof dataModel.schema.unitConversion[unit][siteData.unit] !== 'undefined'){	
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => d *siteData.vol * unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope1[i] * unitConversionFactor ),
												Scope2: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope2[i] * unitConversionFactor ),
												Scope3: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope3[i] * unitConversionFactor ),
												Total:  	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]))
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	activityMultiplier.map(d =>  0 ),
												Scope2: 	activityMultiplier.map(d =>  0 ),
												Scope3: 	activityMultiplier.map(d =>  0 ),
												Total:  	activityMultiplier.map(d =>  0 )											
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
											model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= activityMultiplier.map((d, i) => d * siteData.cost * tariffMultiplier[i])
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "GJ"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per GJ"
										}							
									})
									console.log('.....'+source+" added")								

									break

								case "natural gas (bottled lpg)":	
                                    if(!bottledLpgData) break
									bottledLpgData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											emissionFactorObj 		= model.parameters.emissionFactors.EF_LPG_bottled_tCO2_per_kL,
											unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],												
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal[activityMultiplierName].values[year]),
											tariffMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal['bottledLpgPricePath'].values[year])


										// Only create object where consumption unit is valid								
										if(typeof dataModel.schema.unitConversion[unit][siteData.unit] !== 'undefined'){	
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => d *siteData.vol * unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope1[i] * unitConversionFactor),
												Scope2: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope2[i] * unitConversionFactor),
												Scope3: 	activityMultiplier.map((d, i) => d * siteData.vol * emissionFactorObj.scope3[i] * unitConversionFactor),
												Total:  	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]) )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	activityMultiplier.map(d =>  0 ),
												Scope2: 	activityMultiplier.map(d =>  0 ),
												Scope3: 	activityMultiplier.map(d =>  0 ),
												Total:  	activityMultiplier.map(d =>  0 )											
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
											model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= activityMultiplier.map((d, i) => d * siteData.cost * tariffMultiplier[i])
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 	= "$ per kL"
										}									
									})
									console.log('.....'+source+" added")	
									break

								case "ev charging stations":
                                    if(!evChargingData) break
									evChargingData.forEach( agencyObj => {	 // Includes grid and renewable sourced charging stations
										const emissionFactorObj 	= agencyObj.type !== 'Renewable electricity' ? model.parameters.emissionFactors.EF_GridFactorNSW_CO2_per_MWH : model.parameters.emissionFactors.EF_Zero_Emissions,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]),
											siteID					= 'All EV charging stations using '+agencyObj.type+' for '+agencyObj.agencyName					
											// i. Add to referenceCase									
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = volumeArray
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope1[i] ),
												Scope2: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope2[i] ),
												Scope3: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope3[i] ),
												Total:  	activityMultiplier.map((d, i) => d * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]) )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
												Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= []
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= dataModel.schema.modelYears.map((d, i) => agencyObj.volume * priceArray[i] )
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "MWh"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per MWh"									
									})
									console.log('.....'+source+" added")
									break

								// Additional  stationary energy sources calculated from electricity and existing projects
								case "solar consumed":
                                    if(!electricityData) break
									// Reference case setup at site level compared to GREP data
									electricityData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											unitConversionFactor = dataModel.schema.unitConversion[unit][siteData.unit],											
											activityMultiplier 	 = dataModel.schema.modelYears.map(year => model.parameters.temporal.growthFlat.values[year]),
											tariffMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal['eletricityPricePath'].values[year])

										// ADD IF THERE IS GREP SOLAR DATA MATCHED TO AGENCY AND SITE ID 
										grepSolarData.forEach(grepObj => {
											if(grepObj.agency ===  siteData["Agency name"] && grepObj.siteId ===  siteData["Site Id"] ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map((d, i) => grepObj.eleckWh/ 1000)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	activityMultiplier.map(d =>  0 ),
													Scope2: 	activityMultiplier.map(d =>  0 ),
													Scope3: 	activityMultiplier.map(d =>  0 ),
													Total:  	activityMultiplier.map(d =>  0 )
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsReduction'] =  {
													Scope1: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.eleckWh / 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope1[i] ),
													Scope2: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.eleckWh / 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope2[i] ),
													Scope3: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.eleckWh/ 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope3[i] ),
													Total:  	dataModel.schema.modelYears.map((d,i) =>  grepObj.eleckWh/ 1000 * (settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope3[i] )	)								
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsSinks'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)								
												}

												model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
												model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
												model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
												model.inventory.referenceCase.bySite[sector][source][siteID]["valueOfEnergy"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)		
												model.inventory.referenceCase.bySite[sector][source][siteID]["cost"] 			= Array(dataModel.schema.modelHorizon).fill(0)
												model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
												model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per MWh"
											}
										})
									})	
									// Switch falls through to solar exported
									break

								case "solar exported":
                                    if(!electricityData) break
									// Reference case setup at site level compared to GREP data
									electricityData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											unitConversionFactor = dataModel.schema.unitConversion[unit][siteData.unit],											
											activityMultiplier 	 = dataModel.schema.modelYears.map(year => model.parameters.temporal.growthFlat.values[year])

										// ADD IF THERE IS GREP SOLAR DATA MATCHED TO AGENCY AND SITE ID 
										grepSolarData.forEach(grepObj => {
											if(grepObj.agency ===  siteData["Agency name"] && grepObj.siteId ===  siteData["Site Id"] ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map((d, i) => grepObj.solarExportkWh / 1000)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	activityMultiplier.map(d =>  0 ),
													Scope2: 	activityMultiplier.map(d =>  0 ),
													Scope3: 	activityMultiplier.map(d =>  0 ),
													Total:  	activityMultiplier.map(d =>  0 )
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsSinks'] =  {
													Scope1: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.solarExportkWh / 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope1[i] ),
													Scope2: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.solarExportkWh / 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope2[i] ),
													Scope3: 	dataModel.schema.modelYears.map((d,i) =>  grepObj.solarExportkWh / 1000 * settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope3[i] ),
													Total:  	dataModel.schema.modelYears.map((d,i) =>  grepObj.solarExportkWh / 1000 * (settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[siteData.ag].scope3[i] )	)								
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
												model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
												model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
												model.inventory.referenceCase.bySite[sector][source][siteID]["valueOfEnergy"] 	= settings.parameters.general.price_SolarFeedIn.value
												model.inventory.referenceCase.bySite[sector][source][siteID]["cost"] 			= Array(dataModel.schema.modelHorizon).fill(0)
												model.inventory.referenceCase.bySite[sector][source][siteID]["tariffAvoided"] 	= Array(dataModel.schema.modelHorizon).fill(0)
												model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "MWh"
												model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per MWh"
											}
										})
									})						
									console.log('.....'+source+" added")
									break

								case "power purchase agreement":
                                    if(!electricityData) break
									// Reference case setup at site level 	
									electricityData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],											
											activityMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal.growthFlat.values[year])

										model.inventory.referenceCase.bySite[sector][source][siteID] = {}
										model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => 0)
										model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
											Scope1: 	activityMultiplier.map(d =>  0 ),
											Scope2: 	activityMultiplier.map(d =>  0 ),
											Scope3: 	activityMultiplier.map(d =>  0 ),
											Total:  	activityMultiplier.map(d =>  0 )
										}
										model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsReduction'] =  {
											Scope1: 	activityMultiplier.map(d =>  0 ),
											Scope2: 	activityMultiplier.map(d =>  0 ),
											Scope3: 	activityMultiplier.map(d =>  0 ),
											Total:  	activityMultiplier.map(d =>  0 )											
										}
										model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
										model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
										model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
										model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
										model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
										model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
										model.inventory.referenceCase.bySite[sector][source][siteID]["cost"] 			= Array(dataModel.schema.modelHorizon).fill(0)
										model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= Array(dataModel.schema.modelHorizon).fill(0)
										model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "MWh"
										model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per MWh"
									})
									console.log('.....'+source+" added")
									break
							}
						})
						break

					case dataModel.schema.consumption.sectors[1]: 	// "Supply chain":
						console.log('...Building the '+sector+' reference case:')
						Object.keys(dataModel.schema.inventory[sector]).forEach(source => {
							model.inventory.referenceCase.bySite[sector][source] = {}		
							// Get source unit and datasets
							const unit = dataModel.schema.inventory[sector][source].unit,
								waterData = data.siteConsumptionBySource["Water supply (reticulated)"],
								paperData = data.agencyConsumption.filter(d => d.source === 'Paper supply'),
								paperCarbonNeutralData = data.agencyConsumption.filter(d => d.source === 'Paper supply (carbon neutral)'),
								accommodationDomesticData = data.agencyConsumption.filter(d => d.source === 'Accommodation (domestic)'),
								accommodationInternationalData = data.agencyConsumption.filter(d => d.source === 'Accommodation (international)')

							switch(source.toLowerCase()){ 
								case "water supply (reticulated)":	
                                    if(!waterData) break
									waterData.forEach(siteDataObj => {
										const siteID = Object.keys(siteDataObj)[0],
											siteData = Object.values(siteDataObj)[0],
											emissionFactorObj 		= model.parameters.emissionFactors.EF_WaterSupply_tCO2_per_ML,
											unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal[activityMultiplierName].values[year]),
											tariffMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal['waterPricePath'].values[year])
										// Only create object for defined unit								
										if(typeof dataModel.schema.unitConversion[unit][siteData.unit] !== 'undefined'){												
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor )
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope1[i] / 1000),
												Scope2: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope2[i] / 1000),
												Scope3: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope3[i] / 1000),
												Total:  	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]) / 1000 )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsReduction'] =  {
												Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
												Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
											model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= activityMultiplier.map((d, i) => d * siteData.cost * tariffMultiplier[i])
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"
										}
									})
									console.log('.....'+source+" added")										
									break

								//  AGENCY LEVEL  SUPPLY CHAIN
								case "paper supply":
                                    if(!paperData) break
									paperData.forEach( agencyObj => {	
										const emissionFactorObj 	= agencyObj.type !== 'Carbon neutral' ? model.parameters.emissionFactors.EF_PaperAve_tCO2_per_tonne : model.parameters.emissionFactors.EF_Zero_Emissions ,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID 					= 'All sites for '+agencyObj.agencyName			
								
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each item to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}

											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonne"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)


									})
									console.log('.....'+source+" added")
									break

								case "accommodation (domestic)":
									accommodationDomesticData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_AccomDomestic_tCO2_per_night,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID 					= 'All sites for '+agencyObj.agencyName					
											// i. Add to referenceCase									
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = volumeArray
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope1[i] ),
												Scope2: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope2[i] ),
												Scope3: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope3[i] ),
												Total:  	activityMultiplier.map((d, i) => d * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]) )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
												Total:  	Array(dataModel.schema.modelHorizon).fill(0)																					
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= []
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= dataModel.schema.modelYears.map((d, i) => agencyObj.volume * priceArray[i] )
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "night stays"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per night"		
									})
									console.log('.....'+source+" added")
									break	

								case "accommodation (international)":
									accommodationInternationalData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_AccomInternational_tCO2_per_night,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName					
											// i. Add to referenceCase									
											model.inventory.referenceCase.bySite[sector][source][siteID] = {}
											model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = volumeArray
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
												Scope1: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope1[i] ),
												Scope2: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope2[i] ),
												Scope3: 	activityMultiplier.map((d, i) => d * agencyObj.volume * emissionFactorObj.scope3[i] ),
												Total:  	activityMultiplier.map((d, i) => d * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] +emissionFactorObj.scope3[i]) )
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
												Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
												Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
												Total:  	Array(dataModel.schema.modelHorizon).fill(0)																				
											}										
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= []
											model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= dataModel.schema.modelYears.map((d, i) => agencyObj.volume * priceArray[i] )
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "night stays"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per night"									
									})
									console.log('.....'+source+" added")
									break
							}
						})
						break

					case dataModel.schema.consumption.sectors[2]:	// "Transport": 	
						console.log('...Building the '+sector+' reference case:')		
						Object.keys(dataModel.schema.inventory[sector]).forEach(source => {
							model.inventory.referenceCase.bySite[sector][source] = {}		
							// Get source unit and datasets
							const unit = dataModel.schema.inventory[sector][source].unit,
								fleetPetrolData = data.agencyConsumption.filter(d => d.source === 'Petrol'),
								fleetDieselData = data.agencyConsumption.filter(d => d.source === 'Diesel (transport)'),
								fleetLPGData = data.agencyConsumption.filter(d => d.source === 'LPG (transport)'),
								fleetLNGData = data.agencyConsumption.filter(d => d.source === 'LNG (transport)'),
								fleetCNGData = data.agencyConsumption.filter(d => d.source === 'CNG (transport)'),
								fleetB20Data = data.agencyConsumption.filter(d => d.source === 'Biodiesel (B20)'),
								fleetE85Data = data.agencyConsumption.filter(d => d.source === 'Ethanol (e85)'),
								airTravelShortData = data.agencyConsumption.filter(d => d.source === 'Air travel (short haul)'),
								airTravelMedData = data.agencyConsumption.filter(d => d.source === 'Air travel (medium haul)'),
								airTravelLongData = data.agencyConsumption.filter(d => d.source === 'Air travel (long haul)')

							switch(source.toLowerCase()){ 
								//  AGENCY LEVEL SCOPE 3 WITH MULTIPLE CATEGORISATION
								case "petrol":
									fleetPetrolData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_Gasoline_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID 					= 'All sites for '+agencyObj.agencyName		

											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each item to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}

											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break

								case "diesel (transport)":
									fleetDieselData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_Diesel_transport_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  	= {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break

								case "lpg (transport)":
									fleetLPGData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_LPG_transport_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)										
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)

									})
									console.log('.....'+source+" added")
									break

								case "lng (transport)":
									fleetLNGData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_LNGHeavyTransport_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)										
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)

									})
									console.log('.....'+source+" added")
									break

								case "cng (transport)":
									fleetCNGData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_CNGHeavyTransport_tCO2_per_tonne,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)										
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)

									})
									console.log('.....'+source+" added")
									break

								case "biodiesel (b20)":
									fleetB20Data.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_B20_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break

								case "ethanol (e85)":
									fleetE85Data.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_E85_tCO2_per_kL,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)										
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "kL"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per kL"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break

								//  AGENCY LEVEL SCOPE 3 WITH NO CATEGORISATION								
								case "air travel (short haul)":
									airTravelShortData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_FlightsShortHaul_tCO2_per_km,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID 					= 'All sites for '+agencyObj.agencyName		
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each item to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}

											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "km"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per km"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break

								case "air travel (medium haul)":
									airTravelMedData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_FlightsMediumHaul_tCO2_per_km,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	
											// ii. Add each item to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "km"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per km"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)

									})
									console.log('.....'+source+" added")
									break

								case "air travel (long haul)":
									airTravelLongData.forEach( agencyObj => {	
										const emissionFactorObj 	= model.parameters.emissionFactors.EF_FlightsLongHaul_tCO2_per_km,
											activityMultiplierName 	= 'defaultActivityGrowth',
											activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
											costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
											volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
											priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
											siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)	
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	
											// ii. Add each item to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + volumeArray[i])
											obj.cost 		 = obj.cost.map((d, i) => d + costArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "km"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per km"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
									})
									console.log('.....'+source+" added")
									break
							}
						})
						break

					case dataModel.schema.consumption.sectors[3]: 	// "Waste":
						console.log('...Building the '+sector+' reference case...')
						Object.keys(dataModel.schema.inventory[sector]).forEach(source => {
							const wasteDataSource = 'agencyConsumption'
							model.inventory.referenceCase.bySite[sector][source] = {}		
							// Get source unit and datasets from agencyConsumption Google Sheet
							if(wasteDataSource === 'agencyConsumption'){

								const unit = dataModel.schema.inventory[sector][source].unit,
									ciWasteData = data.agencyConsumption.filter(d => d.source === 'Commercial and industrial waste'),
									organicWasteData = data.agencyConsumption.filter(d => d.source === 'Organic waste'),
									recycledWasteData = data.agencyConsumption.filter(d => d.source === 'Recycled waste'),
									clinicalWasteData = data.agencyConsumption.filter(d => d.source === 'Clinical waste')

								switch(source.toLowerCase()){ 
									//  AGENCY LEVEL SCOPE 3 WITH MULTIPLE CATEGORISATION
									case "commercial and industrial waste":
										ciWasteData.forEach( agencyObj => {	
											const emissionFactorObj 	= model.parameters.emissionFactors.EF_Waste_CI_tCO2_per_t,
												activityMultiplierName 	= 'defaultActivityGrowth',
												activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
												costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
												volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
												priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
												siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											

												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + activityMultiplier[i] * agencyObj.volume)
											obj.cost = obj.cost.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * priceArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonne"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
										})
										console.log('.....'+source+" added")
										break

									case "organic waste":
										organicWasteData.forEach( agencyObj => {	
											const emissionFactorObj 	= model.parameters.emissionFactors.EF_Waste_Organic_tCO2_per_t,
												activityMultiplierName 	= 'defaultActivityGrowth',
												activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
												costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
												volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
												priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
												siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											

												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + activityMultiplier[i] * agencyObj.volume)
											obj.cost = obj.cost.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * priceArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonne"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
										})
										console.log('.....'+source+" added")
										break

									case "recycled waste":
										recycledWasteData.forEach( agencyObj => {	
											const emissionFactorObj 	= model.parameters.emissionFactors.EF_Waste_Recycled_tCO2_per_t,
												activityMultiplierName 	= 'defaultActivityGrowth',
												activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
												costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
												volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
												priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
												siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											

												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + activityMultiplier[i] * agencyObj.volume)
											obj.cost = obj.cost.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * priceArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonne"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
										})
										console.log('.....'+source+" added")
										break

									case "clinical waste":
										clinicalWasteData.forEach( agencyObj => {	
											const emissionFactorObj 	= model.parameters.emissionFactors.EF_Waste_Clinical_tCO2_per_t,
												activityMultiplierName 	= 'defaultActivityGrowth',
												activityMultiplier 		= dataModel.schema.modelYears.map( year => model.parameters.temporal[activityMultiplierName].values[year]),
												costArray 				= activityMultiplier.map((d,i) => d * agencyObj.cost ),
												volumeArray 			= activityMultiplier.map((d,i) => d * agencyObj.volume ),
												priceArray 				= costArray.map( (d, i) => volumeArray[i] === 0 ?  0 : d / volumeArray[i]) ,
												siteID = 'All sites for '+agencyObj.agencyName			
											// i. Initiate referenceCase to zero 
											if(typeof model.inventory.referenceCase.bySite[sector][source][siteID] === 'undefined' ){
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['cost'] = dataModel.schema.modelYears.map(d => 0)
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											

												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionAbatement'] =  {
													Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
													Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
													Total:  	Array(dataModel.schema.modelHorizon).fill(0)											
												}	
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"] = []
											}	

											// ii. Add each agency to referenceCase			
											const obj = model.inventory.referenceCase.bySite[sector][source][siteID]
											obj.naturalVolume = obj.naturalVolume.map((d, i) => d + activityMultiplier[i] * agencyObj.volume)
											obj.cost = obj.cost.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * priceArray[i])
											obj.emissions  = {
												Scope1: 	obj.emissions.Scope1.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope1[i]),
												Scope2: 	obj.emissions.Scope2.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope2[i]),
												Scope3: 	obj.emissions.Scope3.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * emissionFactorObj.scope3[i]),
												Total: 		obj.emissions.Total.map((d, i) => d + activityMultiplier[i] * agencyObj.volume * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]))
											}
									
											model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= agencyObj.cluster
											model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= agencyObj.agencyName
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= 'All of agency'
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= 'All site types'
											model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= priceArray
											model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonne"
											model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"									
											model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"].push(agencyObj.type)
										})
										console.log('.....'+source+" added")
										break

								}

							//  OR Get source unit and datasets from CASPER
							} else if 	(wasteDataSource === 'CASPER'){

								const unit = dataModel.schema.inventory[sector][source].unit,
									ciWasteData  = data.siteConsumptionBySource["Commercial and industrial waste"],
									clinicalWasteData  = data.siteConsumptionBySource["Clinical waste"]

								switch(source.toLowerCase()){ 
									case "commercial and industrial waste":
										ciWasteData.forEach(siteDataObj => {									
											const siteID = Object.keys(siteDataObj)[0],
												siteData = Object.values(siteDataObj)[0],
												emissionFactorObj 		= model.parameters.emissionFactors.EF_Waste_CI_tCO2_per_t,
												unitConversionFactor	= dataModel.schema.unitConversion[unit][siteData.unit],
												activityMultiplierName 	= 'defaultActivityGrowth',
												activityMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal[activityMultiplierName].values[year]),
												tariffMultiplier 		= dataModel.schema.modelYears.map(year => model.parameters.temporal['wasteDisposalPricePath'].values[year])

											// Only create object for defined unit								
											if(typeof dataModel.schema.unitConversion[unit][siteData.unit] !== 'undefined'){													
												model.inventory.referenceCase.bySite[sector][source][siteID] = {}
												model.inventory.referenceCase.bySite[sector][source][siteID]['naturalVolume'] = activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor )
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissions'] = {
													Scope1: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope1[i] ),
													Scope2: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope2[i] ),
													Scope3: 	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * emissionFactorObj.scope3[i] ),
													Total:  	activityMultiplier.map((d, i) => d * siteData.vol * unitConversionFactor * (emissionFactorObj.scope1[i] + emissionFactorObj.scope2[i] + emissionFactorObj.scope3[i]) )
												}
												model.inventory.referenceCase.bySite[sector][source][siteID]['emissionsReduction'] =  {
													Scope1: 	activityMultiplier.map(d =>  0 ),
													Scope2: 	activityMultiplier.map(d =>  0 ),
													Scope3: 	activityMultiplier.map(d =>  0 ),
													Total:  	activityMultiplier.map(d =>  0 )											
												}

												model.inventory.referenceCase.bySite[sector][source][siteID]["cluster"] 		= siteData.cluster
												model.inventory.referenceCase.bySite[sector][source][siteID]["agency"] 			= siteData.ag
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitegroup"] 		= siteData.sitegroup
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitetype"]  		= siteData.type
												model.inventory.referenceCase.bySite[sector][source][siteID]["sitenames"]  		= siteData.names
												model.inventory.referenceCase.bySite[sector][source][siteID]["postcode"]  		= siteData.pc
												model.inventory.referenceCase.bySite[sector][source][siteID]["cost"]  			= activityMultiplier.map((d, i) => d * siteData.cost * tariffMultiplier[i])
												model.inventory.referenceCase.bySite[sector][source][siteID]["modelledTariff"] 	= tariffMultiplier.map((d, i) =>  d * (siteData.cost / siteData.vol ) / unitConversionFactor)
												model.inventory.referenceCase.bySite[sector][source][siteID]["naturalUnit"] 	= "tonnes"
												model.inventory.referenceCase.bySite[sector][source][siteID]["tariffUnit"] 		= "$ per tonne"
											}					
										})
										console.log('.....'+source+" added")									
										break

									case "clinical waste":
										console.log(clinicalWasteData)
										console.log(".....no "+source+" included")							
										break 	

									case "construction and demolition waste":
										console.log(".....no "+source+" included")							
										break 	

									case "municipal Waste":	
										console.log(".....no "+source+" included")	
										break 	
								}
							}
						})
						break
				}
			})

		// 2. SUMMARISE BY TOTAL EMISSIONS AND BY SECTOR AND SOURCE 	
			model.inventory.referenceCase.summaryTotal = {
				emissions: { 
					Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
					Total: 			Array(dataModel.schema.modelHorizon).fill(0)
				},
				emissionsReduction: { 
					Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
					Total: 			Array(dataModel.schema.modelHorizon).fill(0)
				},
				emissionsSinks: { 
					Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
					Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
					Total: 			Array(dataModel.schema.modelHorizon).fill(0)
				},						
				cost: 				Array(dataModel.schema.modelHorizon).fill(0)			
			}		

			Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {
				model.inventory.referenceCase.bySectorSource[sector] = {}
				Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {
					model.inventory.referenceCase.bySectorSource[sector][source] = {
						naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
						cost: 				Array(dataModel.schema.modelHorizon).fill(0),				
						emissions: {
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsReduction: {
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsSinks: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},						
						noSites: 		0					
					}

					Object.keys(model.inventory.referenceCase.bySite[sector][source]).forEach( siteID => {
						const siteObj = model.inventory.referenceCase.bySite[sector][source][siteID]
						// Add to bySectorSource
						model.inventory.referenceCase.bySectorSource[sector][source].naturalVolume 		= model.inventory.referenceCase.bySectorSource[sector][source].naturalVolume.map((d,i) => d + siteObj.naturalVolume[i])
						model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope1 	= model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope1.map((d,i) => d + siteObj.emissions.Scope1[i])
						model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope2 	= model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope2.map((d,i) => d + siteObj.emissions.Scope2[i])
						model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope3 	= model.inventory.referenceCase.bySectorSource[sector][source].emissions.Scope3.map((d,i) => d + siteObj.emissions.Scope3[i])
						model.inventory.referenceCase.bySectorSource[sector][source].emissions.Total	= model.inventory.referenceCase.bySectorSource[sector][source].emissions.Total.map((d,i) => d + siteObj.emissions.Total[i])
						model.inventory.referenceCase.bySectorSource[sector][source].cost				= model.inventory.referenceCase.bySectorSource[sector][source].cost.map((d,i) => d + siteObj.cost[i])

						// Add to total emissions and cost
						model.inventory.referenceCase.summaryTotal.emissions.Scope1 = model.inventory.referenceCase.summaryTotal.emissions.Scope1.map((d,i) => d + siteObj.emissions.Scope1[i])
						model.inventory.referenceCase.summaryTotal.emissions.Scope2 = model.inventory.referenceCase.summaryTotal.emissions.Scope2.map((d,i) => d + siteObj.emissions.Scope2[i])
						model.inventory.referenceCase.summaryTotal.emissions.Scope3 = model.inventory.referenceCase.summaryTotal.emissions.Scope3.map((d,i) => d + siteObj.emissions.Scope3[i])
						model.inventory.referenceCase.summaryTotal.emissions.Total 	= model.inventory.referenceCase.summaryTotal.emissions.Total.map((d,i) => d + siteObj.emissions.Total[i])
						model.inventory.referenceCase.summaryTotal.cost 			= model.inventory.referenceCase.summaryTotal.cost.map((d,i) => d + siteObj.cost[i])

						// Add to bySectorSource and summaryTotal for defined reduction and sinks
						if(typeof siteObj.emissionsReduction !== 'undefined'){
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope1 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope1.map((d,i) => d + siteObj.emissionsReduction.Scope1[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope2 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope2.map((d,i) => d + siteObj.emissionsReduction.Scope2[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope3 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Scope3.map((d,i) => d + siteObj.emissionsReduction.Scope3[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Total	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsReduction.Total.map((d,i) => d + siteObj.emissionsReduction.Total[i])
		
							model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope1 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope1.map((d,i) => d + siteObj.emissionsReduction.Scope1[i])
							model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope2 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope2.map((d,i) => d + siteObj.emissionsReduction.Scope2[i])
							model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope3 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope3.map((d,i) => d + siteObj.emissionsReduction.Scope3[i])
							model.inventory.referenceCase.summaryTotal.emissionsReduction.Total  = model.inventory.referenceCase.summaryTotal.emissionsReduction.Total.map((d,i) => d + siteObj.emissionsReduction.Total[i])
						}
						if(typeof siteObj.emissionsSinks !== 'undefined'){
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope1 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope1.map((d,i) => d + siteObj.emissionsSinks.Scope1[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope2 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope2.map((d,i) => d + siteObj.emissionsSinks.Scope2[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope3 	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Scope3.map((d,i) => d + siteObj.emissionsSinks.Scope3[i])
							model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Total	= model.inventory.referenceCase.bySectorSource[sector][source].emissionsSinks.Total.map((d,i) => d + siteObj.emissionsSinks.Total[i])

							model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope1 	= model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope1.map((d,i) => d + siteObj.emissionsSinks.Scope1[i])
							model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope2 	= model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope2.map((d,i) => d + siteObj.emissionsSinks.Scope2[i])
							model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope3 	= model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope3.map((d,i) => d + siteObj.emissionsSinks.Scope3[i])
							model.inventory.referenceCase.summaryTotal.emissionsSinks.Total 	= model.inventory.referenceCase.summaryTotal.emissionsSinks.Total.map((d,i) => d + siteObj.emissionsSinks.Total[i])
						}
					})
					// Add meta info
					model.inventory.referenceCase.bySectorSource[sector][source].modelledTariff		= d3.sum(model.inventory.referenceCase.bySectorSource[sector][source].naturalVolume) > 0 ? model.inventory.referenceCase.bySectorSource[sector][source].cost.map((d,i) => d / model.inventory.referenceCase.bySectorSource[sector][source].naturalVolume[i]  ) : model.inventory.referenceCase.bySectorSource[sector][source].cost.map(d => 0) 
					model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit			= '$ per '+dataModel.schema.inventory[sector][source].unit
					model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit		= dataModel.schema.inventory[sector][source].unit
					model.inventory.referenceCase.bySectorSource[sector][source].noSites++
				})
			})

		// 3. SITES ROLLED UP BY SITEGROUP > FOR APPLYING ACTIONS ACROSS ALL AGENCIES 
			Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {
				model.inventory.referenceCase.bySitegroup[sector] = {}
				Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {
					model.inventory.referenceCase.bySitegroup[sector][source] = {}	

					dataModel.schema.consumption.sitegroups.forEach( (sitegroup, i) => {					
						sitegroupSourceData = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter(d => d.sitegroup === sitegroup)
						if(sitegroupSourceData.length > 0){			
							const naturalVolume = typeof [...new Set(sitegroupSourceData.map(d => d.naturalVolume))][0] !== 'undefined' ? [...new Set(sitegroupSourceData.map(d => d.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								cost = typeof [...new Set(sitegroupSourceData.map(d => d.cost) )][0] !== 'undefined' ? [...new Set(sitegroupSourceData.map(d => d.cost) )].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								modelledTariff  = naturalVolume.length > 0 && cost.length > 0 && d3.sum(naturalVolume) > 0 ? cost.map((d, i) => d / naturalVolume[i]) : cost.map(d => 0)

							model.inventory.referenceCase.bySitegroup[sector][source][sitegroup] = {
								siteNames: 				[...new Set(sitegroupSourceData.map(d => d.sitenames.join(", ")) )],
								refIds: 				[...new Set(sitegroupSourceData.map(d => d.id) )],
								naturalVolume: 			naturalVolume ,
								naturalUnit: 			dataModel.schema.inventory[sector][source].unit,										
								emissions: 	{
									Scope1: 			[...new Set(sitegroupSourceData.map(d => d.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope2: 			[...new Set(sitegroupSourceData.map(d => d.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope3: 			[...new Set(sitegroupSourceData.map(d => d.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Total: 				[...new Set(sitegroupSourceData.map(d => d.emissions.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
								},	
								emissionsReduction: {
									Scope1: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope2: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope2 : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope3: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope3 : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Total: 		 		[...new Set(sitegroupSourceData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Total  : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
								},	
								emissionsSinks: {
									Scope1: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope1 : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope2: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope2 : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope3: 			[...new Set(sitegroupSourceData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope3 : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Total: 		 		[...new Set(sitegroupSourceData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Total  : Array(dataModel.schema.modelHorizon).fill(0)))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
								},	
								cost: 					cost ,
								modelledTariff: 		modelledTariff,
								tariffUnit: 			'$ per '+dataModel.schema.inventory[sector][source].unit
							}	
						}
					})	

					/// ADD AN AGENCY-LEVEL SITEGROUP DATA FROM EXTERNAL AGENCY CONSUMPTION DATA
					if(dataModel.schema.consumption.agencyLevelSources.indexOf(source) > -1){ 		// For sources and sectors where there is agency level data + Grid electricity (for electrification switch)
						// a. Initialise object
						model.inventory.referenceCase.bySitegroup[sector][source]['All of agency'] = {
							siteNames: 				['All sites'],
							refIds: 				null,
							naturalVolume: 			dataModel.schema.modelYears.map(d => 0),
							naturalUnit: 			dataModel.schema.inventory[sector][source].unit,										
							emissions: 	{
								Scope1: 			dataModel.schema.modelYears.map(d => 0),
								Scope2: 			dataModel.schema.modelYears.map(d => 0),
								Scope3: 			dataModel.schema.modelYears.map(d => 0),
								Total: 				dataModel.schema.modelYears.map(d => 0)
							},	
							emissionsReduction: {
								Scope1: 			dataModel.schema.modelYears.map(d => 0),
								Scope2: 			dataModel.schema.modelYears.map(d => 0),
								Scope3: 			dataModel.schema.modelYears.map(d => 0),
								Total: 				dataModel.schema.modelYears.map(d => 0)
							},	
							emissionsSinks: {
								Scope1: 			dataModel.schema.modelYears.map(d => 0),
								Scope2: 			dataModel.schema.modelYears.map(d => 0),
								Scope3: 			dataModel.schema.modelYears.map(d => 0),
								Total: 				dataModel.schema.modelYears.map(d => 0)
							},	

							cost: 					dataModel.schema.modelYears.map(d => 0) ,
							tariffUnit: 			'$ per '+dataModel.schema.inventory[sector][source].unit
						}	

						// b. Add each agencies emissions and consumption volumes 
						const agencyLevelData = model.inventory.referenceCase.bySite[sector][source],
						 	obj = model.inventory.referenceCase.bySitegroup[sector][source]['All of agency'] 
						Object.entries(agencyLevelData).forEach(([agency, agencyData]) => {
							obj.cost = obj.cost	.map((d, i) => d + agencyData.cost[i] )
							obj.naturalVolume = obj.naturalVolume.map((d, i) => d + agencyData.naturalVolume[i] )
							obj.emissions = {
								Scope1:	obj.emissions.Scope1.map((d, i) => d + agencyData.emissions.Scope1[i] ),
								Scope2:	obj.emissions.Scope2.map((d, i) => d + agencyData.emissions.Scope2[i] ),
								Scope3:	obj.emissions.Scope3.map((d, i) => d + agencyData.emissions.Scope3[i] ),
								Total:	obj.emissions.Total.map((d, i) => d + agencyData.emissions.Total[i] ),
							}
						})

						// c. Add the modelled tariff (all costs / natural volume)
						obj.modelledTariff  = obj.cost.map((d, i) => d /obj.naturalVolume[i] )
					}
				})
			})

		// 4. REFERENCE CASE BY AGENCY-SITEGROUP > FOR APPLYING ACTIONS AT SITE TYPE LEVEL
			// + INITIATE ACTIVITY MULTIPLIER		
			dataModel.schema.interface.agencyList.forEach( agency => {	
				model.inventory.referenceCase.byAgency_sitegroup[agency] = {}
				settings.parameters.activityGrowth[agency] = {}					
				// a. For specified sitegroups
				dataModel.schema.consumption.sitegroupsByAgency[agency].forEach( sitegroup => {
					model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup] = {}
					settings.parameters.activityGrowth[agency][sitegroup] = dataModel.schema.modelYears.map(year => model.parameters.temporal['defaultActivityGrowth'].values[year])	

					Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {						
						model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector] = {}

						Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {											
							const data = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.agency === agency && d.sitegroup === sitegroup),
							 	naturalVolume 		= typeof [...new Set(data.map(d => d.naturalVolume))][0] !== 'undefined' ? [...new Set(data.map(d => d.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								cost 				= typeof [...new Set(data.map(d => d.cost) )][0] !== 'undefined' ? [...new Set(data.map(d => d.cost) )].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								modelledTariff  	= naturalVolume.length > 0 && cost.length > 0 && d3.sum(naturalVolume) > 0 ? cost.map((d, i) => d / naturalVolume[i]) : cost.map(d => 0),
								emissionsScope1 	= [...new Set(data.map(d => d.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
								emissionsScope2 	= [...new Set(data.map(d => d.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
								emissionsScope3 	= [...new Set(data.map(d => d.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
								emissionsTotal 		= emissionsScope1.map( (d, i) => d + emissionsScope2[i] + emissionsScope3[i]),
								emissionsReductionScope1 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
								emissionsReductionScope2 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
								emissionsReductionScope3 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
								emissionsReductionTotal 	= emissionsReductionScope1.map( (d, i) => d + emissionsReductionScope2[i] + emissionsReductionScope3[i]),
								emissionsSinksScope1 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
								emissionsSinksScope2 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
								emissionsSinksScope3 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
								emissionsSinksTotal 		= emissionsSinksScope1.map( (d, i) => d + emissionsSinksScope2[i] + emissionsSinksScope3[i])							

							if(data.length > 0){
								model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector][source] = {
									siteNames: 				[...new Set(data.map(d => d.sitenames.join(", ")) )],
									naturalVolume: 			naturalVolume ,
									naturalUnit: 			data[0]["naturalUnit"],										
									emissions: 	{
										Scope1: 			emissionsScope1,
										Scope2: 			emissionsScope2,
										Scope3: 			emissionsScope3,
										Total: 				emissionsTotal
									},	
									emissionsReduction: {
										Scope1: 			emissionsReductionScope1,
										Scope2: 			emissionsReductionScope2,
										Scope3: 			emissionsReductionScope3,
										Total: 				emissionsReductionTotal
									},		
									emissionsSinks: {
										Scope1: 			emissionsSinksScope1,
										Scope2: 			emissionsSinksScope2,
										Scope3: 			emissionsSinksScope3,
										Total: 				emissionsSinksTotal
									},																										
									cost: 					cost,
									modelledTariff: 		modelledTariff,
									tariffUnit: 			'$ per '+data[0]["naturalUnit"]
								}
							}

							// Add a placeholder for solar exported if grid electricty exists: this puts solar exported in all inventory cases
							if(sector === "Stationary energy" && source === "Grid electricity" && sitegroup !== "All of agency"){
								model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector]['Solar exported']  = {
									siteNames: 				[],
									naturalVolume: 			Array(dataModel.schema.modelHorizon).fill(0),
									naturalUnit: 			'MWh',										
									emissions: 	{
										Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
										Total: 				Array(dataModel.schema.modelHorizon).fill(0)
									},	
									emissionsReduction: {
										Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
										Total: 				Array(dataModel.schema.modelHorizon).fill(0)
									},		
									emissionsSinks: {
										Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
										Total: 				Array(dataModel.schema.modelHorizon).fill(0)
									},																										
									cost: 					Array(dataModel.schema.modelHorizon).fill(0),
									modelledTariff: 		model.parameters.general.price_SolarFeedIn.value,
									tariffUnit: 			'$ per MWh'
								}
							}
						})
					})							
				})				
				
				// c. For agency level data assigned to "All of agency" sitegroup
				model.inventory.referenceCase.byAgency_sitegroup[agency]['All of agency'] = {}

				ui.inventoryOrder.forEach(obj => {
					const sector = Object.keys(obj)[0],
					 	sourceArray = Object.values(obj)[0],
						agencySitegroupObj = model.inventory.referenceCase.byAgency_sitegroup[agency]['All of agency'] 
						agencyObj = model.inventory.referenceCase.byAgency[agency]

					sourceArray.forEach(source => { 
						if(dataModel.schema.consumption.agencyLevelSources.indexOf(source) > -1) {
							// i. Initialised object of byAgency_sitegroup
							if(typeof(agencySitegroupObj[sector]) === 'undefined'){	agencySitegroupObj[sector] = {}	} 
							if(typeof(agencySitegroupObj[sector][source]) === 'undefined'){ 
								agencySitegroupObj[sector][source] = {
									cost:  			Array(dataModel.schema.modelHorizon).fill(0),
									naturalVolume: 	Array(dataModel.schema.modelHorizon).fill(0),
									modelledTariff: Array(dataModel.schema.modelHorizon).fill(0),
									siteNames:  	[],
									emissions: {
										Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
										Total: 		Array(dataModel.schema.modelHorizon).fill(0)
									},
									emissionsReduction: {
										Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
										Total: 		Array(dataModel.schema.modelHorizon).fill(0)
									},
									emissionsSinks: {
										Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
										Total: 		Array(dataModel.schema.modelHorizon).fill(0)
									}
								}
							}
							// ii. Add each agency and build the byAgency_sitegroup object
							const obj = agencySitegroupObj[sector][source]	
							Object.values(model.inventory.referenceCase.bySite[sector][source]).forEach( agencyObj => {
								if(agency === agencyObj.agency){
									obj.naturalVolume = obj.naturalVolume.map((d,i) => d + agencyObj.naturalVolume[i] )
									obj.cost = obj.cost.map((d,i) => d + agencyObj.cost[i] )
									obj.emissions = {
										Scope1: 	obj.emissions.Scope1.map((d,i) => d + agencyObj.emissions.Scope1[i]),
										Scope2: 	obj.emissions.Scope2.map((d,i) => d + agencyObj.emissions.Scope2[i]),
										Scope3: 	obj.emissions.Scope3.map((d,i) => d + agencyObj.emissions.Scope3[i]),
										Total: 		obj.emissions.Total.map((d,i) => d + agencyObj.emissions.Scope1[i] + agencyObj.emissions.Scope2[i] + agencyObj.emissions.Scope3[i]),
									}
									obj.naturalUnit = agencyObj.naturalUnit
									obj.tariffUnit = agencyObj.tariffUnit
								}
							})
							obj.modelledTariff = obj.cost.map((d,i) => obj.naturalVolume[i] === 0 ? null : d / obj.naturalVolume[i])
						}
					})
				})
			})	
			
			// Created data for correct site names, 1) Clear any entries where there are custom list and 2) Create sorted lists
			for( const d of data.siteDataSitegroupByAgency){ 
				const agency = d.key
				for( const sitegroup of Object.keys(d.value)){
					dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup] = []
				}
			}

			data.siteData.forEach( d => {
				dataModel.schema.consumption.sitesByAgencySitegroup[d.agency][d.sitegroup].push(d.siteName)
				dataModel.schema.consumption.sitesByAgencySitegroup[d.agency][d.sitegroup].sort()
			})

		// 5. REFERENCE CASE BY CLUSTER-AGENCY-SITEGROUP > FOR APPLYING ACTIONS AT SITE TYPE LEVEL
			dataModel.schema.interface.clusterList.forEach( cluster => {
				model.inventory.referenceCase.byCluster_agency_sitegroup[cluster] = {}

				dataModel.schema.clusterMapping.agencyByCluster[cluster].forEach( agency => {
					model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency] = {}
					settings.parameters.activityGrowth[agency] = {}					

					if(typeof dataModel.schema.consumption.sitegroupsByAgency[agency] !== 'undefined' && dataModel.schema.consumption.sitegroupsByAgency[agency].length > 0){		// Guard for agencies in the cluster map that have no contracts data	
						dataModel.schema.consumption.sitegroupsByAgency[agency].forEach( sitegroup => {
							model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup] = {}
							settings.parameters.activityGrowth[agency][sitegroup] = {
								userUpdated: false, 
								value: 	dataModel.schema.modelYears.map(year => model.parameters.temporal['defaultActivityGrowth'].values[year])	
							}
							Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {						
								model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector] = {}
								Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {	
		
									const data = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.agency === agency && d.sitegroup === sitegroup),
									 	naturalVolume = typeof [...new Set(data.map(d => d.naturalVolume))][0] !== 'undefined' ? [...new Set(data.map(d => d.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
										cost = typeof [...new Set(data.map(d => d.cost) )][0] !== 'undefined' ? [...new Set(data.map(d => d.cost) )].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
										modelledTariff  = naturalVolume.length > 0 && cost.length > 0 && d3.sum(naturalVolume) > 0 ? cost.map((d, i) => d / naturalVolume[i]) : cost.map(d => 0),
										emissionsScope1 	= [...new Set(data.map(d => d.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
										emissionsScope2 	= [...new Set(data.map(d => d.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
										emissionsScope3 	= [...new Set(data.map(d => d.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
										emissionsTotal 		= emissionsScope1.map( (d, i) => d + emissionsScope2[i] + emissionsScope3[i]),
										emissionsReductionScope1 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
										emissionsReductionScope2 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
										emissionsReductionScope3 	= [...new Set(data.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
										emissionsReductionTotal 	= emissionsReductionScope1.map( (d, i) => d + emissionsReductionScope2[i] + emissionsReductionScope3[i]),
										emissionsSinksScope1 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
										emissionsSinksScope2 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
										emissionsSinksScope3 		= [...new Set(data.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
										emissionsSinksTotal 		= emissionsSinksScope1.map( (d, i) => d + emissionsSinksScope2[i] + emissionsSinksScope3[i])		

									if(data.length > 0){
										model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source] = {
											siteNames: 				[...new Set(data.map(d => d.sitenames.join(", ")) )],
											naturalVolume: 			naturalVolume ,
											naturalUnit: 			data[0]["naturalUnit"],										
											emissions: 	{
												Scope1: 			emissionsScope1,
												Scope2: 			emissionsScope2,
												Scope3: 			emissionsScope3,
												Total: 				emissionsTotal
											},	
											emissionsReduction: {
												Scope1: 			emissionsReductionScope1,
												Scope2: 			emissionsReductionScope2,
												Scope3: 			emissionsReductionScope3,
												Total: 				emissionsReductionTotal
											},		
											emissionsSinks: {
												Scope1: 			emissionsSinksScope1,
												Scope2: 			emissionsSinksScope2,
												Scope3: 			emissionsSinksScope3,
												Total: 				emissionsSinksTotal
											},																	
											cost: 					cost,
											modelledTariff: 		modelledTariff,
											tariffUnit: 			'$ per '+data[0]["naturalUnit"]
										}
									}
								})
							})							
						})	
					}
				})	
			})
		
		// 6. REFERENCE CASE BY CLUSTER 
			dataModel.schema.interface.clusterList.forEach( cluster => {
				model.inventory.referenceCase.byCluster[cluster] = {}
				Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {
					model.inventory.referenceCase.byCluster[cluster][sector] = {}
					Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {					
						const clusterData = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.cluster === cluster)
						if(clusterData.length > 0){
							const naturalVolume = typeof [...new Set(clusterData.map(d => d.naturalVolume))][0] !== 'undefined' ? [...new Set(clusterData.map(d => d.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								cost = typeof [...new Set(clusterData.map(d => d.cost) )][0] !== 'undefined' ? [...new Set(clusterData.map(d => d.cost) )].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								modelledTariff  = naturalVolume.length > 0 && cost.length > 0  && d3.sum(naturalVolume) > 0 ? cost.map((d, i) => d / naturalVolume[i]) : cost.map(d => 0)

							model.inventory.referenceCase.byCluster[cluster][sector][source]  = {
								siteNames: 				[...new Set(clusterData.map(d => d.sitenames.join(", ") ) )],
								refIds: 				[...new Set(clusterData.map(d => d.id) )],
								naturalVolume: 			naturalVolume ,
								naturalUnit: 			clusterData[0]["naturalUnit"],										
								emissions: {
									Scope1: 			[...new Set(clusterData.map(d => d.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope2: 			[...new Set(clusterData.map(d => d.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope3: 			[...new Set(clusterData.map(d => d.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Total: 				[...new Set(clusterData.map(d => d.emissions.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
								},	
								emissionsReduction: {
									Scope1: 			[...new Set(clusterData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope2: 			[...new Set(clusterData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope3: 			[...new Set(clusterData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Total: 				[...new Set(clusterData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Total  : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
								},		
								emissionsSinks: {
									Scope1: 			[...new Set(clusterData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope2: 			[...new Set(clusterData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope3: 			[...new Set(clusterData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Total: 				[...new Set(clusterData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Total  : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
								},																				
								cost: 					cost ,
								modelledTariff: 		modelledTariff,
								tariffUnit: 			'$ per '+clusterData[0]["naturalUnit"] 
							}
						}						
					})
				})
			})	

		// 7. REFERENCE CASE BY AGENCY
			dataModel.schema.interface.agencyList.forEach( agency => {
				model.inventory.referenceCase.byAgency[agency] = {}
				Object.keys(model.inventory.referenceCase.bySite).forEach( sector => {
					model.inventory.referenceCase.byAgency[agency][sector] = {}
					Object.keys(model.inventory.referenceCase.bySite[sector]).forEach( source => {
						const agencyData = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.agency === agency)
						if(agencyData.length > 0){
							const naturalVolume = typeof [...new Set(agencyData.map(d => d.naturalVolume))][0] !== 'undefined' ? [...new Set(agencyData.map(d => d.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								cost = typeof [...new Set(agencyData.map(d => d.cost) )][0] !== 'undefined' ? [...new Set(agencyData.map(d => d.cost) )].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) : [],
								modelledTariff  = naturalVolume.length > 0 && cost.length > 0  && d3.sum(naturalVolume) > 0 ? cost.map((d, i) => d / naturalVolume[i]) : cost.map(d => 0)	

							model.inventory.referenceCase.byAgency[agency][sector][source] = {
								siteNames: 				[...new Set(agencyData.map(d => d.sitenames.join(", ")) )],
								refIds: 				[...new Set(agencyData.map(d => d.id) )],
								naturalVolume: 			naturalVolume ,
								naturalUnit: 			agencyData[0]["naturalUnit"],										
								emissions: {
									Scope1: 			[...new Set(agencyData.map(d => d.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope2: 			[...new Set(agencyData.map(d => d.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Scope3: 			[...new Set(agencyData.map(d => d.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									Total: 				[...new Set(agencyData.map(d => d.emissions.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
								},	
								emissionsReduction: {
									Scope1: 			[...new Set(agencyData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope2: 			[...new Set(agencyData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope3: 			[...new Set(agencyData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Total: 				[...new Set(agencyData.map(d => typeof d.emissionsReduction !== 'undefined' ? d.emissionsReduction.Total  : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
								},		
								emissionsSinks: {
									Scope1: 			[...new Set(agencyData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope1 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope2: 			[...new Set(agencyData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope2 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Scope3: 			[...new Set(agencyData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Scope3 : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
									Total: 				[...new Set(agencyData.map(d => typeof d.emissionsSinks !== 'undefined' ? d.emissionsSinks.Total  : Array(dataModel.schema.modelHorizon).fill(0))) ].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
								},																				
								cost: 					cost ,
								modelledTariff: 		modelledTariff,
								tariffUnit: 			'$ per '+agencyData[0]["naturalUnit"] 
							}
						}
					})
				})
			})	

		// 8. MAKE LISTS: 
			// i .of all agencies modelled
			dataModel.schema.typologyMapping.modelAgencyList = Object.keys(model.inventory.referenceCase.byAgency)	
			console.log('...Reference case built!')
	}; // end buildReferenceCase()

	// PART B. Build an empty SwitchTo case inventory object that mirrors the reference case structure. This is done to allow fuel switch action models to store their "switched to" in a easily indexable object
	async function buildSwitchToCase(){
		// The switchTo part of the inventory is used an interim object to store and transfer switched fuels. It follows the inventory structure and is initialised here for all agencies, secrtors and sources
		console.log('*** 2B. INITIATING THE SWITCHTO INVENTORY OBJECT ***')
		// For byAgency
		Object.entries(model.inventory.referenceCase.byAgency).forEach(([agency, agencyObj]) => {  
			model.inventory.switchToCase.byAgency[agency] = {}
			Object.entries(agencyObj).forEach(([sector, sectorObj]) => {
				model.inventory.switchToCase.byAgency[agency][sector] = {}
				Object.entries(sectorObj).forEach(([source, sourceObj]) => {
					model.inventory.switchToCase.byAgency[agency][sector][source] = {
						emissions: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsReduction: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsSinks: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},						
						cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
						naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
						naturalUnit: 		model.inventory.referenceCase.byAgency[agency][sector][source].naturalUnit, 	
						tariffUnit: 		model.inventory.referenceCase.byAgency[agency][sector][source].tariffUnit,	
						modelledTariff: 	model.inventory.referenceCase.byAgency[agency][sector][source].modelledTariff	
					}
				})	
			})
		})

		// For byAgency_sitegroup
		Object.entries(model.inventory.referenceCase.byAgency_sitegroup).forEach(([agency, agencyObj]) => {  
			model.inventory.switchToCase.byAgency_sitegroup[agency] = {}
			Object.entries(agencyObj).forEach(([sitegroup, sitegroupObj]) => {
				model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup] = {}
				Object.entries(sitegroupObj).forEach(([sector, sectorObj]) => {
					model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector] = {}
					Object.entries(sectorObj).forEach(([source, sourceObj]) => {
						model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source] = {
							emissions: { 
								Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
								Total: 			Array(dataModel.schema.modelHorizon).fill(0)
							},
							emissionsReduction: { 
								Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
								Total: 			Array(dataModel.schema.modelHorizon).fill(0)
							},
							emissionsSinks: { 
								Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
								Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
								Total: 			Array(dataModel.schema.modelHorizon).fill(0)
							},						
							cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
							naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
							naturalUnit: 		model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector][source].naturalUnit, 	
							tariffUnit: 		model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector][source].tariffUnit,	
							modelledTariff: 	model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector][source].modelledTariff	
						}
					})	
				})
			})
			// Add the electrification object for all of agency
			model.inventory.switchToCase.byAgency_sitegroup[agency]['All of agency']['Stationary energy'] = {} 
			model.inventory.switchToCase.byAgency_sitegroup[agency]['All of agency']['Stationary energy']['Grid electricity'] = {
				naturalVolume: 			dataModel.schema.modelYears.map(d => 0),
				naturalUnit: 			dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit,										
				emissions: 	{
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				emissionsReduction: {
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				emissionsSinks: {
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				cost: 					dataModel.schema.modelYears.map(d => 0) ,
				tariffUnit: 			'$ per '+dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit
			}	
		})

		// For byCluster
		Object.entries(model.inventory.referenceCase.byCluster).forEach(([cluster, clusterObj]) => {  
			model.inventory.switchToCase.byCluster[cluster] = {}
			Object.entries(clusterObj).forEach(([sector, sectorObj]) => {
				model.inventory.switchToCase.byCluster[cluster][sector] = {}
				Object.entries(sectorObj).forEach(([source, sourceObj]) => {
					model.inventory.switchToCase.byCluster[cluster][sector][source] = {
						emissions: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsReduction: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsSinks: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},						
						cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
						naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
						naturalUnit: 		model.inventory.referenceCase.byCluster[cluster][sector][source].naturalUnit, 	
						tariffUnit: 		model.inventory.referenceCase.byCluster[cluster][sector][source].tariffUnit,	
						modelledTariff: 	model.inventory.referenceCase.byCluster[cluster][sector][source].modelledTariff	
					}
				})	
			})
		})

		// For byCluster_sitegroup
		Object.entries(model.inventory.referenceCase.byCluster_agency_sitegroup).forEach(([cluster, clusterObj]) => {  
			model.inventory.switchToCase.byCluster_agency_sitegroup[cluster] = {}
			Object.entries(clusterObj).forEach(([agency, agencyObj]) => {
				model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency] = {}
				Object.entries(agencyObj).forEach(([sitegroup, sitegroupObj]) => {
					model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup] = {}
					Object.entries(sitegroupObj).forEach(([sector, sectorObj]) => {
						model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector] = {}
						Object.entries(sectorObj).forEach(([source, sourceObj]) => {
							model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source] = {
								emissions: { 
									Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
									Total: 			Array(dataModel.schema.modelHorizon).fill(0)
								},
								emissionsReduction: { 
									Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
									Total: 			Array(dataModel.schema.modelHorizon).fill(0)
								},
								emissionsSinks: { 
									Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
									Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
									Total: 			Array(dataModel.schema.modelHorizon).fill(0)
								},						
								cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
								naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
								naturalUnit: 		model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalUnit, 	
								tariffUnit: 		model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].tariffUnit,	
								modelledTariff: 	model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].modelledTariff	
							}
						})	
					})
				})
				// Add the electrification object for all of agency
				model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency]['All of agency']['Stationary energy'] = {} 
				model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency]['All of agency']['Stationary energy']['Grid electricity'] = {
					naturalVolume: 			dataModel.schema.modelYears.map(d => 0),
					naturalUnit: 			dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit,										
					emissions: 	{
						Scope1: 			dataModel.schema.modelYears.map(d => 0),
						Scope2: 			dataModel.schema.modelYears.map(d => 0),
						Scope3: 			dataModel.schema.modelYears.map(d => 0),
						Total: 				dataModel.schema.modelYears.map(d => 0)
					},	
					emissionsReduction: {
						Scope1: 			dataModel.schema.modelYears.map(d => 0),
						Scope2: 			dataModel.schema.modelYears.map(d => 0),
						Scope3: 			dataModel.schema.modelYears.map(d => 0),
						Total: 				dataModel.schema.modelYears.map(d => 0)
					},	
					emissionsSinks: {
						Scope1: 			dataModel.schema.modelYears.map(d => 0),
						Scope2: 			dataModel.schema.modelYears.map(d => 0),
						Scope3: 			dataModel.schema.modelYears.map(d => 0),
						Total: 				dataModel.schema.modelYears.map(d => 0)
					},	
					cost: 					dataModel.schema.modelYears.map(d => 0) ,
					tariffUnit: 			'$ per '+dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit
				}	
			})
		})

		// For bySector_source
		Object.entries(model.inventory.referenceCase.bySectorSource).forEach(([sector, sectorObj]) => {  
			model.inventory.switchToCase.bySectorSource[sector] = {}
			Object.entries(sectorObj).forEach(([source, sourceObj]) => {
				model.inventory.switchToCase.bySectorSource[sector][source] = {
					emissions: { 
						Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
						Total: 			Array(dataModel.schema.modelHorizon).fill(0)
					},
					emissionsReduction: { 
						Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
						Total: 			Array(dataModel.schema.modelHorizon).fill(0)
					},
					emissionsSinks: { 
						Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
						Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
						Total: 			Array(dataModel.schema.modelHorizon).fill(0)
					},						
					cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
					naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
					naturalUnit: 		model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit, 	
					tariffUnit: 		model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit,	
					modelledTariff: 	model.inventory.referenceCase.bySectorSource[sector][source].modelledTariff	
				}
			})	
		})

		// For bySite
		Object.entries(model.inventory.referenceCase.bySite).forEach(([sector, sectorObj]) => {  
			model.inventory.switchToCase.bySite[sector] = {}
			Object.entries(sectorObj).forEach(([source, sourceObj]) => {
			model.inventory.switchToCase.bySite[sector][source] = {}
				Object.entries(sourceObj).forEach(([site, siteObj]) => {
					model.inventory.switchToCase.bySite[sector][source][site] = {
						emissions: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsReduction: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsSinks: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},						
						cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
						naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
						naturalUnit: 		model.inventory.referenceCase.bySite[sector][source][site].naturalUnit, 	
						tariffUnit: 		model.inventory.referenceCase.bySite[sector][source][site].tariffUnit,	
						modelledTariff: 	model.inventory.referenceCase.bySite[sector][source][site].modelledTariff	
					}
				})	
			})	
		})

		// For bySitegroup
		Object.entries(model.inventory.referenceCase.bySitegroup).forEach(([sector, sectorObj]) => {  
			model.inventory.switchToCase.bySitegroup[sector] = {}
			Object.entries(sectorObj).forEach(([source, sourceObj]) => {
			model.inventory.switchToCase.bySitegroup[sector][source] = {}
				Object.entries(sourceObj).forEach(([sitegroup, sitegroupObj]) => {
					model.inventory.switchToCase.bySitegroup[sector][source][sitegroup] = {
						emissions: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsReduction: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},
						emissionsSinks: { 
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						},						
						cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
						naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
						naturalUnit: 		model.inventory.referenceCase.bySitegroup[sector][source][sitegroup].naturalUnit, 	
						tariffUnit: 		model.inventory.referenceCase.bySitegroup[sector][source][sitegroup].tariffUnit,	
						modelledTariff: 	model.inventory.referenceCase.bySitegroup[sector][source][sitegroup].modelledTariff	
					}
				})
			})	
		})
			// Add the electrification object for all of agency
			model.inventory.switchToCase.bySitegroup['Stationary energy']['Grid electricity']['All of agency'] = {
				naturalVolume: 			dataModel.schema.modelYears.map(d => 0),
				naturalUnit: 			dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit,										
				emissions: 	{
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				emissionsReduction: {
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				emissionsSinks: {
					Scope1: 			dataModel.schema.modelYears.map(d => 0),
					Scope2: 			dataModel.schema.modelYears.map(d => 0),
					Scope3: 			dataModel.schema.modelYears.map(d => 0),
					Total: 				dataModel.schema.modelYears.map(d => 0)
				},	
				cost: 					dataModel.schema.modelYears.map(d => 0) ,
				tariffUnit: 			'$ per '+dataModel.schema.inventory['Stationary energy']['Grid electricity'].unit
			}	

		// For summaryTotal
		model.inventory.switchToCase.summaryTotal = {
			emissions: { 
				Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
				Total: 			Array(dataModel.schema.modelHorizon).fill(0)
			},
			emissionsReduction: { 
				Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
				Total: 			Array(dataModel.schema.modelHorizon).fill(0)
			},
			emissionsSinks: { 
				Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
				Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
				Total: 			Array(dataModel.schema.modelHorizon).fill(0)
			},						
			cost: 				Array(dataModel.schema.modelHorizon).fill(0),	
		}
	}; // end buildSwitchToCase

	// PART C. ESTABLISH THE AGENCY LEVEL TARGETS	
	async function setAgencyTargets(){
		for( const obj of data.agencyTargets){
			const agency = obj.agency
			if (dataModel.schema.typologyMapping.modelAgencyList.indexOf(agency) > -1){
				const agencyRefData = model.inventory.referenceCase.byAgency[agency],
					agencyEmissions =  d3.sum(Object.values(agencyRefData).map(d => Object.values(d)).map(d => d3.sum(Object.values(d).map(d => d.emissions.Total[0]))) )

				settings.targets.byAgency[agency] = {
					targetYear: 		obj.et1_targetYear !== "" && dataModel.schema.indexOf(+obj.et1_targetYear) > -1 ? +obj.et1_targetYear : settings.parameters.horizon,
					targetGHG: 			obj.et1_absolute !== "" && !isNaN(parseFloat(obj.et1_absolute.replace(/,/g, '')) ) ? parseFloat(obj.et1_absolute.replace(/,/g, '')) : 
											obj.et1_pcReductionScope12 !== "" ? (1 - obj.et1_pcReductionScope12) * agencyEmissions : null,
					targetPct_S12: 		obj.et1_absolute !== "" && !isNaN(parseFloat(obj.et1_absolute .replace(/,/g, '')))  ? parseFloat(obj.et1_absolute .replace(/,/g, '')) / agencyEmissions : 
											obj.et1_pcReductionScope12 !== "" ? (1 - obj.et1_pcReductionScope12) :  null,
					targetPct_S3: 		obj.et1_absolute !== "" && !isNaN(parseFloat(obj.et1_absolute .replace(/,/g, '')))  ? parseFloat(obj.et1_absolute .replace(/,/g, '')) / agencyEmissions : 
											obj.et1_pcReductionScope3 !== "" ? (1 - obj.et1_pcReductionScope3) :  null
				}
			}
		}
	}


///////////////////////////////////////////////////
// 3. BUILD ACTION BUSINESS CASE-IMPACT MODELS  //
/////////////////////////////////////////////////

	// PART A. CREATE/UPDATE ACTIONS AT THE AGENCY-SITEGROUP LEVEL
	async function buildActionModels(rebuild = false){
		if(!rebuild) {	console.log('**** 3A. BUILDING ACTION MODELS: ****') }	else { console.log('**** RE-BUILDING ACTION MODELS: ****')	}

		// I. BUILD ACTION MODELS
			switch(model.settings.actionModelLevel){
				case 'sitegroup':	// Note: this is the only level available. A future server sided application may include site level modelling 
					// 1. BUILD AGENCY-SITEGROUP LEVEL			
					Object.keys(model.inventory.referenceCase.byAgency_sitegroup).forEach(agency => {
						if(!rebuild){
							model.action.businessCase.byAgency_sitegroup[agency] = {}
							settings.action.byAgency_sitegroup[agency] = {}
							model.action.summaryCount[agency] = {}											
						}						
						Object.keys(model.inventory.referenceCase.byAgency_sitegroup[agency]).forEach( sitegroup => {							
							if(!rebuild){
								model.action.businessCase.byAgency_sitegroup[agency][sitegroup] = {}
								settings.action.byAgency_sitegroup[agency][sitegroup] = {}
							}
							model.action.summaryCount[agency][sitegroup] = {
								noActions: 		0,
								capitalCost: 	0,
								solar: 		 	{}
							}

							// Set solar electricity-related and site consumption threshold check variables
							let sitegroupElecConsumption = sitegroup === 'All of agency' ? Array(dataModel.schema.modelHorizon).fill(0)  // Note: consumption from electrification actions is added AFTER the action is modelled. Other agency level actions have no electricity impact
									: typeof model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup]['Stationary energy']['Grid electricity'] !== 'undefined' 
									? model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup]['Stationary energy']['Grid electricity']['naturalVolume'] 
									: null,
								onSiteConsumptionMWh = Array(dataModel.schema.modelHorizon).fill(0), 
								exportedElecMWh 	 = Array(dataModel.schema.modelHorizon).fill(0), 
								meetsThreshold 	     = false 										// Default to false and run checks below

							dataModel.schema.actions.ids.forEach(actionID => {
								const actionParameters = model.action.parameters[actionID],
									actionSettings =  settings.action.byAgency_sitegroup[agency][sitegroup][actionID]

								// Check for for action consumption threshold at site level (where specified/applicable)
								const sectorFrom =  actionParameters.impact.from[0].sector, 			// Sector and source specified 
									sourceFrom =  actionParameters.impact.from[0].source, 				// as being reduced by the action
									tempRefCaseFrom = (sitegroup === 'All of agency') ? null  			// Agency level actions have no threshold checks and there are no byAgency_sitegroup reference case where agencies without agency level data
										: model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sectorFrom][sourceFrom]

								if(tempRefCaseFrom && typeof tempRefCaseFrom !== 'undefined'){
									const noSitesInSitegroup = tempRefCaseFrom.siteNames.length
									meetsThreshold = (typeof actionParameters.opportunity[sitegroup] !== 'undefined' && typeof actionParameters.opportunity[sitegroup].siteThreshold !== 'undefined' && actionParameters.opportunity[sitegroup].siteThreshold < (tempRefCaseFrom.naturalVolume[0] / noSitesInSitegroup)) ? true : false																
								} else { 
								 	// For agency level actions threshold check is for agency supplied data does not apply (as no site data is available)
									meetsThreshold = data.agencyConsumption.filter(d => d.agencyName === agency && d.sector === sectorFrom && d.source === sourceFrom && d.volume > 0).length > 0 ? true : false  
								}

								///////////////////////////////////////////////////////////////////////////
								//// ADD EMISSIONS REDUCTION ACTION (IF CONSUMPTION THRESHOLD IS MET)  ////
								///////////////////////////////////////////////////////////////////////////
								if(meetsThreshold){								
									let impactOutflow = [], 	
										activityOutflowImpact = [],
										impactInflow = [],  			// Inflow can be multiple sources (e.g solar consumed/exported)
										activityInflowImpact = [],
										referenceCaseFrom = [],						
										totalActivityPropBySource = {},		// Tracks activity proportion affect						
										switchToCase,	
										activityCounter = 0, 
										impactRefCaseSectorSources,
										elecActionIDs = []

									// 0. Check for matched action sitegroup before adding an action
									if((!rebuild && actionParameters.meta.sitegroups.indexOf(sitegroup) > -1)  || rebuild && sitegroup !=='All of agency'){									
										dataModel.schema.consumption.sources.concat(dataModel.schema.consumption.agencyLevelSources).forEach( source => totalActivityPropBySource[source] = 0 )

										// 1. CALC. REDUCTION IMPACT (STOCK OUTFLOW)
										for( const impactFrom of actionParameters.impact.from){
											const impactRefCaseFrom = model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][impactFrom.sector][impactFrom.source]
											impactRefCaseSectorSources = Object.keys(model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][impactFrom.sector])

											if(typeof(impactRefCaseFrom) !== 'undefined' && d3.sum(impactRefCaseFrom.naturalVolume) > 0) {		// Guard for undefined impactRefCaseFrom and zero volume																	
												referenceCaseFrom.push(impactRefCaseFrom)
												let outflowObj = {
													costSaving: 			Array(dataModel.schema.modelHorizon).fill(0),
													emissionsReduction: 	{
														Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
														Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
														Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
														Total: 				Array(dataModel.schema.modelHorizon).fill(0)
													},											
													naturalVolume: 			Array(dataModel.schema.modelHorizon).fill(0),
													baselineNaturalVolume: 	Array(dataModel.schema.modelHorizon).fill(0),
												}

												// Calculate activity level impact for impact type: Efficiency, Generation and Switch
												switch(actionParameters.impact.type.toLowerCase()){
													case 'efficiency':
													case 'reduction':
													case 'switch':
														// 1. Loop to extract variables
														for( const activityObj of impactFrom.reductionByActivity) {
															const activity 		= activityObj.activity,
																activityProp 	= model.parameters.typology[sitegroup][activity],
																impactPct 		= activityObj.reductionPct,  
																targetUptake 	= rebuild ? actionSettings.opportunity.targetUptake : actionParameters.opportunity[sitegroup].targetUptake,
																costImpact 		= impactRefCaseFrom.cost.map( d => actionParameters.meta.sector ==="Waste" ? 0 : d * activityProp * impactPct * targetUptake),
																scope1Impact	= impactRefCaseFrom.emissions.Scope1.map( d => d * activityProp * impactPct * targetUptake),
																scope2Impact	= impactRefCaseFrom.emissions.Scope2.map( d => d * activityProp * impactPct * targetUptake ),
																scope3Impact	= impactRefCaseFrom.emissions.Scope3.map( d => d * activityProp * impactPct * targetUptake ),
																totalEmissionsImpact	= impactRefCaseFrom.emissions.Total.map( d => d * activityProp * impactPct * targetUptake ),
																naturalVolumeImpact		= impactRefCaseFrom.naturalVolume.map( d => d * activityProp * impactPct * targetUptake ),
																baselineNaturalVolume	= impactRefCaseFrom.naturalVolume.map( d => d * activityProp )
															totalActivityPropBySource[sourceFrom] += activityProp // Track total activity affected for calculating per unit costs

															// Push to activityOutflow for each impactFrom object
															activityOutflowImpact.push({
																[activity]: {
																	costSaving: 			costImpact,
																	emissionsReduction: {
																		Scope1: 			scope1Impact,
																		Scope2: 			scope2Impact,
																		Scope3: 			scope3Impact,
																		Total: 				totalEmissionsImpact
																	},																
																	naturalVolume: 			naturalVolumeImpact,
																	baselineNaturalVolume: 	baselineNaturalVolume,
																	source: 				impactFrom.source,
																}
															})
														}
														// 2a. Re-loop to get cumulative (reduction) impact of all activities
														for( const activityObj of impactFrom.reductionByActivity) {
															const activity  		= activityObj.activity, 
																activityData 		= activityOutflowImpact[activityCounter][activity],
															 	cumCostImpact 		= outflowObj.costSaving.map((d, i) => d + activityData.costSaving[i]),
																cumScope1Impact		= outflowObj.emissionsReduction.Scope1.map( (d, i) => d + activityData.emissionsReduction.Scope1[i] ),
																cumScope2Impact		= outflowObj.emissionsReduction.Scope2.map( (d, i) => d + activityData.emissionsReduction.Scope2[i] ),
																cumScope3Impact		= outflowObj.emissionsReduction.Scope3.map( (d, i) => d + activityData.emissionsReduction.Scope3[i] ),
																cumTotalEmissionsImpact		= outflowObj.emissionsReduction.Total.map( (d, i) => d + activityData.emissionsReduction.Total[i] ),
																cumNaturalVolsImpact		= outflowObj.naturalVolume.map( (d, i) => d + activityData.naturalVolume[i] ),
																cumBaselineNaturalVols		= outflowObj.baselineNaturalVolume.map( (d, i) => d + activityData.baselineNaturalVolume[i] )

															activityCounter++
															outflowObj = {
																costSaving: 			cumCostImpact,
																emissionsReduction: 	{
																	Scope1: 			cumScope1Impact,
																	Scope2: 			cumScope2Impact,
																	Scope3: 			cumScope3Impact,
																	Total: 				cumTotalEmissionsImpact
																},
																naturalVolume: 			cumNaturalVolsImpact,
																baselineNaturalVolume: 	cumBaselineNaturalVols,
																naturalUnit: 			impactRefCaseFrom.naturalUnit,
																source: 				impactFrom.source,
															}
															impactOutflow.push(outflowObj)
														}
														//  2b. Update the sitegroup electricity for all efficiency and switch actions before assessing generation (solar) options.
															// Note: action impact hierarchy is enforced by the actionIDs: Electricity related actions with types of 'efficiency' (and 'switch') need to have a lower ID number (than 'generation' and 'offset') to execute first
															// Electrification switches at 'All of agency' level won't actually matter (as solar is modelled at sitegroup level) 
														const totalElecConsumption = impactOutflow.filter(d => d.source === 'Grid electricity').map(d => d.naturalVolume).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
														if(sitegroupElecConsumption && totalElecConsumption.length > 0 && elecActionIDs.indexOf(actionID) < 0){
															sitegroupElecConsumption = sitegroupElecConsumption.map( (d,i) => d - totalElecConsumption[i])
															elecActionIDs.push(actionID)
														}
														break

													case 'generation':	// For solar PV options 
														const totalNoSites 		= impactRefCaseFrom.siteNames.length
															kWPerSite 	 		= rebuild ? actionSettings.opportunity.sizekWPerSite : actionParameters.opportunity[sitegroup].sizekWPerSite,
															targetUptake 		= rebuild ? actionSettings.opportunity.targetUptake : actionParameters.opportunity[sitegroup].targetUptake,	
															noSites 	 		= rebuild ? totalNoSites * targetUptake : dataModel.schema.consumption.sitesByAgencySitegroup[agency][sitegroup].length,
															generationMWh 		= model.parameters.general.CF_SolarIrradiance_MWh_per_kW.value.map(d => d * noSites * kWPerSite),
															solarLoadMatchPct 	= model.parameters.typology[sitegroup]['SOLAR - Matched load'],
															solarMatchedMWh     = sitegroupElecConsumption.map( d => d * solarLoadMatchPct * targetUptake)

														generationMWh.forEach((generatedMWh, i) => {
															if(generatedMWh > solarMatchedMWh[i]){ 			// If (total) generation is more than (total) consumption that could be matched by solar (i.e. daylight hours)
																exportedElecMWh[i] = generatedMWh - solarMatchedMWh[i]  			// then allocate excess to export
																onSiteConsumptionMWh[i] = solarMatchedMWh[i] 						// and onsite consumption is capped at the matched load
															}  else {										// If (total) generation is LESS than (total) consumption that could be matched by solar
																exportedElecMWh[i] = 0												// then there is no export
																onSiteConsumptionMWh[i] = generatedMWh 								// and all generation is used on site
															}
														})
												
														impactOutflow = [{
															costSaving: 		impactRefCaseFrom.modelledTariff.map( (d, i) => d * onSiteConsumptionMWh[i]),
															emissionsReduction: {
																Scope1: 		onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
																Scope2: 		onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
																Scope3: 		onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
																Total: 			onSiteConsumptionMWh.map( (d, i) => d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i]) )
															},													
															naturalVolume: 		onSiteConsumptionMWh,
															naturalUnit: 		impactRefCaseFrom.naturalUnit,
															source: 			impactFrom.source,
														}]
														// Record solar metrics
														model.action.summaryCount[agency][sitegroup]['solar'] = {
															modelledCapacitykW: 		noSites * kWPerSite * targetUptake,
															modelledPenetration: 		targetUptake,
															modelledNoSites: 			noSites * targetUptake,
															modelledSitekWPerSite: 		kWPerSite,
															"Solar exported": 			exportedElecMWh,	
															"Solar consumed": 			onSiteConsumptionMWh,
															"Solar generated": 			generationMWh,
															modelledExportPct: 			d3.sum(exportedElecMWh) / (d3.sum(exportedElecMWh) + d3.sum(onSiteConsumptionMWh)),
															totalNoSites: 				noSites										
														}		
														//  Update the sitegroup electricity before assessing PPA opportunity
														if(impactFrom.source === 'Grid electricity' && elecActionIDs.indexOf(actionID) < 0){
															sitegroupElecConsumption = sitegroupElecConsumption.map( (d,i) => d - onSiteConsumptionMWh[i] )
															elecActionIDs.push(actionID)
														}
														break
													case 'offset':	// For PPAs
														const targetPerSite 	= !rebuild ? actionParameters.opportunity[sitegroup].targetUptake : actionSettings.opportunity.targetUptake	
														impactOutflow = [{
															costSaving: 			sitegroupElecConsumption.map((d,i) => d * impactRefCaseFrom.modelledTariff[i] * targetPerSite),
															emissionsReduction: 	{
																Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
																Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
																Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
																Total: 				Array(dataModel.schema.modelHorizon).fill(0)
															},
															naturalVolume: 			sitegroupElecConsumption.map(d => d * targetPerSite),
															baselineNaturalVolume: 	sitegroupElecConsumption.map(d => d * targetPerSite),
															naturalUnit: 			impactRefCaseFrom.naturalUnit,
															source: 				impactFrom.source
														}]
														break
												}
											}	
										}

										// 2. GENERATION OR FUEL SWITCH IMPACT >> STOCK INFLOW | This should be generalized when further sinks are included in the inventory		
										if((actionParameters.impact.type.toLowerCase() !== 'efficiency' || actionParameters.impact.type.toLowerCase() !== 'reduction') && typeof referenceCaseFrom !== 'undefined'){
											for( const impactTo of actionParameters.impact.to){
												switch(actionParameters.impact.type.toLowerCase()){
													case 'switch':	
														// a. Calculate switch impact (if there was an outflow object recorded)
														if(impactOutflow.length > 0){ 
															switchToCase = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][impactTo.sector][impactTo.source]
															const outflowNaturalVolume  = [...new Set(impactOutflow.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), // Assumes only one source for a switch action
																conversionFactor 		= model.parameters.general[impactTo.cf].value,
																sourceEF 				= model.parameters.emissionFactors[impactTo.sourceEF],
																newConsumption 			= outflowNaturalVolume.map( (d, i) => d * conversionFactor[i]),
																price 					= model.parameters.general[impactTo.price].value.map(d => d * model.parameters.general[impactTo.price].unitMultiplier)
																cost 					= newConsumption.map( (d, i) => d * price[i]),
																newScope1 				= newConsumption.map( (d, i) => d * sourceEF.scope1[i]),
																newScope2 				= newConsumption.map( (d, i) => d * sourceEF.scope2[i]),
																newScope3 				= newConsumption.map( (d, i) => d * sourceEF.scope3[i]),
																newTotal 				= newConsumption.map( (d, i) => d * (sourceEF.scope1[i] + sourceEF.scope2[i] + sourceEF.scope3[i]) )

															impactInflow.push({
																benefit: 			Array(dataModel.schema.modelHorizon).fill(0),
																cost: 				cost,
																emissions: { 		 // Push switch impact as negative reduction
																	Scope1: 		newScope1,
																	Scope2: 		newScope2,
																	Scope3: 		newScope3,
																	Total: 			newTotal
																},
																emissionsReduction: 	{
																	Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Total: 			Array(dataModel.schema.modelHorizon).fill(0)
																},
																emissionsSinks: 	{
																	Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Total: 			Array(dataModel.schema.modelHorizon).fill(0)
																},
																emissionsSinksBySource: {
																	Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Total: 			Array(dataModel.schema.modelHorizon).fill(0)
																},
																naturalVolume: 		newConsumption,
																source: 			impactTo.source,
															})
														}
														break

													case 'generation':	// For a rooftop solar case
														if( typeof model.action.summaryCount[agency][sitegroup]['solar'] !== 'undefined' &&  Object.keys(model.action.summaryCount[agency][sitegroup]['solar']).length > 0){
															const noSites 	 	  = model.action.summaryCount[agency][sitegroup]['solar'].totalNoSites,
																kWPerSite 	 	  = rebuild ? actionSettings.opportunity.sizekWPerSite : actionParameters.opportunity[sitegroup].sizekWPerSite,
																targetUptake 	  = rebuild ? actionSettings.opportunity.targetUptake : actionParameters.opportunity[sitegroup].targetUptake,
																sourceProportion  = (d3.sum(model.action.summaryCount[agency][sitegroup]['solar']['Solar generated']) === 0) ? 0 : d3.sum(model.action.summaryCount[agency][sitegroup]['solar'][impactTo.source]) / d3.sum(model.action.summaryCount[agency][sitegroup]['solar']['Solar generated']),
																sourceElecMWh 	  = model.parameters.general.CF_SolarIrradiance_MWh_per_kW.value.map(d => d * noSites * kWPerSite * targetUptake * sourceProportion),
																sourceType 		  = dataModel.schema.inventory[impactTo.sector][impactTo.source].type

															impactInflow.push({
																benefit: 			sourceElecMWh.map( (d, i) => d * (impactTo.source.toLowerCase() === 'solar exported' ? settings.parameters.general.price_SolarFeedIn.value[i] : 0 ) ),
																cost: 				Array(dataModel.schema.modelHorizon).fill(0),
																emissionsReduction: 	{
																	Scope1: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope1[i] ),
																	Scope2: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope2[i] ),
																	Scope3: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope3[i] ),
																	Total: 			sourceElecMWh.map( (d, i) => d * (model.parameters.emissionFactors.EF_Zero_Emissions.scope1[i] + model.parameters.emissionFactors.EF_Zero_Emissions.scope2[i] + model.parameters.emissionFactors.EF_Zero_Emissions.scope3[i]) )
																},
																emissionsSinks: 	{
																	Scope1: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] : 0 ) ),
																	Scope2: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] : 0 ) ),
																	Scope3: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] : 0 ) ),
																	Total: 			sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i]) : 0 ) )
																},
																emissionsSinksBySource: {
																	Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Total: 			Array(dataModel.schema.modelHorizon).fill(0)
																},														
																naturalVolume: 		sourceElecMWh,
																source: 			impactTo.source,
															})
														}			
														break

													case 'offset':		// For a PPA like switch	
														const pctSourcePerSite 	  = actionParameters.opportunity[sitegroup].targetUptake, 						// Always 100% per site
															outflowNaturalVolume 		= [...new Set(impactOutflow.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
															referenceCaseFromTariff 	= [...new Set(referenceCaseFrom.map(obj => obj.modelledTariff))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])

															impactInflow.push({
																benefit: 			Array(dataModel.schema.modelHorizon).fill(0),
																cost: 				outflowNaturalVolume.map((d, i) => d * (referenceCaseFromTariff[i] + settings.parameters.general.price_PPA.value[i]) ),
																emissionsReduction: 	{
																	Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
																	Total: 			Array(dataModel.schema.modelHorizon).fill(0)
																},
																emissionsSinks: 	{
																	Scope1: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
																	Scope2: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
																	Scope3: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
																	Total: 			outflowNaturalVolume.map((d, i) => -d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ))
																},	
																emissionsSinksBySource: {
																	Scope1: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
																	Scope2: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
																	Scope3: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
																	Total: 			outflowNaturalVolume.map((d, i) => -d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ))
																},																
																naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
																source: 			impactTo.source
															})

														break
												}
											}
										}
										// 3. ADD THE COMPLETED ACTION IMPACT OBJECT	
										if(typeof referenceCaseFrom !== 'undefined'  && d3.sum([...new Set(referenceCaseFrom.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ) > 0){ 
											// I. CALC EMISSIONS IMPACTS OBJECT IMPACT DATA	
												const reducedNaturalVolume = 	d3.nest().key(d => d.source).entries(impactOutflow).map(d => { 
																					return { 
																						[d.key] : d.values.map(d => d.naturalVolume).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
																					}
																				}),
												 	outflowEmissionsReductionScope1   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													outflowEmissionsReductionScope2   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													outflowEmissionsReductionScope3   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													outflowEmissionsReductionTotal 	  = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													outflowSources = [...new Set(impactOutflow.map(obj => obj.source))],
													inflowSources = [...new Set(impactOutflow.map(obj => obj.source))],
													emissionsNew  = {  	// NEW EMISSIONS FROM SWTICHED TO FUELS
														Scope1: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Scope2: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Scope3: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Total: 	 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
													},
													emissionsSinks = {  		// SINKS 
														Scope1: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Scope2: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Scope3: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
														Total: 	 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
													},
													emissionsReduction = {
														Scope1: 	 outflowEmissionsReductionScope1.map( (d,i) => d - emissionsNew.Scope1[i] - emissionsSinks.Scope1[i] ),
														Scope2: 	 outflowEmissionsReductionScope2.map( (d,i) => d - emissionsNew.Scope2[i] - emissionsSinks.Scope2[i]),
														Scope3:  	 outflowEmissionsReductionScope3.map( (d,i) => d - emissionsNew.Scope3[i] - emissionsSinks.Scope3[i]),
														Total: 	 	 outflowEmissionsReductionTotal.map( (d,i) => d - emissionsNew.Total[i] - emissionsSinks.Total[i])
													},	
													emissionsRedExSinks  = {  	// NET REDUCTION (FLOWS) EX SINKS
														Scope1: 	 emissionsReduction.Scope1.map((d, i) => d - emissionsSinks.Scope1[i]),
														Scope2: 	 emissionsReduction.Scope2.map((d, i) => d - emissionsSinks.Scope2[i]),
														Scope3: 	 emissionsReduction.Scope3.map((d, i) => d - emissionsSinks.Scope3[i]),
														Total: 	 	 emissionsReduction.Total.map((d, i) => d - emissionsSinks.Total[i])
													},
													emissionsGrossReduction = {
														Scope1: 	 emissionsSinks.Scope1.map((d, i) => -d + emissionsRedExSinks.Scope1[i]),
														Scope2: 	 emissionsSinks.Scope2.map((d, i) => -d + emissionsRedExSinks.Scope2[i]),
														Scope3:  	 emissionsSinks.Scope3.map((d, i) => -d + emissionsRedExSinks.Scope3[i]),
														Total: 	 	 emissionsSinks.Total.map((d, i)  => -d + emissionsRedExSinks.Total[i])
													},	
													emissionsReductionBySource = {},
													emissionsSinksBySource = {},
													discountedNetEmissionsImpact = emissionsReduction.Total.map( (d,i) => (d  / settings.parameters.financial["Discount factor"][i])  ) ,
													switchToNaturalVolume 		 = actionParameters.impact.type.toLowerCase() !== 'switch' ? Array(dataModel.schema.modelHorizon).fill(0) 
																					:  impactInflow[0].naturalVolume 	// This assumes only one switched to item

													// Initiate and record the total emissions reduction by source
													for( const source of outflowSources){
														if(impactRefCaseSectorSources.indexOf(source) > -1){
															emissionsReductionBySource[source] = {
																Scope1: 	 Array(dataModel.schema.modelHorizon).fill(0),
																Scope2: 	 Array(dataModel.schema.modelHorizon).fill(0),
																Scope3:  	 Array(dataModel.schema.modelHorizon).fill(0),
																Total: 	 	 Array(dataModel.schema.modelHorizon).fill(0),
															}
														}
													}																
													for( const obj of impactOutflow){
														if( impactRefCaseSectorSources.indexOf(obj.source) > -1){
															emissionsReductionBySource[obj.source] = {
																Scope1: 	emissionsReductionBySource[obj.source].Scope1.map((d,i) => d + obj.emissionsReduction.Scope1[i]) ,
																Scope2: 	emissionsReductionBySource[obj.source].Scope2.map((d,i) => d + obj.emissionsReduction.Scope2[i] ) ,
																Scope3:  	emissionsReductionBySource[obj.source].Scope3.map((d,i) => d + obj.emissionsReduction.Scope3[i]) ,
																Total: 	 	emissionsReductionBySource[obj.source].Total.map((d,i) => d + obj.emissionsReduction.Total[i]) ,
															}
														}
													}
													// Initiate and record the emissions sinks by source												
													for( const obj of impactInflow){
														if(typeof emissionsSinksBySource[obj.source] === 'undefined'){
															emissionsSinksBySource[obj.source] = {
																Scope1: 	 Array(dataModel.schema.modelHorizon).fill(0),
																Scope2: 	 Array(dataModel.schema.modelHorizon).fill(0),
																Scope3:  	 Array(dataModel.schema.modelHorizon).fill(0),
																Total: 	 	 Array(dataModel.schema.modelHorizon).fill(0),
															}
														}
														emissionsSinksBySource[obj.source] = {
															Scope1: 	emissionsSinksBySource[obj.source].Scope1.map((d,i) => d + obj.emissionsSinks.Scope1[i]) ,
															Scope2: 	emissionsSinksBySource[obj.source].Scope2.map((d,i) => d + obj.emissionsSinks.Scope2[i] ) ,
															Scope3:  	emissionsSinksBySource[obj.source].Scope3.map((d,i) => d + obj.emissionsSinks.Scope3[i]) ,
															Total: 	 	emissionsSinksBySource[obj.source].Total.map((d,i) => d + obj.emissionsSinks.Total[i]) ,
														}
													}

											// II. ADD OBJECT IMPACT DATA										
												model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID] = {
													actionName: 					actionParameters.meta.label,
													impactStatus: 					true,
													impact: {
														outflow: 					impactOutflow,
														inflow: 					impactInflow,
														emissionsRedExSinks: 		emissionsRedExSinks,
														emissionsSinks: 			emissionsSinks,
														emissionsSinksBySource: 	emissionsSinksBySource,
														emissionsGrossReduction: 	emissionsGrossReduction,
														emissionsReduction: 		emissionsReduction,
														emissionsReductionBySource: emissionsReductionBySource,
														emissionsNew:  				emissionsNew,
														reducedNaturalVolume: 		reducedNaturalVolume,
														addedNaturalVolume: 		switchToNaturalVolume,
														byActivity: {
															outflow: 					activityOutflowImpact,
															inflow: 					activityInflowImpact
														}
													}
												}

											// III. MODEL AND ADD THE BUSINESS CASE FOR ONE SITE	
												const refCaseFromNaturalVol 		= [...new Set(referenceCaseFrom.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													refCaseFromSiteCount 			= d3.max([...new Set(referenceCaseFrom.map(obj => obj.siteNames))].map(d => d.length)),
													targetUptake 					= rebuild ? actionSettings.opportunity.targetUptake : actionParameters.opportunity[sitegroup].targetUptake, 
													agencyIndexOfCustomSiteData 	= data.siteDataSitegroupByAgency.map(d => d.key).indexOf(agency),
													actionSource 					= actionParameters.impact.from[0].source,
													actionType 						= actionParameters.impact.type,
													actionAsset 					= actionParameters.impact.asset,
													customSiteDataSitegroup 		= agencyIndexOfCustomSiteData > -1 ? data.siteDataSitegroupByAgency[agencyIndexOfCustomSiteData].value[sitegroup] : null,
													customSiteCount 				= customSiteDataSitegroup ? customSiteDataSitegroup[actionSource] : null,
													totalNoSites 					= customSiteCount ? customSiteCount :  refCaseFromSiteCount,
													noSites 						= sitegroup === 'All of agency' ? 1 : totalNoSites * targetUptake,
													avoidedCostBySource 			=  d3.nest().key(d => d.source).entries(impactOutflow).map( d => {  
																						return { [d.key] :  d.values.map(d=> d.costSaving).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
																											 .slice(0, rebuild ? actionSettings.economicLife : actionParameters.meta.life) 
																											.map( d => targetUptake === 0 ? 0 : d / noSites) }
																					}),
													ouflowCostSavings 				= impactOutflow.map(obj => obj.costSaving).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
													avoidedCost 					= ouflowCostSavings.slice(0, rebuild ? actionSettings.economicLife : actionParameters.meta.life).map( d => targetUptake === 0 || noSites === 0 ? 0 : d / noSites),
													additionalCost					= impactInflow.length > 0 ?	impactInflow[0].cost.slice(0, rebuild ? actionSettings.economicLife : actionParameters.meta.life).map( d => noSites === 0 ? 0 : d / noSites) :  Array(dataModel.schema.modelHorizon).fill(0),
													revenueByInflow 				= impactInflow.length > 0 ?	Array(rebuild ? actionSettings.economicLife :
																			 			actionParameters.meta.life).fill(0) : impactInflow.map(obj => obj.benefit).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []).slice(0, rebuild ? actionSettings.economicLife : actionParameters.meta.life).map( d =>  d / noSites),													
													baselineVolPerSite 				=  sitegroup === 'All of agency' ?  sitegroup === 'All of agency' : refCaseFromNaturalVol.map( d => d / totalNoSites)[0],
													capitalCost						= Array(rebuild ? actionSettings.economicLife : actionParameters.meta.life).fill(0)

												let omCost 							= Array(rebuild ? actionSettings.economicLife : actionParameters.meta.life).fill(0),
													capitalCostPerSite 				= 0,			
													omCostPerSite 					= 0,	
													netCashFlow

												// Create cash flow based on what is defined: Capital and OM 
												if(!rebuild){
													switch(actionParameters.impact.type){
														case 'efficiency':														
														case 'reduction':														
															actionParameters.cost.capitalCost.unitCostBythreshold.forEach(costObj => {
																if(totalActivityPropBySource[sourceFrom] * baselineVolPerSite >= costObj.above){
																	const roundedCapitalCost = Math.round(costObj.costPerUnit * totalActivityPropBySource[sourceFrom] * baselineVolPerSite / 100) *100															
																	capitalCostPerSite = roundedCapitalCost
																	capitalCost[0] = roundedCapitalCost * targetUptake
																}																						
															})									
															actionParameters.cost.omCost.unitCostBythreshold.forEach(costObj => {
																if(baselineVolPerSite * totalActivityPropBySource[sourceFrom] >= costObj.above){
																	const roundedOmCost = Math.round(costObj.costPerUnit * totalActivityPropBySource[sourceFrom] * baselineVolPerSite / 10) * 10
																	omCostPerSite = roundedOmCost
																	omCost = Array(actionParameters.meta.life).fill(roundedOmCost * targetUptake)
																} 
															})		
															break

														case 'switch':	
															actionParameters.cost.capitalCost.unitCostBythreshold.forEach(costObj => {
																if(baselineVolPerSite >= costObj.above){
																	const roundedCapitalCost = Math.round(costObj.costPerUnit / 100) *100															
																	capitalCostPerSite = roundedCapitalCost
																	capitalCost[0] = roundedCapitalCost * targetUptake
																}																						
															})									
															actionParameters.cost.omCost.unitCostBythreshold.forEach(costObj => {
																if(baselineVolPerSite >= costObj.above){
																	const roundedOmCost = Math.round(costObj.costPerUnit / 10) * 10
																	omCostPerSite = roundedOmCost
																	omCost = Array(actionParameters.meta.life).fill(roundedOmCost)
																} 
															})
															break
														case 'generation':
															const capacityPerSite = rebuild ?  actionSettings.opportunity.sizekWPerSite : actionParameters.opportunity[sitegroup].sizekWPerSite 														
															actionParameters.cost.capitalCost.unitCostBythreshold.forEach(costObj => {																
																if(capacityPerSite >= costObj.above){
																	const roundedCapitalCost = Math.round(costObj.costPerUnit * capacityPerSite  / 100) * 100		
																	capitalCostPerSite = roundedCapitalCost
																	capitalCost[0] = roundedCapitalCost * targetUptake							
																}
															})
															actionParameters.cost.omCost.unitCostBythreshold.forEach(costObj => {
																if(capacityPerSite >= costObj.above){
																	const roundedOmCost = Math.round(costObj.costPerUnit * baselineVolPerSite / 10) * 10																	
																	omCostPerSite = roundedOmCost 																
																	omCost = Array(actionParameters.meta.life).fill(roundedOmCost * targetUptake)
																} 
															})
															break
														case 'offset':	

															break
													}

												} else {
													capitalCost[0]  = actionSettings.cost.capitalCost
													omCost = omCost.map(d => actionSettings.cost.omCost)
												}

												// Add avoided cost and revenue if they apply
												netCashFlow = capitalCost.map((d,i) => - d - omCost[i])												
												if(avoidedCost.length > 0){
													netCashFlow = netCashFlow.map( (d, i) => d + avoidedCost[i])
												}
												if(revenueByInflow.length > 0){
													netCashFlow = netCashFlow.map( (d, i) => d + revenueByInflow[i])
												}
												if(additionalCost.length > 0){
													netCashFlow = netCashFlow.map( (d, i) => d - additionalCost[i])
												}										

												const discountedCashFlow = netCashFlow.map( (d, i) =>  d / settings.parameters.financial["Discount factor"][i]),
													cumNetCF 	= netCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
													cumDCF 		= discountedCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
													npv 		= d3.sum(discountedCashFlow),
													abatementNPV = d3.sum(discountedNetEmissionsImpact.slice(0, actionParameters.meta.life).map(d => d / noSites)), 
													levelisedCost = (npv === 0 || abatementNPV === 0) ? 0 : -  npv / abatementNPV 

												model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID].businessCase = {
													"Cashflow items": 		{
														"Marginal capital cost": 						capitalCost,
														"Marginal operations and maintenance cost": 	omCost,
														"Additional cost": 								additionalCost,
														"Avoided cost": 								avoidedCost,
														"Avoided cost by source": 						avoidedCostBySource,
														"Revenue": 										revenueByInflow
													},
													"Net cash flow":	 								netCashFlow,
													"Discounted cash flow":								discountedCashFlow,
													"Cumulative cash flow": 							cumNetCF,
													"Cumulative DCF": 									cumDCF,
													"Emissions abatement": 								emissionsReduction.Total.slice(0, actionParameters.meta.life),
													"Natural volume abatement": 						reducedNaturalVolume.map(d => {return {[Object.keys(d)] : Object.values(d)[0].slice(0, actionParameters.meta.life)} }) ,
													"Natural volume new consumption (fuel switch)": 	switchToNaturalVolume.slice(0, actionParameters.meta.life),
													"Modelled tariffs":{
														"Added": 										actionParameters.impact.type.toLowerCase() === 'switch' ?  model.parameters.general[actionParameters.impact.to[0].price].value : null,
														"Added unit": 									actionParameters.impact.type.toLowerCase() === 'switch' ?  '$'+model.parameters.general[actionParameters.impact.to[0].price].unit : null,
														"Avoided": 										actionParameters.meta.sector === "Waste" ?  [Array(dataModel.schema.modelHorizon).fill(0)] : referenceCaseFrom.map(obj => obj.modelledTariff),
														"Avoided unit": 								referenceCaseFrom.map(obj => obj.tariffUnit),
														"Revenue": 										actionParameters.impact.type.toLowerCase() === 'generation' ? model.parameters.general.price_SolarFeedIn.value : null, 		// Only ever solar feedin so this is hard coded
														"Revenue unit": 								actionParameters.impact.type.toLowerCase() === 'generation' ? '$'+model.parameters.general.price_SolarFeedIn.unit : null, 	// and only accesssed for solar PV actions with export
													},
													"Metrics": {
														"NPV": 											npv,
														"IRR": 											helpers.IRR(netCashFlow, 0),
														"Simple payback": 								helpers.payback(cumNetCF, actionParameters.meta.life),
														"Discounted payback": 							helpers.payback(cumDCF, actionParameters.meta.life),
														"Levelised cost of abatement": 					levelisedCost,
														"abatementNPV": 								abatementNPV,
													}
												}

											// IV. INCREASE COUNTERS AND META INFO
												model.action.summaryCount.modelledActions += 1
												model.action.summaryCount[agency][sitegroup].noActions += 1
												model.action.summaryCount[agency][sitegroup].capitalCost += capitalCost[0]

											// IV. MODEL THE IMPACT UPTAKE: set default path and extend impact to model horizon		
												const uptakeArray = rebuild ? actionSettings.uptake : Array(dataModel.schema.modelHorizon).fill(1).map( (d, i) => i < actionParameters.uptake.length ? actionParameters.uptake[i] : d)		
												model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'] = {
													uptakePct: 				uptakeArray,
													reducedNaturalVolume: 	reducedNaturalVolume.map((d, i) => reducedNaturalVolume[actionParameters.meta.life] * uptakeArray[i]),
													addedNaturalVolume: 	switchToNaturalVolume.map((d, i) => d * uptakeArray[i]),
													emissionsRedExSinks: {
														Scope1: 			emissionsRedExSinks.Scope1.map((d, i) => d * uptakeArray[i] ),
														Scope2: 			emissionsRedExSinks.Scope2.map((d, i) => d * uptakeArray[i] ),
														Scope3: 			emissionsRedExSinks.Scope3.map((d, i) => d * uptakeArray[i] ),
														Total: 				emissionsRedExSinks.Total.map((d, i) => d * uptakeArray[i] )
													},
													emissionsSinks: {
														Scope1: 			emissionsSinks.Scope1.map((d, i) => d * uptakeArray[i] ),
														Scope2: 			emissionsSinks.Scope2.map((d, i) => d * uptakeArray[i] ),
														Scope3: 			emissionsSinks.Scope3.map((d, i) => d * uptakeArray[i] ),
														Total: 				emissionsSinks.Total.map((d, i) => d * uptakeArray[i] )
													},	
													emissionsReduction: {
														Scope1: 			emissionsReduction.Scope1.map((d, i) => d * uptakeArray[i] ),
														Scope2: 			emissionsReduction.Scope2.map((d, i) => d * uptakeArray[i] ),
														Scope3: 			emissionsReduction.Scope3.map((d, i) => d * uptakeArray[i] ),
														Total: 				emissionsReduction.Total.map((d, i) => d * uptakeArray[i] )
													},
													emissionsNew: {
														Scope1: 			emissionsNew.Scope1.map((d, i) => d * uptakeArray[i] ),
														Scope2: 			emissionsNew.Scope2.map((d, i) => d * uptakeArray[i] ),
														Scope3: 			emissionsNew.Scope3.map((d, i) => d * uptakeArray[i] ),
														Total: 				emissionsNew.Total.map((d, i) => d * uptakeArray[i] )
													},
													emissionsReductionBySource: {},
													emissionsSinksBySource: {},
													reducedNaturalVolume: 	reducedNaturalVolume.map(d => {return {[Object.keys(d)] : Object.values(d)[0].map((d, i) => d * uptakeArray[i])} })  ,
													noSites: 				noSites
												}	

												Object.entries(emissionsReductionBySource).forEach(([source, obj]) => {
													model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'].emissionsReductionBySource[source] = {
															Scope1: 		obj.Scope1.map((d, i) => d * uptakeArray[i]),
															Scope2: 		obj.Scope2.map((d, i) => d * uptakeArray[i]),
															Scope3: 		obj.Scope3.map((d, i) => d * uptakeArray[i]),
															Total: 			obj.Total.map((d, i) => d * uptakeArray[i]),
														}
													}
												)
												Object.entries(emissionsSinksBySource).forEach(([source, obj]) => {
													model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'].emissionsSinksBySource[source] = {
															Scope1: 		obj.Scope1.map((d, i) => d * uptakeArray[i]),
															Scope2: 		obj.Scope2.map((d, i) => d * uptakeArray[i]),
															Scope3: 		obj.Scope3.map((d, i) => d * uptakeArray[i]),
															Total: 			obj.Total.map((d, i) => d * uptakeArray[i]),
														}
													}
												)

											// VI. CREATE ACTION MODEL SETTINGS OBJECT																			
												if(!rebuild){	
													settings.action.byAgency_sitegroup[agency][sitegroup][actionID] = {
														cost:{
															capitalCost: 		+capitalCostPerSite,
															omCost:				+omCostPerSite
														},
														economicLife: 			+actionParameters.meta.life,				
														opportunity:  			JSON.parse(JSON.stringify(actionParameters.opportunity[sitegroup])), 	
														reductionPct: 			(actionParameters.impact.type !=='generation' && actionParameters.impact.type !=='offset') 
																					? actionParameters.impact.from[0].reductionByActivity[0].reductionPct 	// Take first specified pct reduction
																					: actionParameters.impact.type ==='generation' ? null  :1,   	// Set at null for generation and 1 for offset
														uptake:  				uptakeArray.map(d => d),
														uptakePreset: 			actionParameters.uptakePreset,
														uptakeTotalSites: 		noSites,
														userUpdated: 			false
													}	
												}
										}
									}
								} 
							})
						})
					})
					break

				default:
				// Other cases may be added...
			}
			if(!rebuild) {console.log("..."+model.action.summaryCount.modelledActions+" actions modelled at sitegroup level across "+(Object.keys(model.action.summaryCount).length -1)+ " agencies") }
			else{
			console.log('Action models should have been rebuilt...')
		}
		// II. AGGREGATE ACTION MODELLING TO DISPLAY LEVELS OF  AGENCY, WHOLE OF GOV AND CLUSTER
			await aggregateActionModels(false)
	}; // end buildActionModels()


	// PART B-I. CALCULATE ACTION AND SWITCH TO CASE INVENTORY
	async function buildActionAndSwitchToCase(rebuild = false){
		if(!rebuild){ console.log('**** 3B. BUILDING ACTION AND SWITCH TO CASEEMISSIONS PROFILE AT '+model.settings.actionModelLevel.toUpperCase()+' LEVEL ****') }
			else{ console.log('**** REBUILDING ACTION AND SWITCHTO CASE ***')}

		// 1. Initialise aggregate actionCase views
			// i. model.inventory.actionCase.summaryTotal 
			model.inventory.actionCase.summaryTotal =  new Object()
			await initCaseObj(model.inventory.actionCase.summaryTotal, dataModel.schema.modelHorizon)
			// ii. model.inventory.actionCase.bySectorSource | model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume
			Object.keys(model.inventory.referenceCase.bySectorSource).forEach( sector => {
				model.inventory.actionCase.bySectorSource[sector] = {}
				model.inventory.actionCase.bySitegroup[sector] = {}
				Object.keys(model.inventory.referenceCase.bySectorSource[sector]).forEach( source => {
					model.inventory.actionCase.bySectorSource[sector][source] = new Object()
					initCaseObj(model.inventory.actionCase.bySectorSource[sector][source], dataModel.schema.modelHorizon)
					model.inventory.actionCase.bySectorSource[sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
					model.inventory.actionCase.bySectorSource[sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
					model.inventory.actionCase.bySectorSource[sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
					if( typeof model.inventory.referenceCase.bySitegroup[sector][source] !== 'undefined'){
					 	model.inventory.actionCase.bySitegroup[sector][source] = {}					
						Object.keys(model.inventory.referenceCase.bySitegroup[sector][source]).forEach( sitegroup => {
							model.inventory.actionCase.bySitegroup[sector][source][sitegroup] = new Object()
							initCaseObj(model.inventory.actionCase.bySitegroup[sector][source][sitegroup] , dataModel.schema.modelHorizon)
							model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
							model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
							model.inventory.actionCase.bySitegroup[sector][source][sitegroup].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit						
						})
					}
				})
			})
			// iii. model.inventory.actionCase.byCluster 
			Object.keys(model.inventory.referenceCase.byCluster).forEach( cluster => {
				model.inventory.actionCase.byCluster[cluster] = {}
				Object.keys(model.inventory.referenceCase.byCluster[cluster]).forEach(sector => {
					model.inventory.actionCase.byCluster[cluster][sector] = {}
					Object.keys(model.inventory.referenceCase.byCluster[cluster][sector]).forEach(source => {
						model.inventory.actionCase.byCluster[cluster][sector][source] = new Object()
						initCaseObj(model.inventory.actionCase.byCluster[cluster][sector][source] , dataModel.schema.modelHorizon)
						model.inventory.actionCase.byCluster[cluster][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.actionCase.byCluster[cluster][sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
						model.inventory.actionCase.byCluster[cluster][sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
					})
				})
			})			
			// iv. model.inventory.actionCase.byCluster_agency_sitegroup
			Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup).forEach( cluster => {
				model.inventory.actionCase.byCluster_agency_sitegroup[cluster] = {}
				Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster]).forEach(agency => {
					model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency] = {}
					Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency]).forEach(sitegroup => {
						model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup] = {}
						Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup]).forEach(sector => {
							model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector] = {}
							Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector]).forEach(source => {
								model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source] = new Object()
								initCaseObj(model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source], dataModel.schema.modelHorizon)
								model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
								model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
								model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
							})
						})
					})
				})
			})
			// v. model.inventory.actionCase.byAgency
			Object.keys(model.inventory.referenceCase.byAgency).forEach(agency => {
				model.inventory.actionCase.byAgency[agency] = {}
				Object.keys(model.inventory.referenceCase.byAgency[agency]).forEach(sector => {
					model.inventory.actionCase.byAgency[agency][sector] = {}
					Object.keys(model.inventory.referenceCase.byAgency[agency][sector]).forEach(source => {
						model.inventory.actionCase.byAgency[agency][sector][source] = new Object()
						initCaseObj(model.inventory.actionCase.byAgency[agency][sector][source], dataModel.schema.modelHorizon)
						model.inventory.actionCase.byAgency[agency][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.actionCase.byAgency[agency][sector][source].naturalUnit   = model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
						model.inventory.actionCase.byAgency[agency][sector][source].tariffUnit 	  = model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit						
					})
				})
			})
	
		// 2. Initialise aggregate switchToCase views
			// i. model.inventory.switchToCase.summaryTotal 
			model.inventory.switchToCase.summaryTotal =  new Object()
			await initCaseObj(model.inventory.switchToCase.summaryTotal, dataModel.schema.modelHorizon)
			// ii. model.inventory.actionCase.bySectorSource | model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume
			Object.keys(model.inventory.referenceCase.bySectorSource).forEach( sector => {
				model.inventory.switchToCase.bySectorSource[sector] = {}
				model.inventory.switchToCase.bySitegroup[sector] = {}
				Object.keys(model.inventory.referenceCase.bySectorSource[sector]).forEach( source => {
					model.inventory.switchToCase.bySectorSource[sector][source] = new Object()
					initCaseObj(model.inventory.switchToCase.bySectorSource[sector][source], dataModel.schema.modelHorizon)
					model.inventory.switchToCase.bySectorSource[sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
					model.inventory.switchToCase.bySectorSource[sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
					model.inventory.switchToCase.bySectorSource[sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
					if( typeof model.inventory.referenceCase.bySitegroup[sector][source] !== 'undefined'){
					 	model.inventory.switchToCase.bySitegroup[sector][source] = {}					
						Object.keys(model.inventory.referenceCase.bySitegroup[sector][source]).forEach( sitegroup => {
							model.inventory.switchToCase.bySitegroup[sector][source][sitegroup] = new Object()
							initCaseObj(model.inventory.switchToCase.bySitegroup[sector][source][sitegroup] , dataModel.schema.modelHorizon)
							model.inventory.switchToCase.bySitegroup[sector][source][sitegroup].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
							model.inventory.switchToCase.bySitegroup[sector][source][sitegroup].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
							model.inventory.switchToCase.bySitegroup[sector][source][sitegroup].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit						
						})
					}
				})
			})
			// iii. model.inventory.switchToCase.byCluster 
			Object.keys(model.inventory.referenceCase.byCluster).forEach( cluster => {
				model.inventory.switchToCase.byCluster[cluster] = {}
				Object.keys(model.inventory.referenceCase.byCluster[cluster]).forEach(sector => {
					model.inventory.switchToCase.byCluster[cluster][sector] = {}
					Object.keys(model.inventory.referenceCase.byCluster[cluster][sector]).forEach(source => {
						model.inventory.switchToCase.byCluster[cluster][sector][source] = new Object()
						initCaseObj(model.inventory.switchToCase.byCluster[cluster][sector][source] , dataModel.schema.modelHorizon)
						model.inventory.switchToCase.byCluster[cluster][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.switchToCase.byCluster[cluster][sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
						model.inventory.switchToCase.byCluster[cluster][sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
					})
				})
			})			
			// iv. model.inventory.switchToCase.byCluster_agency_sitegroup
			Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup).forEach( cluster => {
				model.inventory.switchToCase.byCluster_agency_sitegroup[cluster] = {}
				Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster]).forEach(agency => {
					model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency] = {}
					Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency]).forEach(sitegroup => {
						model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup] = {}
						Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup]).forEach(sector => {
							model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector] = {}
							Object.keys(model.inventory.referenceCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector]).forEach(source => {
								model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source] = new Object()
								initCaseObj(model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source], dataModel.schema.modelHorizon)
								model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
								model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
								model.inventory.switchToCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].tariffUnit 	= model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit
							})
						})
					})
				})
			})
			// v. model.inventory.switchToCase.byAgency
			Object.keys(model.inventory.referenceCase.byAgency).forEach(agency => {
				model.inventory.switchToCase.byAgency[agency] = {}
				Object.keys(model.inventory.referenceCase.byAgency[agency]).forEach(sector => {
					model.inventory.switchToCase.byAgency[agency][sector] = {}
					Object.keys(model.inventory.referenceCase.byAgency[agency][sector]).forEach(source => {
						model.inventory.switchToCase.byAgency[agency][sector][source] = new Object()
						initCaseObj(model.inventory.switchToCase.byAgency[agency][sector][source], dataModel.schema.modelHorizon)
						model.inventory.switchToCase.byAgency[agency][sector][source].naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.switchToCase.byAgency[agency][sector][source].naturalUnit   = model.inventory.referenceCase.bySectorSource[sector][source].naturalUnit
						model.inventory.switchToCase.byAgency[agency][sector][source].tariffUnit 	  = model.inventory.referenceCase.bySectorSource[sector][source].tariffUnit						
					})
				})
			})
	
		// 3. Build actionCase and switchToCase profiles
			// Sequence to build and aggregate actionCase
			await buildAgencySitegroupActionCase() 			// Determine actionCase 
			await buildAgencySitegroupSwitchToCase() 		// Determine switchTo case and add it to the actionCase

			await buildSummaryActionCase() 					// Aggreagtes summary level actionCases
			await allocateSolar()
			console.log('Action and swtichTo case built...')

				// A. Build action case at Agency-site-group level
				async function buildAgencySitegroupActionCase(){
					for( const agency of Object.keys(model.inventory.referenceCase.byAgency_sitegroup)) {
						model.inventory.actionCase.byAgency_sitegroup[agency] = {}
						for( const sitegroup of Object.keys(model.inventory.referenceCase.byAgency_sitegroup[agency])) {
							model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup] = {}
							for( const sector of Object.keys(model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup])) {
								model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector] = {}
								const sectorRefData = model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][sector]
								// FOR EACH SECTOR OF AN AGENCY-SITEGROUP (WITH REFERENCE CASE DATA)
								if(Object.keys(sectorRefData).length > 0){ 
									for( const source of Object.keys(sectorRefData)) {
										// Get impact and net cash flow from all actions matching the SOURCE: Initialise all to 0 
										const sourceRefData = sectorRefData[source],
											actionAgencySitegroupData = model.action.businessCase.byAgency_sitegroup[agency][sitegroup]
										let	sourceEmissionsReduction = { // Iniitate as zero for each source: This is the impact
												Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
												Total:  			Array(dataModel.schema.modelHorizon).fill(0)
											},
											sourceEmissionsSinks  = {
												Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
												Total:  			Array(dataModel.schema.modelHorizon).fill(0)
											},
											sourceNetEmissions  = {
												Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
												Total:  			Array(dataModel.schema.modelHorizon).fill(0)
											},
											actionFinancials = {
												avoidedCost:  		Array(dataModel.schema.modelHorizon).fill(0),
												additionalCost:  	Array(dataModel.schema.modelHorizon).fill(0),
												capitalCost:   		Array(dataModel.schema.modelHorizon).fill(0),
												omCost: 			Array(dataModel.schema.modelHorizon).fill(0),
												revenue:		 	Array(dataModel.schema.modelHorizon).fill(0)									
											},				
										 	sourceNaturalVolReduction 	= Array(dataModel.schema.modelHorizon).fill(0), 											
											sourceNaturalVolIncrease 	= Array(dataModel.schema.modelHorizon).fill(0),
											netCashFlow 				= Array(dataModel.schema.modelHorizon).fill(0) 

										// Loop through all actions to impact IF the action reduces the the source ...
										for( const actionID of Object.keys(actionAgencySitegroupData)) {	
											const actionParameters 		= model.action.parameters[actionID],
												impactFromSourceList 	= actionParameters.impact.from,
												actionNetCashFlow 		= actionAgencySitegroupData[actionID].businessCase["Net cash flow"],
												actionCFItems 			= actionAgencySitegroupData[actionID].businessCase["Cashflow items"],
												uptakeSettings 			= settings.action.byAgency_sitegroup[agency][sitegroup][actionID].uptake
											// .. by iterating through each source reduced and matching to the source being aggregated
											for( const impactFromSource of impactFromSourceList){
												if(source === impactFromSource.source){  // Only interested in the desired sources component
													// Check arrays of reducedNatural volume and add only matched sources: ensures sourceNaturalVolReduction only contains the correct source
													for( const obj of actionAgencySitegroupData[actionID].impact.reducedNaturalVolume){
														if(Object.keys(obj)[0] === source){	
															sourceNaturalVolReduction 	= sourceNaturalVolReduction.map((d, i) => d + Object.values(obj)[0][i])
														}
													}													
													sourceNaturalVolIncrease 	= sourceNaturalVolIncrease.map((d, i) => d + actionAgencySitegroupData[actionID].impact.addedNaturalVolume[i])
													// Aggregate emisisons reduction and sinks (by source)
													if(typeof actionAgencySitegroupData[actionID].impact.emissionsReductionBySource[source] !== 'undefined'){
														sourceEmissionsReduction.Scope1 = sourceEmissionsReduction.Scope1.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsReductionBySource[source].Scope1[i] * uptakeSettings[i] )
														sourceEmissionsReduction.Scope2 = sourceEmissionsReduction.Scope2.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsReductionBySource[source].Scope2[i] * uptakeSettings[i] )
														sourceEmissionsReduction.Scope3 = sourceEmissionsReduction.Scope3.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsReductionBySource[source].Scope3[i] * uptakeSettings[i] )
														sourceEmissionsReduction.Total  = sourceEmissionsReduction.Total.map( (d, i)  =>  d + actionAgencySitegroupData[actionID].impact.emissionsReductionBySource[source].Total[i]  * uptakeSettings[i] )
													} 
													if(typeof actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source] !== 'undefined'){
														sourceEmissionsSinks.Scope1 = sourceEmissionsSinks.Scope1.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope1[i] * uptakeSettings[i] )
														sourceEmissionsSinks.Scope2 = sourceEmissionsSinks.Scope2.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope2[i] * uptakeSettings[i] )
														sourceEmissionsSinks.Scope3 = sourceEmissionsSinks.Scope3.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope3[i] * uptakeSettings[i] )
														sourceEmissionsSinks.Total  = sourceEmissionsSinks.Total.map( (d, i)  =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Total[i]  * uptakeSettings[i] )
													} 

													netCashFlow = netCashFlow.map((d, i) => d -  (i < actionNetCashFlow.length ? actionNetCashFlow[i] : actionNetCashFlow[actionNetCashFlow.length -1]) )  			// Cost saving is continued indefinitely for accumulated impact
													actionFinancials = {
														avoidedCost:  	actionFinancials.avoidedCost.map( (d, i) 	=> d + (actionCFItems['Avoided cost'].length > i ? actionCFItems['Avoided cost'][i] : 0 ) ),
														additionalCost: actionFinancials.additionalCost.map( (d, i) => d + (actionCFItems['Additional cost'].length > i ? actionCFItems['Additional cost'][i] : 0 ) ),
														capitalCost:   	actionFinancials.capitalCost.map( (d, i) 	=> d + (actionCFItems['Marginal capital cost'].length > i ? actionCFItems['Marginal capital cost'][i] : 0 )),
														omCost: 		actionFinancials.omCost.map( (d, i) 		=> d + (actionCFItems['Marginal operations and maintenance cost'].length > i ? actionCFItems['Marginal operations and maintenance cost'][i] : 0 )),
														revenue:		actionFinancials.revenue.map( (d, i) 		=> d + (actionCFItems['Revenue'].length > i ? actionCFItems['Revenue'][i] : 0 ))
													}	
												}	// End of targeted source IF statement
											} // End of sourcelist loop 

											// Update sinks (which relate to Grid electricity in this version source)
											if(typeof actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source] !== 'undefined'){
												sourceEmissionsSinks.Scope1 = sourceEmissionsSinks.Scope1.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope1[i] * uptakeSettings[i] )
												sourceEmissionsSinks.Scope2 = sourceEmissionsSinks.Scope2.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope2[i] * uptakeSettings[i] )
												sourceEmissionsSinks.Scope3 = sourceEmissionsSinks.Scope3.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Scope3[i] * uptakeSettings[i] )
												sourceEmissionsSinks.Total  = sourceEmissionsSinks.Total.map( (d, i)  =>  d + actionAgencySitegroupData[actionID].impact.emissionsSinksBySource[source].Total[i]  * uptakeSettings[i] )
											} 
										} // End of action loop

										// sourceEmissionsReduction now contains the source impact from every action in the agencySitegrup
										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source] = {
											cost: 						sourceRefData.cost.map((d, i) => d + netCashFlow[i] ), 			
											actionCFImpact:  			actionFinancials,
											siteNames: 					sourceRefData.siteNames,
											emissions: 	{		// Initiate as souceRefData 
												Scope1:					sourceRefData.emissions.Scope1.map((d, i) => d - sourceEmissionsReduction.Scope1[i] ),
												Scope2: 				sourceRefData.emissions.Scope2.map((d, i) => d - sourceEmissionsReduction.Scope2[i] ),
												Scope3: 				sourceRefData.emissions.Scope3.map((d, i) => d - sourceEmissionsReduction.Scope3[i] ),
												Total: 					sourceRefData.emissions.Total.map((d, i) => d - sourceEmissionsReduction.Total[i] )
											}, 
											emissionsSinks: 			sourceEmissionsSinks, 		 			// Action case zeros out sinks and reductions as these are represented in the actions themselves
											emissionsReduction: 		sourceEmissionsReduction, 				
											modelledTariff: 			sourceRefData.modelledTariff,
											naturalUnit: 				sourceRefData.naturalUnit,
											naturalVolume: 				sourceRefData.naturalVolume.map((d, i) => d - sourceNaturalVolReduction[i] + sourceNaturalVolIncrease[i]),
											tariffUnit: 				sourceRefData.tariffUnit
										}	

										/// Update the summaryTotal if there is a reduction 
											model.inventory.actionCase.summaryTotal.emissions.Scope1 = model.inventory.actionCase.summaryTotal.emissions.Scope1.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope1[i] )
											model.inventory.actionCase.summaryTotal.emissions.Scope2 = model.inventory.actionCase.summaryTotal.emissions.Scope2.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope2[i] )
											model.inventory.actionCase.summaryTotal.emissions.Scope3 = model.inventory.actionCase.summaryTotal.emissions.Scope3.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope3[i] )
											model.inventory.actionCase.summaryTotal.emissions.Total  = model.inventory.actionCase.summaryTotal.emissions.Total.map((d,i)  =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Total[i] )

											model.inventory.actionCase.summaryTotal.emissionsReduction.Scope1 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope1.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope1[i] )
											model.inventory.actionCase.summaryTotal.emissionsReduction.Scope2 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope2.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope2[i] )
											model.inventory.actionCase.summaryTotal.emissionsReduction.Scope3 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope3.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope3[i] )
											model.inventory.actionCase.summaryTotal.emissionsReduction.Total  = model.inventory.actionCase.summaryTotal.emissionsReduction.Total.map((d,i)  =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Total[i] )											

											model.inventory.actionCase.summaryTotal.emissionsSinks.Scope1 = model.inventory.actionCase.summaryTotal.emissionsSinks.Scope1.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope1[i] )
											model.inventory.actionCase.summaryTotal.emissionsSinks.Scope2 = model.inventory.actionCase.summaryTotal.emissionsSinks.Scope2.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope2[i] )
											model.inventory.actionCase.summaryTotal.emissionsSinks.Scope3 = model.inventory.actionCase.summaryTotal.emissionsSinks.Scope3.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope3[i] )
											model.inventory.actionCase.summaryTotal.emissionsSinks.Total = model.inventory.actionCase.summaryTotal.emissionsSinks.Total.map((d,i) =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Total[i] )

											if(model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].cost.length > 0){
												model.inventory.actionCase.summaryTotal.cost = model.inventory.actionCase.summaryTotal.cost.map((d,i)  =>  d + model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].cost[i] )		
											}	
									} // End of adding action to actionCase.byAgency_sitegroup
								}
							}
						}
					}
				}; // End buildAgencySitegroupActionCase()

				// B. Build switchTo case at Agency-site-group level
				async function buildAgencySitegroupSwitchToCase(){
					for( const agency of Object.keys(model.inventory.switchToCase.byAgency_sitegroup)) {
						for( const sitegroup of Object.keys(model.inventory.switchToCase.byAgency_sitegroup[agency])) {
							for( const sector of Object.keys(model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup])) {
								const sectorSwitchToData = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector]
								// FOR EACH SECTOR OF AN AGENCY-SITEGROUP 
								if(Object.keys(sectorSwitchToData).length > 0){ 
									for( const source of Object.keys(sectorSwitchToData)) {
										// Get impact and net cash flow from all actions matching the SOURCE: Initialise all to 0 
										const sourceSwitchToData = sectorSwitchToData[source],
											actionAgencySitegroupData = model.action.businessCase.byAgency_sitegroup[agency][sitegroup],
											sourceEmissionsNew = { // Iniitate as zero for each source: This is the impact
												Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
												Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
												Total:  			Array(dataModel.schema.modelHorizon).fill(0)
											}													
										
										let	sourceNaturalVolIncrease 	= Array(dataModel.schema.modelHorizon).fill(0)

										sourceSwitchToData.emissions =  { // Iniitate as zero for each source: This is the impact
											Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
											Total:  			Array(dataModel.schema.modelHorizon).fill(0)
										}		
										sourceSwitchToData.naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)

										// Loop through all SWITCH actions for a source and aggregate impacts...
										for( const actionID of Object.keys(actionAgencySitegroupData)) {	
											const actionParameters 		= model.action.parameters[actionID],
												impactToSource 			= typeof(actionParameters.impact.to[0]) !== 'undefined' ? actionParameters.impact.to[0].source : null,
												uptakeSettings 			= settings.action.byAgency_sitegroup[agency][sitegroup][actionID].uptake

											if(actionParameters.impact.type === 'switch' && impactToSource && source === impactToSource){
												sourceNaturalVolIncrease 	= sourceNaturalVolIncrease.map((d, i) => d + actionAgencySitegroupData[actionID].impact.inflow[0].naturalVolume[i]  * uptakeSettings[i]  )
												sourceEmissionsNew.Scope1 = sourceEmissionsNew.Scope1.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsNew.Scope1[i] * uptakeSettings[i] )
												sourceEmissionsNew.Scope2 = sourceEmissionsNew.Scope2.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsNew.Scope2[i] * uptakeSettings[i] )
												sourceEmissionsNew.Scope3 = sourceEmissionsNew.Scope3.map( (d, i) =>  d + actionAgencySitegroupData[actionID].impact.emissionsNew.Scope3[i] * uptakeSettings[i] )
												sourceEmissionsNew.Total  = sourceEmissionsNew.Total.map( (d, i)  =>  d + actionAgencySitegroupData[actionID].impact.emissionsNew.Total[i]  * uptakeSettings[i] )
											}
										} // End of action loop

										// Update natural volume and emissions for switched to 
										model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].naturalVolume = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].naturalVolume.map((d,i) => d + sourceNaturalVolIncrease[i] )
										model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope1 = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope1.map((d,i) => d + sourceEmissionsNew.Scope1[i] )
										model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope2 = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope2.map((d,i) => d + sourceEmissionsNew.Scope2[i] )
										model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope3 = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope3.map((d,i) => d + sourceEmissionsNew.Scope3[i] )
										model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Total = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Total.map((d,i) => d + sourceEmissionsNew.Total[i] )
										// Update the summaryTotal for actionCase
										model.inventory.actionCase.summaryTotal.emissionsReduction.Scope1 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope1.map((d,i) =>  d + model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope1[i] )
										model.inventory.actionCase.summaryTotal.emissionsReduction.Scope2 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope2.map((d,i) =>  d + model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope2[i] )
										model.inventory.actionCase.summaryTotal.emissionsReduction.Scope3 = model.inventory.actionCase.summaryTotal.emissionsReduction.Scope3.map((d,i) =>  d + model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Scope3[i] )
										model.inventory.actionCase.summaryTotal.emissionsReduction.Total  = model.inventory.actionCase.summaryTotal.emissionsReduction.Total.map((d,i)  =>  d + model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissions.Total[i] )											
									} 
								}
							}
						}
					}
				}; // End buildAgencySitegroupSwitchToCase()

				// C. Extract summary level action cases (aand account for switchTo emissions)
				async function buildSummaryActionCase(){
					console.log('SUMMARISING THE ACTION CASE')
					for(const agency of Object.keys(model.inventory.referenceCase.byAgency)){
						const cluster = dataModel.schema.clusterMapping.agencyToCluster[agency]		
						for(const sector of Object.keys(model.inventory.referenceCase.byAgency[agency])){	
							for(const source of Object.keys(model.inventory.referenceCase.byAgency[agency][sector])){				
								const agencyData = model.inventory.actionCase.byAgency_sitegroup[agency]
								for(const sitegroup of Object.keys(model.inventory.referenceCase.byAgency_sitegroup[agency])){	
									const siteGroupData = typeof(model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector]) === 'undefined' 
										? null : model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source],
										switchToData = typeof(model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector]) === 'undefined' 
										? null : model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][sector][source]

									if(siteGroupData){	
										// Add to the model.inventory.actionCase.bySectorSource object										
										model.inventory.actionCase.bySectorSource[sector][source].cost 							= model.inventory.actionCase.bySectorSource[sector][source].cost.map((d, i) => d + siteGroupData.cost[i])
										model.inventory.actionCase.bySectorSource[sector][source].naturalVolume 				= model.inventory.actionCase.bySectorSource[sector][source].naturalVolume.map((d, i) => d + siteGroupData.naturalVolume[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope1 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope1.map((d, i) => d + siteGroupData.emissions.Scope1[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope2 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope2.map((d, i) => d + siteGroupData.emissions.Scope2[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope3 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope3.map((d, i) => d + siteGroupData.emissions.Scope3[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Total 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Total.map((d, i) => d + siteGroupData.emissions.Total[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope1 	= model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope1.map((d, i) => d + siteGroupData.emissionsReduction.Scope1[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope2 	= model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope2.map((d, i) => d + siteGroupData.emissionsReduction.Scope2[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope3 	= model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Scope3.map((d, i) => d + siteGroupData.emissionsReduction.Scope3[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Total 		= model.inventory.actionCase.bySectorSource[sector][source].emissionsReduction.Total.map((d, i) => d + siteGroupData.emissionsReduction.Total[i])									
										model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope1 		= model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope1.map((d, i) => d + siteGroupData.emissionsSinks.Scope1[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope2 		= model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope2.map((d, i) => d + siteGroupData.emissionsSinks.Scope2[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope3 		= model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Scope3.map((d, i) => d + siteGroupData.emissionsSinks.Scope3[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Total 			= model.inventory.actionCase.bySectorSource[sector][source].emissionsSinks.Total.map((d, i) => d + siteGroupData.emissionsSinks.Total[i])									
										// Add to model.inventory.actionCase.bySitegroup 
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].cost 						=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].cost.map((d, i) => d + siteGroupData.cost[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume 			=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume.map((d, i) => d + siteGroupData.naturalVolume[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope1 			=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope1.map((d, i) => d + siteGroupData.emissions.Scope1[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope2 			=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope2.map((d, i) => d + siteGroupData.emissions.Scope2[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope3 			=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope3.map((d, i) => d + siteGroupData.emissions.Scope3[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Total 			=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Total.map((d, i) => d + siteGroupData.emissions.Total[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope1 =  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope1.map((d, i) => d + siteGroupData.emissionsReduction.Scope1[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope2 =  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope2.map((d, i) => d + siteGroupData.emissionsReduction.Scope2[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope3 =  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Scope3.map((d, i) => d + siteGroupData.emissionsReduction.Scope3[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Total  =  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsReduction.Total.map((d, i) => d + siteGroupData.emissionsReduction.Total[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope1  	=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope1.map((d, i) => d + siteGroupData.emissionsSinks.Scope1[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope2  	=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope2.map((d, i) => d + siteGroupData.emissionsSinks.Scope2[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope3  	=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Scope3.map((d, i) => d + siteGroupData.emissionsSinks.Scope3[i])
										model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Total   	=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissionsSinks.Total.map((d, i) => d + siteGroupData.emissionsSinks.Total[i])
										// Add to model.inventory.actionCase.byAgency							
										model.inventory.actionCase.byAgency[agency][sector][source].cost 						= model.inventory.actionCase.byAgency[agency][sector][source].cost.map((d, i) => d + siteGroupData.cost[i])
										model.inventory.actionCase.byAgency[agency][sector][source].naturalVolume 				= model.inventory.actionCase.byAgency[agency][sector][source].naturalVolume.map((d, i) => d + siteGroupData.naturalVolume[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope1 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope1.map((d, i) => d + siteGroupData.emissions.Scope1[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope2 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope2.map((d, i) => d + siteGroupData.emissions.Scope2[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope3 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope3.map((d, i) => d + siteGroupData.emissions.Scope3[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Total 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Total.map((d, i) => d + siteGroupData.emissions.Total[i] )
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope1 	= model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope1.map((d, i) => d + siteGroupData.emissionsReduction.Scope1[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope2 	= model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope2.map((d, i) => d + siteGroupData.emissionsReduction.Scope2[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope3 	= model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Scope3.map((d, i) => d + siteGroupData.emissionsReduction.Scope3[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Total 	= model.inventory.actionCase.byAgency[agency][sector][source].emissionsReduction.Total.map((d, i) => d + siteGroupData.emissionsReduction.Total[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope1 		= model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope1.map((d, i) => d + siteGroupData.emissionsSinks.Scope1[i])	
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope2 		= model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope2.map((d, i) => d + siteGroupData.emissionsSinks.Scope2[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope3 		= model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Scope3.map((d, i) => d + siteGroupData.emissionsSinks.Scope3[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Total 		= model.inventory.actionCase.byAgency[agency][sector][source].emissionsSinks.Total.map((d, i) => d + siteGroupData.emissionsSinks.Total[i])	
										// Add to model.inventory.actionCase.byCluster		
										model.inventory.actionCase.byCluster[cluster][sector][source].cost 						= model.inventory.actionCase.byCluster[cluster][sector][source].cost.map((d, i) => d + siteGroupData.cost[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].naturalVolume 			= model.inventory.actionCase.byCluster[cluster][sector][source].naturalVolume.map((d, i) => d + siteGroupData.naturalVolume[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope1 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope1.map((d, i) => d + siteGroupData.emissions.Scope1[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope2 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope2.map((d, i) => d + siteGroupData.emissions.Scope2[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope3 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope3.map((d, i) => d + siteGroupData.emissions.Scope3[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Total 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Total.map((d, i) => d + siteGroupData.emissions.Total[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope1 = model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope1.map((d, i) => d + siteGroupData.emissionsReduction.Scope1[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope2 = model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope2.map((d, i) => d + siteGroupData.emissionsReduction.Scope2[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope3 = model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Scope3.map((d, i) => d + siteGroupData.emissionsReduction.Scope3[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Total 	= model.inventory.actionCase.byCluster[cluster][sector][source].emissionsReduction.Total.map((d, i) => d + siteGroupData.emissionsReduction.Total[i])	
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Scope1 	= model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Scope1.map((d, i) => d + siteGroupData.emissionsSinks.Scope1[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Scope2 	= model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Scope2.map((d, i) => d + siteGroupData.emissionsSinks.Scope2[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.scope3 	= model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Scope3.map((d, i) => d + siteGroupData.emissionsSinks.Scope3[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Total 		= model.inventory.actionCase.byCluster[cluster][sector][source].emissionsSinks.Total.map((d, i) => d + siteGroupData.emissionsSinks.Total[i])	
										// Add to model.inventory.actionCase.byCluster_agency_sitegroup			
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].cost 						= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].cost.map((d, i) => d + siteGroupData.cost[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume.map((d, i) => d + siteGroupData.naturalVolume[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope1 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope1.map((d, i) => d + siteGroupData.emissions.Scope1[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope2 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope2.map((d, i) => d + siteGroupData.emissions.Scope2[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope3 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope3.map((d, i) => d + siteGroupData.emissions.Scope3[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Total 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Total.map((d, i) => d + siteGroupData.emissions.Total[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope1 = model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope1.map((d, i) => d + siteGroupData.emissionsReduction.Scope1[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope2 = model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope2.map((d, i) => d + siteGroupData.emissionsReduction.Scope2[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope3 = model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Scope3.map((d, i) => d + siteGroupData.emissionsReduction.Scope3[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Total  = model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsReduction.Total.map((d, i) => d + siteGroupData.emissionsReduction.Total[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope1 	= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope1.map((d, i) => d + siteGroupData.emissionsSinks.Scope1[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope2 	= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope2.map((d, i) => d + siteGroupData.emissionsSinks.Scope2[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope3 	= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Scope3.map((d, i) => d + siteGroupData.emissionsSinks.Scope3[i])
										model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Total  	= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissionsSinks.Total.map((d, i) => d + siteGroupData.emissionsSinks.Total[i])
									}
									if(switchToData){	
										// Add to the model.inventory.actionCase.bySectorSource object										
										model.inventory.actionCase.bySectorSource[sector][source].naturalVolume 				= model.inventory.actionCase.bySectorSource[sector][source].naturalVolume.map((d, i) => d + switchToData.naturalVolume[i] )
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope1 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope1.map((d, i) => d + switchToData.emissions.Scope1[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope2 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope2.map((d, i) => d + switchToData.emissions.Scope2[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope3 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Scope3.map((d, i) => d + switchToData.emissions.Scope3[i])
										model.inventory.actionCase.bySectorSource[sector][source].emissions.Total 				= model.inventory.actionCase.bySectorSource[sector][source].emissions.Total.map((d, i) => d + switchToData.emissions.Total[i])
										// Add to model.inventory.actionCase.bySitegroup  *** NOT WORKING BUT NOT USED ***
										// model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume 		=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].naturalVolume.map((d, i) => d + switchToData.naturalVolume[i] )
										// model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope1 		=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope1.map((d, i) => d + switchToData.emissions.Scope1[i])
										// model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope2 		=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope2.map((d, i) => d + switchToData.emissions.Scope2[i])
										// model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope3 		=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Scope3.map((d, i) => d + switchToData.emissions.Scope3[i])
										// model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Total 		=  model.inventory.actionCase.bySitegroup[sector][source][sitegroup].emissions.Total.map((d, i) => d + switchToData.emissions.Total[i])
										// Add to model.inventory.actionCase.byAgency							
										model.inventory.actionCase.byAgency[agency][sector][source].naturalVolume 				= model.inventory.actionCase.byAgency[agency][sector][source].naturalVolume.map((d, i) => d + switchToData.naturalVolume[i] )
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope1 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope1.map((d, i) => d + switchToData.emissions.Scope1[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope2 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope2.map((d, i) => d + switchToData.emissions.Scope2[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope3 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Scope3.map((d, i) => d + switchToData.emissions.Scope3[i])
										model.inventory.actionCase.byAgency[agency][sector][source].emissions.Total 			= model.inventory.actionCase.byAgency[agency][sector][source].emissions.Total.map((d, i) => d + switchToData.emissions.Total[i])
										// Add to model.inventory.actionCase.byCluster	
										model.inventory.actionCase.byCluster[cluster][sector][source].naturalVolume 			= model.inventory.actionCase.byCluster[cluster][sector][source].naturalVolume.map((d, i) => d + switchToData.naturalVolume[i] )
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope1 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope1.map((d, i) => d + switchToData.emissions.Scope1[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope2 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope2.map((d, i) => d + switchToData.emissions.Scope2[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope3 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Scope3.map((d, i) => d + switchToData.emissions.Scope3[i])
										model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Total 			= model.inventory.actionCase.byCluster[cluster][sector][source].emissions.Total.map((d, i) => d + switchToData.emissions.Total[i])
										// Add to model.inventory.actionCase.byCluster_agency_sitegroup  *** NOT WORKING BUT NOT USED ***	
										// model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].naturalVolume.map((d, i) => d + switchToData.naturalVolume[i] )
										// model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope1 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope1.map((d, i) => d + switchToData.emissions.Scope1[i])
										// model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope2 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope2.map((d, i) => d + switchToData.emissions.Scope2[i])
										// model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope3 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Scope3.map((d, i) => d + switchToData.emissions.Scope3[i])
										// model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Total 			= model.inventory.actionCase.byCluster_agency_sitegroup[cluster][agency][sitegroup][sector][source].emissions.Total.map((d, i) => d + switchToData.emissions.Total[i])
									}
								}
							}
						}
					}
				}; // end buildSummaryActionCase()

				// D. RE-ALLOCATION OF GRID ABATEMENT TO SOLAR CONSUMED AND EXPORTED
				async function allocateSolar(){
					for( const agency of Object.keys(model.inventory.actionCase.byAgency_sitegroup)){ 	
						for( const sitegroup of Object.keys(model.inventory.actionCase.byAgency_sitegroup[agency])) {
							for( const sector of Object.keys(model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup])) {
								for( const source of Object.keys(model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector])) {
									if(source === 'Grid electricity'){
										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector]["Solar consumed"] = {}
										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector]["Solar exported"] = {}

										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector]["Solar consumed"].emissionsReduction = {
											Scope1: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope1.map(d => d),
											Scope2: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope2.map(d => d),
											Scope3: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Scope3.map(d => d),
											Total: 		model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction.Total.map(d => d)
										}
										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector]["Solar exported"].emissionsSinks = {
											Scope1: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope1.map(d => d),
											Scope2: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope2.map(d => d),
											Scope3: 	model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Scope3.map(d => d),
											Total: 		model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks.Total.map(d => d)
										}

										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsReduction = {
											Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
											Total:  			Array(dataModel.schema.modelHorizon).fill(0)						
										}
										model.inventory.actionCase.byAgency_sitegroup[agency][sitegroup][sector][source].emissionsSinks = {
											Scope1:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope2:  			Array(dataModel.schema.modelHorizon).fill(0),
											Scope3:  			Array(dataModel.schema.modelHorizon).fill(0),
											Total:  			Array(dataModel.schema.modelHorizon).fill(0)						
										}
									}
								}
							}
						}
					}
				}; // end allocateSolar()
				

		// x. Helper to initialise case data object
			async function initCaseObj(obj, length){
				obj.emissions = { 
					Scope1: 		Array(length).fill(0),
					Scope2: 		Array(length).fill(0),
					Scope3: 		Array(length).fill(0),
					Total: 			Array(length).fill(0)
				}					
				obj.emissionsReduction = { 
					Scope1: 		Array(length).fill(0),
					Scope2: 		Array(length).fill(0),
					Scope3: 		Array(length).fill(0),
					Total: 			Array(length).fill(0)
				}	
				obj.emissionsSinks = { 
					Scope1: 		Array(length).fill(0),
					Scope2: 		Array(length).fill(0),
					Scope3: 		Array(length).fill(0),
					Total: 			Array(length).fill(0)
				}											
				obj.cost = Array(length).fill(0)	
			};


	}; // end buildActionAndSwitchToCase()


	// PART B-II. AGGREGATE ACTION MODELS
	async function aggregateActionModels(reAggregate = true){
		if(reAggregate) { 
			await clear() 
		} else {
			await initialise() 
		}
		await aggregate()
		await updateMetrics()

		// 0. INITIALISE AGGREGATE OBJECTS: 
		async function initialise(){
			// i. Initialise Whole of Gov roll ups
			for (const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)){
				model.action.businessCase.byAgency_action[agency] = {}
				for (const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])){	
					if(typeof model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup] === 'undefined'){
						model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup] = {}	
					}
					for (const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])){	
						const actionParameters = model.action.parameters[actionID]						
						model.action.businessCase.byAgency_action[agency][actionID] = await returnNewBCobj(actionParameters.meta.life, actionParameters.meta.label)
						if(typeof model.action.businessCase.byWholeOfGov_sitegroup[sitegroup] === 'undefined'){
							model.action.businessCase.byWholeOfGov_sitegroup[sitegroup] = await returnNewBCobj(dataModel.schema.modelHorizon, sitegroup)
						}
						if(typeof model.action.businessCase.byWholeOfGov_action[actionID] === 'undefined'){
							model.action.businessCase.byWholeOfGov_action[actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
						}
						if(typeof model.action.businessCase.byWholeOfGov_sitegroup_action[actionID] === 'undefined'){
							model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
						}
					}
				}
			}
			// ii. Initialise byCluster by actionID and sitegroup
			for (const cluster of Object.keys(model.inventory.referenceCase.byCluster)) {
				for (const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
					const activeCluster = dataModel.schema.clusterMapping.agencyToCluster[agency]							
					if(typeof model.action.businessCase.byCluster_action[activeCluster] === 'undefined'){
						model.action.businessCase.byCluster_action[activeCluster] = {}
						model.action.businessCase.byCluster_sitegroup[activeCluster] = {}
						model.action.businessCase.byCluster_sitegroup_action[activeCluster] = {}							
					}
					for (const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {						
						if(typeof model.action.businessCase.byCluster_sitegroup[activeCluster][sitegroup] === 'undefined'){
							model.action.businessCase.byCluster_sitegroup[activeCluster][sitegroup ] = await returnNewBCobj( dataModel.schema.modelHorizon, sitegroup)	
							model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup] = {}	
						}
						for (const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {	
							const actionParameters = model.action.parameters[actionID]	
							if(typeof model.action.businessCase.byCluster_action[activeCluster][actionID] === 'undefined'){							
								model.action.businessCase.byCluster_action[activeCluster][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
							}
							if(typeof model.action.businessCase.byCluster_action[activeCluster][actionID] === 'undefined'){							
								model.action.businessCase.byCluster_action[activeCluster][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
							}
							if(typeof model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup][actionID]  === 'undefined'){					
								model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
							}
						}
					}
				}
			}	
		};

		// 1. CLEAR EXISTING AGGREGATE OBJECTS
		async function clear(){
			// i. Clear model.action.businessCase.byAgency_action
			for (const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
				for (const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {				
					for (const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {				
						const actionParameters = model.action.parameters[actionID]				
						model.action.businessCase.byAgency_action[agency][actionID] = await returnNewBCobj(actionParameters.meta.life, actionParameters.meta.label)
						if(typeof model.action.businessCase.byWholeOfGov_sitegroup[sitegroup] !== 'undefined'){
							model.action.businessCase.byWholeOfGov_sitegroup[sitegroup] = await returnNewBCobj(dataModel.schema.modelHorizon, sitegroup)
						}
						if(typeof model.action.businessCase.byWholeOfGov_action[actionID] !== 'undefined'){
							model.action.businessCase.byWholeOfGov_action[actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
						}
						if(typeof model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID] !== 'undefined'){
							model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
						}
					}
				}
			}
			// ii. Clear byCluster and byWholeOfGov by actionID and sitegroup
			for (const cluster of Object.keys(model.inventory.referenceCase.byCluster)) {
				for (const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
					const activeCluster = dataModel.schema.clusterMapping.agencyToCluster[agency]
					for (const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {																							
						model.action.businessCase.byCluster_sitegroup[activeCluster][sitegroup ] = await returnNewBCobj( dataModel.schema.modelHorizon, sitegroup)	
						for (const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {		
							const actionParameters = model.action.parameters[actionID]									
							model.action.businessCase.byCluster_action[activeCluster][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
							model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup][actionID] = await returnNewBCobj(dataModel.schema.modelHorizon, actionParameters.meta.label)	
						}
					}
				}
			}
		};	

		// 2. Aggregate business case items via summation
		async function aggregate(){
			for (const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
				const activeCluster = dataModel.schema.clusterMapping.agencyToCluster[agency]	
				for (const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {	
					for (const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {	
						const actionData = model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID],	
						 	actionSettings = settings.action.byAgency_sitegroup[agency][sitegroup][actionID]

						await aggregateOBJ(model.action.businessCase.byAgency_action[agency][actionID], 		actionData, actionSettings)						// i. Aggregate byAgency_action							
						await aggregateOBJ(model.action.businessCase.byWholeOfGov_action[actionID], 			actionData, actionSettings)						// ii. Aggregate byWholeOfGov_action 			 						
						await aggregateOBJ(model.action.businessCase.byWholeOfGov_sitegroup[sitegroup], 		actionData, actionSettings)						// iii. Aggregate byWholeOfGov_sitegroup	

						// if( typeof model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID] !== 'undefined'){
						// // NOT WORKING		
						// 	await aggregateOBJ(model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID], 	actionData, actionSettings)		// iv. Aggregate byWholeOfGov_sitegroup_action											
						// }						
						// if(typeof model.action.businessCase.byCluster_action[activeCluster][actionID] !== 'undefined') {
						// // NOT WORKING								
						// 	await aggregateOBJ(model.action.businessCase.byCluster_action[activeCluster][actionID], 	actionData, actionSettings)				// v. Aggregate byCluster_action						
						// }
						// if(typeof model.action.businessCase.byCluster_sitegroup[activeCluster][sitegroup] !== 'undefined') {
						// // NOT WORKING						
						// 	await aggregateOBJ(model.action.businessCase.byCluster_sitegroup[activeCluster][sitegroup], 	actionData, actionSettings)			// vi. Aggregate byCluster_sitegroup
						// }	
						// if(typeof model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup][actionID] !== 'undefined') {				
						// // SEEMS OK
						// 	await aggregateOBJ(model.action.businessCase.byCluster_sitegroup_action[activeCluster][sitegroup][actionID], 	actionData, actionSettings)	// vii. Aggregate byCluster_sitegroup_action
						// }	
					}
				}
			}
		}	

		// 3. Calculate business case metrics
		async function updateMetrics(){
			// i. model.action.businessCase.byAgency_action
			for( const agency of Object.keys(model.action.businessCase.byAgency_action)) {
				for( const actionID of Object.keys(model.action.businessCase.byAgency_action[agency])){
					const bcObject 	= model.action.businessCase.byAgency_action[agency][actionID], length  = model.action.parameters[actionID].meta.life
					await recalcMetrics(bcObject, length)
				}
			}
			// ii. model.action.businessCase.byWholeOfGov_action
			for( const actionID of Object.keys(model.action.businessCase.byWholeOfGov_action)) {
				const bcObject 	= model.action.businessCase.byWholeOfGov_action[actionID], length  = model.action.parameters[actionID].meta.life
				await recalcMetrics(bcObject, length)
			}
			// iii. model.action.businessCase.byWholeOfGov_sitegroup_action
			for( const sitegroup of Object.keys(model.action.businessCase.byWholeOfGov_sitegroup_action)){
				for( const actionID of Object.keys(model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup])) {
					const bcObject 	= model.action.businessCase.byWholeOfGov_sitegroup_action[sitegroup][actionID], length  = model.action.parameters[actionID].meta.life
					await recalcMetrics(bcObject, length)
				}
			}
			// iv. model.action.businessCase.byWholeOfGov_sitegroup
			for( const sitegroup of Object.keys(model.action.businessCase.byWholeOfGov_sitegroup)){
				const bcObject 	= model.action.businessCase.byWholeOfGov_sitegroup[sitegroup], length = dataModel.schema.modelHorizon
				await recalcMetrics(bcObject, length)
			}
			// v. model.action.businessCase.byCluster_action
			for( const cluster of Object.keys(model.action.businessCase.byCluster_action)) {
				for( const actionID of Object.keys(model.action.businessCase.byCluster_action[cluster])) {
					const bcObject 	= model.action.businessCase.byCluster_action[cluster][actionID], length  = model.action.parameters[actionID].meta.life
					await recalcMetrics(bcObject, length)
				}
			}
			// vi. model.action.businessCase.byCluster_sitegroup
			for( const cluster of Object.keys(model.action.businessCase.byCluster_sitegroup)){
				for( const sitegroup of Object.keys(model.action.businessCase.byCluster_sitegroup[cluster])) {
					const bcObject 	= model.action.businessCase.byCluster_sitegroup[cluster][sitegroup], length = dataModel.schema.modelHorizon
					await recalcMetrics(bcObject, length)
				}
			}
			// vii model.action.businessCase.byCluster_sitegroup_action
			for( const cluster of Object.keys(model.action.businessCase.byCluster_sitegroup_action)){
				for( const sitegroup of Object.keys(model.action.businessCase.byCluster_sitegroup_action[cluster])) {
					for( const actionID of Object.keys(model.action.businessCase.byCluster_sitegroup_action[cluster][sitegroup])) {
						const bcObject 	= model.action.businessCase.byCluster_sitegroup_action[cluster][sitegroup][actionID], 
							length = dataModel.schema.modelHorizon
						await recalcMetrics(bcObject, length)
					}
				}
			}

			// vii. Update aggregation flag
			ui.state.modelsAggregated = true
			
			// x. Helper for recalculating aggregated BC metrics
			async function recalcMetrics(bcObject, length){
				bcObject.businessCase['Net cash flow'] 	= bcObject.businessCase['Net cash flow'].map( (d, i) => d 
														+ bcObject.businessCase["Cashflow items"]["Avoided cost"][i] 
														+ bcObject.businessCase["Cashflow items"]["Revenue"][i] 
														- bcObject.businessCase["Cashflow items"]["Additional cost"][i] 
														- bcObject.businessCase["Cashflow items"]["Marginal capital cost"][i]	
														- bcObject.businessCase["Cashflow items"]["Marginal operations and maintenance cost"][i]	
													)
				const netCashFlow 		= bcObject.businessCase['Net cash flow'],
					discountedCashFlow 	= netCashFlow.map( (d, i) =>  d / settings.parameters.financial["Discount factor"][i]),
					cumNetCF 			= netCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
					cumDCF 				= discountedCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
					discountedNetEmissionsImpact = bcObject.businessCase['Emissions abatement'].map( (d,i) => d / settings.parameters.financial["Discount factor"][i] / bcObject.uptakeModel.noSites),
					npv 				= d3.sum(discountedCashFlow),
					discountedAbatement = d3.sum(discountedNetEmissionsImpact),
					levelisedCost 		= (npv === 0 || discountedAbatement === 0) ? 0 : - npv / discountedAbatement


					bcObject.businessCase['Cumulative cash flow'] = cumNetCF
					bcObject.businessCase['Discounted cash flow'] = discountedCashFlow
					bcObject.businessCase['Cumulative DCF'] 	  = cumDCF
					bcObject.businessCase['Metrics'] = {
						"NPV": 								d3.sum(discountedCashFlow),
						"IRR": 								helpers.IRR(netCashFlow, 0),
						"Simple payback": 					helpers.payback(cumNetCF, length),
						"Discounted payback": 				helpers.payback(cumDCF, length),
						"Levelised cost of abatement": 		levelisedCost,
						"abatementNPV": 					discountedAbatement
					}
			}; 		
		};

		// x. Helper to initialise BC objects
		async function returnNewBCobj(length, name){ 
			return {
				name: 								name,
				businessCase: {
					"Cashflow items": {
						"Avoided cost": 								Array(length).fill(0),
						"Marginal capital cost": 						Array(length).fill(0),
						"Marginal operations and maintenance cost": 	Array(length).fill(0),
						"Revenue": 										Array(length).fill(0),
						"Additional cost": 								Array(length).fill(0),
					},	
					"Net cash flow": 				Array(length).fill(0),	
					"Emissions abatement": 			Array(length).fill(0),	
					"Natural volume abatement": 	{}	
				},
				impact: {
					emissionsReduction: {
						Scope1: 		 			Array(length).fill(0),	
						Scope2: 		 			Array(length).fill(0),	
						Scope3: 		 			Array(length).fill(0),	
						Total: 		 				Array(length).fill(0)
					},
					emissionsRedExSinks: {
						Scope1: 		 			Array(length).fill(0),	
						Scope2: 		 			Array(length).fill(0),	
						Scope3: 		 			Array(length).fill(0),	
						Total: 		 				Array(length).fill(0)
					},	
					emissionsSinks: {
						Scope1: 		 			Array(length).fill(0),	
						Scope2: 		 			Array(length).fill(0),	
						Scope3: 		 			Array(length).fill(0),	
						Total: 		 				Array(length).fill(0)
					},
					emissionsReductionBySource: 	{},												
					reducedNaturalVolume: 			{}
				},
				uptakeModel:{
					emissionsReduction: {
						Scope1: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope2: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope3: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Total: 		 				Array(dataModel.schema.modelHorizon).fill(0)
					},
					emissionsRedExSinks: {
						Scope1: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope2: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope3: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Total: 		 				Array(dataModel.schema.modelHorizon).fill(0)
					},	
					emissionsSinks: {
						Scope1: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope2: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Scope3: 		 			Array(dataModel.schema.modelHorizon).fill(0),	
						Total: 		 				Array(dataModel.schema.modelHorizon).fill(0)
					},
					emissionsReductionBySource: 	{},										
					reducedNaturalVolume: 		 	{},
					noSites: 						0
				}				
			}
		};

		// x. Helper for aggregation for summable items, with uptake applied?
		async function aggregateOBJ(bcObject, actionData, actionSettings){
			const totalNoSitesTargeted = actionSettings.uptakeTotalSites
			// Initiate  the bcObject for various natural volume reductions
			actionData.impact.reducedNaturalVolume.forEach( sourceObj => {
				if(typeof bcObject.impact.reducedNaturalVolume[Object.keys(sourceObj)[0]] === 'undefined'){
					bcObject.impact.reducedNaturalVolume[Object.keys(sourceObj)[0]] = Array(dataModel.schema.modelHorizon).fill(0)
				}
				if(typeof bcObject.uptakeModel.reducedNaturalVolume[Object.keys(sourceObj)[0]] === 'undefined'){
					bcObject.uptakeModel.reducedNaturalVolume[Object.keys(sourceObj)[0]] = Array(dataModel.schema.modelHorizon).fill(0)
				}
				if(typeof bcObject.businessCase["Natural volume abatement"][Object.keys(sourceObj)[0]] === 'undefined'){
					bcObject.businessCase["Natural volume abatement"][Object.keys(sourceObj)[0]] = Array(dataModel.schema.modelHorizon).fill(0)
				}
			})

			// Aggregate each cashflow and stock item, multiplied by totalNoSites
			bcObject.businessCase["Cashflow items"]["Avoided cost"] = bcObject.businessCase['Cashflow items']['Avoided cost'].map( (d, i) => d + (typeof actionData.businessCase['Cashflow items']['Avoided cost'][i] !== 'undefined' ? actionData.businessCase['Cashflow items']['Avoided cost'][i] * totalNoSitesTargeted : 0) )
			bcObject.businessCase["Cashflow items"]["Additional cost"] = bcObject.businessCase['Cashflow items']['Additional cost'].map( (d, i) => d + (typeof actionData.businessCase['Cashflow items']['Additional cost'][i] !== 'undefined' ? actionData.businessCase['Cashflow items']['Additional cost'][i] * totalNoSitesTargeted : 0) )
			bcObject.businessCase["Cashflow items"]["Marginal capital cost"] = bcObject.businessCase['Cashflow items']['Marginal capital cost'].map( (d, i) => d + (typeof actionData.businessCase['Cashflow items']['Marginal capital cost'][i] !== 'undefined' ? actionData.businessCase['Cashflow items']['Marginal capital cost'][i] * totalNoSitesTargeted : 0) )
			bcObject.businessCase["Cashflow items"]["Marginal operations and maintenance cost"] = bcObject.businessCase['Cashflow items']['Marginal operations and maintenance cost'].map( (d, i) => d + (typeof actionData.businessCase['Cashflow items']['Marginal operations and maintenance cost'][i] !== 'undefined' ? actionData.businessCase['Cashflow items']['Marginal operations and maintenance cost'][i] * totalNoSitesTargeted : 0) )
			bcObject.businessCase["Cashflow items"]["Revenue"] 	= bcObject.businessCase['Cashflow items']['Revenue'].map( (d, i) => d + (typeof actionData.businessCase['Cashflow items']['Revenue'][i] !== 'undefined' ? actionData.businessCase['Cashflow items']['Revenue'][i] * totalNoSitesTargeted : 0) )
	
			// Aggregate all other items (already adjusted for sites)
			bcObject.businessCase['Emissions abatement'] 		= bcObject.businessCase['Emissions abatement'].map( (d, i) => d + (typeof actionData.businessCase['Emissions abatement'][i] !== 'undefined' ? actionData.businessCase['Emissions abatement'][i] : 0) )

			actionData.businessCase["Natural volume abatement"].forEach(sourceObj => {
				const source = Object.keys(sourceObj)[0]
				bcObject.businessCase["Natural volume abatement"][source] = bcObject.uptakeModel.reducedNaturalVolume[source].map((d, i) => d + Object.values(sourceObj)[0][i] ) 
			})
			actionData.impact.reducedNaturalVolume.forEach(sourceObj => {
				const source = Object.keys(sourceObj)[0]
				bcObject.impact.reducedNaturalVolume[source] = bcObject.impact.reducedNaturalVolume[source].map((d, i) => d + Object.values(sourceObj)[0][i] ) 
			})
			actionData.uptakeModel.reducedNaturalVolume.forEach(sourceObj => {
				const source = Object.keys(sourceObj)[0]
				bcObject.uptakeModel.reducedNaturalVolume[source] = bcObject.uptakeModel.reducedNaturalVolume[source].map((d, i) => d + Object.values(sourceObj)[0][i] ) 
			})

			bcObject.impact.emissionsReduction.Scope1 	= bcObject.impact.emissionsReduction.Scope1.map( (d, i) => d + (typeof actionData.impact.emissionsReduction.Scope1[i] !== 'undefined' ? actionData.impact.emissionsReduction.Scope1[i] : 0) )
			bcObject.impact.emissionsReduction.Scope2 	= bcObject.impact.emissionsReduction.Scope2.map( (d, i) => d + (typeof actionData.impact.emissionsReduction.Scope2[i] !== 'undefined' ? actionData.impact.emissionsReduction.Scope2[i] : 0) )
			bcObject.impact.emissionsReduction.Scope3 	= bcObject.impact.emissionsReduction.Scope3.map( (d, i) => d + (typeof actionData.impact.emissionsReduction.Scope3[i] !== 'undefined' ? actionData.impact.emissionsReduction.Scope3[i] : 0) )
			bcObject.impact.emissionsReduction.Total 	= bcObject.impact.emissionsReduction.Total.map( (d, i)  => d + (typeof actionData.impact.emissionsReduction.Total [i] !== 'undefined' ? actionData.impact.emissionsReduction.Total [i] : 0) )

			bcObject.impact.emissionsRedExSinks.Scope1 = bcObject.impact.emissionsRedExSinks.Scope1.map( (d, i) => d + (typeof actionData.impact.emissionsRedExSinks.Scope1[i] !== 'undefined' ? actionData.impact.emissionsRedExSinks.Scope1[i] : 0) )
			bcObject.impact.emissionsRedExSinks.Scope2 = bcObject.impact.emissionsRedExSinks.Scope2.map( (d, i) => d + (typeof actionData.impact.emissionsRedExSinks.Scope2[i] !== 'undefined' ? actionData.impact.emissionsRedExSinks.Scope2[i] : 0) )
			bcObject.impact.emissionsRedExSinks.Scope3 = bcObject.impact.emissionsRedExSinks.Scope3.map( (d, i) => d + (typeof actionData.impact.emissionsRedExSinks.Scope3[i] !== 'undefined' ? actionData.impact.emissionsRedExSinks.Scope3[i] : 0) )
			bcObject.impact.emissionsRedExSinks.Total 	= bcObject.impact.emissionsRedExSinks.Total.map( (d, i) => d +  (typeof actionData.impact.emissionsRedExSinks.Total[i]  !== 'undefined' ? actionData.impact.emissionsRedExSinks.Total[i]  : 0) )

			bcObject.impact.emissionsSinks.Scope1 	= bcObject.impact.emissionsSinks.Scope1.map( (d, i) => d + (typeof actionData.impact.emissionsSinks.Scope1[i] !== 'undefined' ? actionData.impact.emissionsSinks.Scope1[i] : 0) )
			bcObject.impact.emissionsSinks.Scope2 	= bcObject.impact.emissionsSinks.Scope2.map( (d, i) => d + (typeof actionData.impact.emissionsSinks.Scope2[i] !== 'undefined' ? actionData.impact.emissionsSinks.Scope2[i] : 0) )
			bcObject.impact.emissionsSinks.Scope3 	= bcObject.impact.emissionsSinks.Scope3.map( (d, i) => d + (typeof actionData.impact.emissionsSinks.Scope3[i] !== 'undefined' ? actionData.impact.emissionsSinks.Scope3[i] : 0) )
			bcObject.impact.emissionsSinks.Total 	= bcObject.impact.emissionsSinks.Total.map( (d, i) =>  d + (typeof actionData.impact.emissionsSinks.Total[i]  !== 'undefined' ? actionData.impact.emissionsSinks.Total[i] : 0) )
		
			bcObject.uptakeModel.emissionsReduction.Scope1 	= bcObject.uptakeModel.emissionsReduction.Scope1.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsReduction.Scope1[i] !== 'undefined' ? actionData.uptakeModel.emissionsReduction.Scope1[i] : 0) )
			bcObject.uptakeModel.emissionsReduction.Scope2 	= bcObject.uptakeModel.emissionsReduction.Scope2.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsReduction.Scope2[i] !== 'undefined' ? actionData.uptakeModel.emissionsReduction.Scope2[i] : 0) )
			bcObject.uptakeModel.emissionsReduction.Scope3 	= bcObject.uptakeModel.emissionsReduction.Scope3.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsReduction.Scope3[i] !== 'undefined' ? actionData.uptakeModel.emissionsReduction.Scope3[i] : 0) )
			bcObject.uptakeModel.emissionsReduction.Total 	= bcObject.uptakeModel.emissionsReduction.Total.map( (d, i)  => d + (typeof actionData.uptakeModel.emissionsReduction.Total [i] !== 'undefined' ? actionData.uptakeModel.emissionsReduction.Total [i] : 0) )				

			bcObject.uptakeModel.emissionsRedExSinks.Scope1 = bcObject.uptakeModel.emissionsRedExSinks.Scope1.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsRedExSinks.Scope1[i] !== 'undefined' ? actionData.uptakeModel.emissionsRedExSinks.Scope1[i] : 0) )
			bcObject.uptakeModel.emissionsRedExSinks.Scope2 = bcObject.uptakeModel.emissionsRedExSinks.Scope2.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsRedExSinks.Scope2[i] !== 'undefined' ? actionData.uptakeModel.emissionsRedExSinks.Scope2[i] : 0) )
			bcObject.uptakeModel.emissionsRedExSinks.Scope3 = bcObject.uptakeModel.emissionsRedExSinks.Scope3.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsRedExSinks.Scope3[i] !== 'undefined' ? actionData.uptakeModel.emissionsRedExSinks.Scope3[i] : 0) )
			bcObject.uptakeModel.emissionsRedExSinks.Total = bcObject.uptakeModel.emissionsRedExSinks.Total.map( (d, i) => d +  (typeof actionData.uptakeModel.emissionsRedExSinks.Total[i]  !== 'undefined' ? actionData.uptakeModel.emissionsRedExSinks.Total[i] : 0) )

			bcObject.uptakeModel.emissionsSinks.Scope1 	= bcObject.uptakeModel.emissionsSinks.Scope1.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsSinks.Scope1[i] !== 'undefined' ? actionData.uptakeModel.emissionsSinks.Scope1[i] : 0) )
			bcObject.uptakeModel.emissionsSinks.Scope2 	= bcObject.uptakeModel.emissionsSinks.Scope2.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsSinks.Scope2[i] !== 'undefined' ? actionData.uptakeModel.emissionsSinks.Scope2[i] : 0) )
			bcObject.uptakeModel.emissionsSinks.Scope3 	= bcObject.uptakeModel.emissionsSinks.Scope3.map( (d, i) => d + (typeof actionData.uptakeModel.emissionsSinks.Scope3[i] !== 'undefined' ? actionData.uptakeModel.emissionsSinks.Scope3[i] : 0) )
			bcObject.uptakeModel.emissionsSinks.Total 	= bcObject.uptakeModel.emissionsSinks.Total.map( (d, i) =>  d + (typeof actionData.uptakeModel.emissionsSinks.Total[i]  !== 'undefined' ? actionData.uptakeModel.emissionsSinks.Total[i] : 0) )

			// Aggregation the reductions by source
			if(Object.keys(actionData.impact.emissionsReductionBySource.length > 0)){
				Object.entries(actionData.impact.emissionsReductionBySource).forEach(([source, values]) =>{
					if(typeof bcObject.impact.emissionsReductionBySource[source] === 'undefined'){
						bcObject.impact.emissionsReductionBySource[source] 	= {
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						}
					}
					bcObject.impact.emissionsReductionBySource[source] = {
						Scope1: 		bcObject.impact.emissionsReductionBySource[source].Scope1.map((d,i) => d + actionData.impact.emissionsReductionBySource[source].Scope1[i]) ,
						Scope2: 		bcObject.impact.emissionsReductionBySource[source].Scope2.map((d,i) => d + actionData.impact.emissionsReductionBySource[source].Scope2[i]) ,
						Scope3: 		bcObject.impact.emissionsReductionBySource[source].Scope3.map((d,i) => d + actionData.impact.emissionsReductionBySource[source].Scope3[i]) ,
						Total: 			bcObject.impact.emissionsReductionBySource[source].Total.map((d,i)  => d + actionData.impact.emissionsReductionBySource[source].Total[i]) ,
					}
				} )
			}

			if(Object.keys(actionData.uptakeModel.emissionsReductionBySource.length > 0)){
				Object.entries(actionData.uptakeModel.emissionsReductionBySource).forEach(([source, values]) =>{
					if(typeof bcObject.uptakeModel.emissionsReductionBySource[source] === 'undefined'){
						bcObject.uptakeModel.emissionsReductionBySource[source] = {
							Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
							Total: 			Array(dataModel.schema.modelHorizon).fill(0)
						}
					}
					bcObject.uptakeModel.emissionsReductionBySource[source] = {
						Scope1: 		bcObject.uptakeModel.emissionsReductionBySource[source].Scope1.map((d,i) => d + actionData.uptakeModel.emissionsReductionBySource[source].Scope1[i]) ,
						Scope2: 		bcObject.uptakeModel.emissionsReductionBySource[source].Scope2.map((d,i) => d + actionData.uptakeModel.emissionsReductionBySource[source].Scope2[i]) ,
						Scope3: 		bcObject.uptakeModel.emissionsReductionBySource[source].Scope3.map((d,i) => d + actionData.uptakeModel.emissionsReductionBySource[source].Scope3[i]) ,
						Total: 			bcObject.uptakeModel.emissionsReductionBySource[source].Total.map((d,i)  => d + actionData.uptakeModel.emissionsReductionBySource[source].Total[i]) ,
					}
				} )
			}

			// Sum Net Cash Flow and update noSites
			bcObject.uptakeModel.noSites  += totalNoSitesTargeted	
		};		
	}; // end aggregateActionModels()



/////////////////////////////////////////////////////////////////////
///  UPDATE MODEL METHODS: REF CASE, ACTION MODELS & ACTION CASE  ///
/////////////////////////////////////////////////////////////////////

	// UPDATE THE REFERENCE CASE (model.inventory.referenceCase.byAgency_sitegroup only for specific cases, without rebuild)
	async function updateReferenceCase(){ 
		const selectedAgency = (ui.state.agencyName !== 'All agencies') ? ui.state.agencyName : null,
			selectedSitegroup = (ui.state.sitegroup !== 'none') ? ui.state.sitegroup : null,
			paramID =  ui.dynamics.changedParameter.parameterName
		let paramData

		switch(ui.dynamics.changedParameter.parameterType){
			// CASE A. UPDATE FOR EMISSIONS FACTOR CHANGE			
			case 'emissionFactor':
				paramData = model.parameters.emissionFactors[paramID]
				const efSector =  paramData.sector, efSource = paramData.source

				// a. Update referenceCase.byAgency_sitegroup and model.inventory.referenceCase.byAgency
				const agencySitegroupRefData = model.inventory.referenceCase.byAgency_sitegroup			
				for( const agency of Object.keys(agencySitegroupRefData)) {
					for( const sitegroup of Object.keys(agencySitegroupRefData[agency])) {
						if(typeof agencySitegroupRefData[agency][sitegroup][efSector] !== 'undefined' && typeof agencySitegroupRefData[agency][sitegroup][efSector][efSource] !== 'undefined'){
							const agencySiteNaturalVol = agencySitegroupRefData[agency][sitegroup][efSector][efSource].naturalVolume.map( d => d / (paramID === 'EF_PipedGas_CO2_per_TJ' || paramID === 'EF_WaterSupply_tCO2_per_ML' ? 1000 : 1) )
							agencySitegroupRefData[agency][sitegroup][efSector][efSource].emissions.Scope1 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope1[i] )
							agencySitegroupRefData[agency][sitegroup][efSector][efSource].emissions.Scope2 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope2[i] )
							agencySitegroupRefData[agency][sitegroup][efSector][efSource].emissions.Scope3 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope3[i] )
							agencySitegroupRefData[agency][sitegroup][efSector][efSource].emissions.Total	= agencySiteNaturalVol.map((d,i) => d * (settings.parameters.emissionFactors[paramID].scope1[i] + settings.parameters.emissionFactors[paramID].scope2[i] + settings.parameters.emissionFactors[paramID].scope3[i]) )
						}
					}
				}

				// b. REFERENCE CASE by model.inventory.referenceCase.byCluster_agency_sitegroup
				const clusterAgencySitegroupRefData = model.inventory.referenceCase.byCluster_agency_sitegroup
				for( const cluster of Object.keys(clusterAgencySitegroupRefData)) {
					for( const agency of Object.keys(clusterAgencySitegroupRefData[cluster])) {
						for( const sitegroup of Object.keys(clusterAgencySitegroupRefData[cluster][agency])) {
							if(typeof clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector] !== 'undefined' && typeof clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource] !== 'undefined'){
								const agencySiteNaturalVol = clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource].naturalVolume.map( d => d / (paramID === 'EF_PipedGas_CO2_per_TJ' || paramID === 'EF_WaterSupply_tCO2_per_ML' ? 1000 : 1) )
								clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource].emissions.Scope1 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope1[i] )
								clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource].emissions.Scope2 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope2[i] )
								clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource].emissions.Scope3 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope3[i] )
								clusterAgencySitegroupRefData[cluster][agency][sitegroup][efSector][efSource].emissions.Total  = agencySiteNaturalVol.map((d,i) => d * (settings.parameters.emissionFactors[paramID].scope1[i] + settings.parameters.emissionFactors[paramID].scope2[i] + settings.parameters.emissionFactors[paramID].scope3[i]) )
							}	
						}
					}
				}

				// c. REFERENCE CASE by model.inventory.referenceCase.byCluster
				const clusterRefData = model.inventory.referenceCase.byCluster
				for( cluster of Object.keys(clusterRefData)){
					if(typeof clusterRefData[cluster][efSector] !== 'undefined' && typeof clusterRefData[cluster][efSector][efSource] !== 'undefined'){
						const agencySiteNaturalVol = clusterRefData[cluster][efSector][efSource].naturalVolume.map( d => d / (paramID === 'EF_PipedGas_CO2_per_TJ' || paramID === 'EF_WaterSupply_tCO2_per_ML' ? 1000 : 1) )
						clusterRefData[cluster][efSector][efSource].emissions.Scope1 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope1[i] )
						clusterRefData[cluster][efSector][efSource].emissions.Scope2 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope2[i] )
						clusterRefData[cluster][efSector][efSource].emissions.Scope3 = agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope3[i] )
						clusterRefData[cluster][efSector][efSource].emissions.Total  = agencySiteNaturalVol.map((d,i) => d * (settings.parameters.emissionFactors[paramID].scope1[i] + settings.parameters.emissionFactors[paramID].scope2[i] + settings.parameters.emissionFactors[paramID].scope3[i]) )
					}	
				}

				// d. REFERENCE CASE by model.inventory.referenceCase.byAgency
				const agencyRefData = model.inventory.referenceCase.byAgency
				for( const agency of Object.keys(agencyRefData)) {
					if(typeof agencyRefData[agency][efSector] !== 'undefined' && typeof agencyRefData[agency][efSector][efSource] !== 'undefined'){
						const agencySiteNaturalVol = agencyRefData[agency][efSector][efSource].naturalVolume.map( d => d / (paramID === 'EF_PipedGas_CO2_per_TJ' || paramID === 'EF_WaterSupply_tCO2_per_ML' ? 1000 : 1) )
						agencyRefData[agency][efSector][efSource].emissions.Scope1 =  agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope1[i] )
						agencyRefData[agency][efSector][efSource].emissions.Scope2 =  agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope2[i] )
						agencyRefData[agency][efSector][efSource].emissions.Scope3 =  agencySiteNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope3[i] )
						agencyRefData[agency][efSector][efSource].emissions.Total  =  agencySiteNaturalVol.map((d,i) => d * (settings.parameters.emissionFactors[paramID].scope1[i] + settings.parameters.emissionFactors[paramID].scope2[i] + settings.parameters.emissionFactors[paramID].scope3[i]) )
					}	
				}

				// e. REFERENCE CASE by model.inventory.referenceCase.bySectorSource
				const sectorSourceRefData = model.inventory.referenceCase.bySectorSource
				for( const sector of Object.keys(sectorSourceRefData)) {
					for( const source of Object.keys(sectorSourceRefData[sector])) {			
						if(sector === efSector && source === efSource && sectorSourceRefData[efSector][efSource] !== 'undefined') {
							const sectorSourceNaturalVol = sectorSourceRefData[sector][source].naturalVolume.map( d => d / (paramID === 'EF_PipedGas_CO2_per_TJ' || paramID === 'EF_WaterSupply_tCO2_per_ML' ? 1000 : 1) )
							sectorSourceRefData[efSector][efSource].emissions.Scope1 =  sectorSourceNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope1[i] )
							sectorSourceRefData[efSector][efSource].emissions.Scope2 =  sectorSourceNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope2[i] )
							sectorSourceRefData[efSector][efSource].emissions.Scope3 =  sectorSourceNaturalVol.map((d,i) => d * settings.parameters.emissionFactors[paramID].scope3[i] )
							sectorSourceRefData[efSector][efSource].emissions.Total  =  sectorSourceNaturalVol.map((d,i) => d * (settings.parameters.emissionFactors[paramID].scope1[i] + settings.parameters.emissionFactors[paramID].scope2[i] + settings.parameters.emissionFactors[paramID].scope3[i]) )
						}	
					}
				}

				// f. REFERENCE CASE by summaryTotal
				model.inventory.referenceCase.summaryTotal.emissions = {
				 	Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
				 	Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
				 	Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
				 	Total: 		Array(dataModel.schema.modelHorizon).fill(0)
				}
				for( const sector of Object.keys(sectorSourceRefData)) {
					for( source of Object.keys(sectorSourceRefData[sector])) {		
						model.inventory.referenceCase.summaryTotal.emissions.Scope1 = model.inventory.referenceCase.summaryTotal.emissions.Scope1.map((d, i) => d + sectorSourceRefData[sector][source].emissions.Scope1[i])
						model.inventory.referenceCase.summaryTotal.emissions.Scope2 = model.inventory.referenceCase.summaryTotal.emissions.Scope2.map((d, i) => d + sectorSourceRefData[sector][source].emissions.Scope2[i])
						model.inventory.referenceCase.summaryTotal.emissions.Scope3 = model.inventory.referenceCase.summaryTotal.emissions.Scope3.map((d, i) => d + sectorSourceRefData[sector][source].emissions.Scope3[i])
						model.inventory.referenceCase.summaryTotal.emissions.Total  = model.inventory.referenceCase.summaryTotal.emissions.Total.map( (d, i) => d + sectorSourceRefData[sector][source].emissions.Total[i])
					}
				}
				break

			// CASE B. UPDATE FOR ACTVITY OUTLOOK CHANGE AT SITEGROUP LEVEL
			case 'activity':
				// i. Update activity growth multiplier in settings agency/sitegroup level
				if(selectedAgency && selectedSitegroup){					
					let selectedCluster
					for( const cluster of Object.keys(dataModel.schema.consumption.agenciesByCluster)){
						if(dataModel.schema.consumption.agenciesByCluster[cluster].indexOf(selectedAgency) > -1){	selectedCluster = cluster }
					}
					// a. REFERENCE CASE with new activity settings where Agency and sitegroup and specified
						const agencySiteRefData = model.inventory.referenceCase.byAgency_sitegroup[selectedAgency][selectedSitegroup],
							clusterAgencyRefData = model.inventory.referenceCase.byCluster_agency_sitegroup[selectedCluster][selectedAgency][selectedSitegroup]

						await updateAgencySitegroupActivity(agencySiteRefData)
						await updateAgencySitegroupActivity(clusterAgencyRefData)
						// Update the totals
						async function updateAgencySitegroupActivity(refData){
							for( const sector of Object.keys(refData)) {	
								if(Object.keys(refData[sector]).length > 0){
									for( const source of Object.keys(refData[sector])) {		
										if(Object.keys(refData[sector][source]).length > 0){
											const baseNaturalVol = refData[sector][source]['naturalVolume'][0]
											let emisisonsFactorPath
											switch(source){
												case 'Grid electricity':
													emisisonsFactorPath = model.parameters.emissionFactors.agencyGridEF[selectedAgency]
													break	
												case 'Natural gas (reticulated)':
													emisisonsFactorPath = model.parameters.emissionFactors.EF_PipedGas_CO2_per_GJ
													break	
												case 'Commercial and industrial waste':
													emisisonsFactorPath = model.parameters.emissionFactors.EF_Waste_CI_tCO2_per_t
													break	
												case 'Water supply (reticulated)':
													emisisonsFactorPath = model.parameters.emissionFactors.EF_WaterSupply_tCO2_per_ML
													break	
												default:
													emisisonsFactorPath = {
														scope1: Array(dataModel.schema.modelHorizon).fill(1), 
														scope2: Array(dataModel.schema.modelHorizon).fill(1), 
														scope3: Array(dataModel.schema.modelHorizon).fill(1)
													}
											}

											if(baseNaturalVol > 0){
												refData[sector][source]['cost'] 				= refData[sector][source]['cost'].map((d, i) => refData[sector][source]['cost'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] )
												refData[sector][source]['naturalVolume'] 		= refData[sector][source]['naturalVolume'].map((d, i) => refData[sector][source]['naturalVolume'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] )
												refData[sector][source]['emissions']['Scope1'] 	= refData[sector][source]['emissions']['Scope1'].map((d, i) => refData[sector][source]['emissions']['Scope1'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope1[0] === 0 ? 1 : emisisonsFactorPath.scope1[i] / emisisonsFactorPath.scope1[0]) )
												refData[sector][source]['emissions']['Scope2'] 	= refData[sector][source]['emissions']['Scope2'].map((d, i) => refData[sector][source]['emissions']['Scope2'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope2[0] === 0 ? 1 : emisisonsFactorPath.scope2[i] / emisisonsFactorPath.scope2[0]) )
												refData[sector][source]['emissions']['Scope3'] 	= refData[sector][source]['emissions']['Scope3'].map((d, i) => refData[sector][source]['emissions']['Scope3'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope3[0] === 0 ? 1 : emisisonsFactorPath.scope3[i] / emisisonsFactorPath.scope3[0]) )
												refData[sector][source]['emissions']['Total'] 	= refData[sector][source]['emissions']['Total'].map((d, i) => (refData[sector][source]['emissions']['Scope1'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope1[0] === 0 ? 1 : emisisonsFactorPath.scope1[i] / emisisonsFactorPath.scope1[0]) )
																																							+ (refData[sector][source]['emissions']['Scope2'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope2[0] === 0 ? 1 : emisisonsFactorPath.scope2[i] / emisisonsFactorPath.scope2[0]) )
																																							+ (refData[sector][source]['emissions']['Scope3'][0] * settings.parameters.activityGrowth[selectedAgency][selectedSitegroup].value[i] * (emisisonsFactorPath.scope3[0] === 0 ? 1 : emisisonsFactorPath.scope3[i] / emisisonsFactorPath.scope3[0]) ) )
											}
										}
									}
								}
							}
						}; // end updateActivityBySectorSource

					// b. OTHER REFERENCE CASE shaped data
						for( const sector of Object.keys(model.inventory.referenceCase.byCluster[selectedCluster])) {
							for( const source of Object.keys(model.inventory.referenceCase.byCluster[selectedCluster][sector])) {					
								const clusterData = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.cluster === selectedCluster)

								if(clusterData.length > 0){
									const refCaseObj = model.inventory.referenceCase.byCluster[selectedCluster][sector][source]
									refCaseObj.cost 			= Array(dataModel.schema.modelHorizon).fill(0)	
									refCaseObj.naturalVolume 	=  Array(dataModel.schema.modelHorizon).fill(0)									
									refCaseObj.emissions = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
										Scope2:	 		Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 	 	Array(dataModel.schema.modelHorizon).fill(0),
										Total:		 	Array(dataModel.schema.modelHorizon).fill(0)
									}
									refCaseObj.emissionsReduction = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope2: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope3: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Total: 			Array(dataModel.schema.modelHorizon).fill(0)
									}		
									refCaseObj.emissionsSinks = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope2: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope3: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Total: 			Array(dataModel.schema.modelHorizon).fill(0)
									}																			
												
									// Rebuild from model.inventory.referenceCase.byCluster_agency_sitegroup
									Object.entries(model.inventory.referenceCase.byCluster_agency_sitegroup[selectedCluster]).forEach( ([agency, agencyObj]) => {
										Object.entries(agencyObj).forEach( ([sitegroup, sitegroupObj ]) => {
											let data = (typeof(sitegroupObj[sector]) !== 'undefined' && typeof(sitegroupObj[sector][source]) !== 'undefined') ? sitegroupObj[sector][source] : null
											if(data){
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].cost = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].cost.map((d, i) => d + data.cost[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].naturalVolume = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].naturalVolume.map((d, i) => d + data.naturalVolume[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope1 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope1.map((d, i) => d + data.emissions.Scope1[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope2 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope2.map((d, i) => d + data.emissions.Scope2[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope3 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Scope3.map((d, i) => d + data.emissions.Scope3[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Total = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissions.Total.map((d, i) => d + data.emissions.Total[i])	

												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope1 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope1.map((d, i) => d + data.emissionsReduction.Scope1[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope2 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope2.map((d, i) => d + data.emissionsReduction.Scope2[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope3 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Scope3.map((d, i) => d + data.emissionsReduction.Scope3[i])	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Total = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsReduction.Total.map((d, i) => d + data.emissionsReduction.Total[i])	

												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope1 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope1.map((d, i) => d + data.emissionsSinks.Scope1[i] )	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope2 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope2.map((d, i) => d + data.emissionsSinks.Scope2[i] )	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope3 = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Scope3.map((d, i) => d + data.emissionsSinks.Scope3[i] )	
												model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Total = model.inventory.referenceCase.byCluster[selectedCluster][sector][source].emissionsSinks.Total.map((d, i) => d + data.emissionsSinks.Total[i] )	
											}			
										})
									})
								}						
							}
						}
						// ii. by Agency and summaryTotal
						model.inventory.referenceCase.summaryTotal.cost = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.referenceCase.summaryTotal.naturalVolume = Array(dataModel.schema.modelHorizon).fill(0)
						model.inventory.referenceCase.summaryTotal.emissions = {
							Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
							Total: 		Array(dataModel.schema.modelHorizon).fill(0)
						}
						model.inventory.referenceCase.summaryTotal.emissionsReduction = {
							Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
							Total: 		Array(dataModel.schema.modelHorizon).fill(0)
						}
						model.inventory.referenceCase.summaryTotal.emissionsSinks = {
							Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
							Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
							Total: 		Array(dataModel.schema.modelHorizon).fill(0)
						}

						for( const sector of Object.keys(model.inventory.referenceCase.byAgency[selectedAgency])) {
							for( const source of Object.keys(model.inventory.referenceCase.byAgency[selectedAgency][sector])) {
								const agencyData = Object.values(model.inventory.referenceCase.bySite[sector][source]).filter( d => d.agency === selectedAgency)

								if(agencyData.length > 0){
									const refCaseObj = model.inventory.referenceCase.byAgency[selectedAgency][sector][source]
									refCaseObj.cost 			= Array(dataModel.schema.modelHorizon).fill(0)	
									refCaseObj.naturalVolume 	=  Array(dataModel.schema.modelHorizon).fill(0)									
									refCaseObj.emissions = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
										Scope2:	 		Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 	 	Array(dataModel.schema.modelHorizon).fill(0),
										Total:		 	Array(dataModel.schema.modelHorizon).fill(0)
									}
									refCaseObj.emissionsReduction = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope2: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope3: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Total: 			Array(dataModel.schema.modelHorizon).fill(0)
									}		
									refCaseObj.emissionsSinks = {
										Scope1: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope2: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Scope3: 		Array(dataModel.schema.modelHorizon).fill(0) ,
										Total: 			Array(dataModel.schema.modelHorizon).fill(0)
									}

									// Rebuild from model.inventory.referenceCase.byCluster_agency_sitegroup
									Object.entries(model.inventory.referenceCase.byCluster_agency_sitegroup[selectedCluster]).forEach( ([agency, agencyObj]) => {
										Object.entries(agencyObj).forEach( ([sitegroup, sitegroupObj ]) => {
											let data = (typeof(sitegroupObj[sector]) !== 'undefined' && typeof(sitegroupObj[sector][source]) !== 'undefined') ? sitegroupObj[sector][source] : null
											if(data){
												if(agency === selectedAgency){
													refCaseObj.cost = refCaseObj.cost.map((d, i) => d + data.cost[i])	
													refCaseObj.naturalVolume = refCaseObj.naturalVolume.map((d, i) => d + data.naturalVolume[i])	
													refCaseObj.emissions.Scope1 = refCaseObj.emissions.Scope1.map((d, i) => d + data.emissions.Scope1[i])	
													refCaseObj.emissions.Scope2 = refCaseObj.emissions.Scope2.map((d, i) => d + data.emissions.Scope2[i])	
													refCaseObj.emissions.Scope3 = refCaseObj.emissions.Scope3.map((d, i) => d + data.emissions.Scope3[i])	
													refCaseObj.emissions.Total = refCaseObj.emissions.Total.map((d, i) => d + data.emissions.Total[i])	

													refCaseObj.emissionsReduction.Scope1 = refCaseObj.emissionsReduction.Scope1.map((d, i) => d + data.emissionsReduction.Scope1[i])	
													refCaseObj.emissionsReduction.Scope2 = refCaseObj.emissionsReduction.Scope2.map((d, i) => d + data.emissionsReduction.Scope2[i])	
													refCaseObj.emissionsReduction.Scope3 = refCaseObj.emissionsReduction.Scope3.map((d, i) => d + data.emissionsReduction.Scope3[i])	
													refCaseObj.emissionsReduction.Total = refCaseObj.emissionsReduction.Total.map((d, i) => d + data.emissionsReduction.Total[i])	

													refCaseObj.emissionsSinks.Scope1 = refCaseObj.emissionsSinks.Scope1.map((d, i) => d + data.emissionsSinks.Scope1[i] )	
													refCaseObj.emissionsSinks.Scope2 = refCaseObj.emissionsSinks.Scope2.map((d, i) => d + data.emissionsSinks.Scope2[i] )	
													refCaseObj.emissionsSinks.Scope3 = refCaseObj.emissionsSinks.Scope3.map((d, i) => d + data.emissionsSinks.Scope3[i] )	
													refCaseObj.emissionsSinks.Total = refCaseObj.emissionsSinks.Total.map((d, i) => d + data.emissionsSinks.Total[i] )	
												}

												// Update totals
												model.inventory.referenceCase.summaryTotal.cost = model.inventory.referenceCase.summaryTotal.cost.map((d, i) => d + data.cost[i])	
												model.inventory.referenceCase.summaryTotal.naturalVolume = model.inventory.referenceCase.summaryTotal.naturalVolume.map((d, i) => d + data.naturalVolume[i])	
												model.inventory.referenceCase.summaryTotal.emissions.Scope1 = model.inventory.referenceCase.summaryTotal.emissions.Scope1.map((d, i) => d + data.emissions.Scope1[i])	
												model.inventory.referenceCase.summaryTotal.emissions.Scope2 = model.inventory.referenceCase.summaryTotal.emissions.Scope2.map((d, i) => d + data.emissions.Scope2[i])	
												model.inventory.referenceCase.summaryTotal.emissions.Scope3 = model.inventory.referenceCase.summaryTotal.emissions.Scope3.map((d, i) => d + data.emissions.Scope3[i])	
												model.inventory.referenceCase.summaryTotal.emissions.Total = model.inventory.referenceCase.summaryTotal.emissions.Total.map((d, i) => d + data.emissions.Total[i])	

												model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope1 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope1.map((d, i) => d + data.emissionsReduction.Scope1[i])	
												model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope2 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope2.map((d, i) => d + data.emissionsReduction.Scope2[i])	
												model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope3 = model.inventory.referenceCase.summaryTotal.emissionsReduction.Scope3.map((d, i) => d + data.emissionsReduction.Scope3[i])	
												model.inventory.referenceCase.summaryTotal.emissionsReduction.Total = model.inventory.referenceCase.summaryTotal.emissionsReduction.Total.map((d, i) => d + data.emissionsReduction.Total[i])	

												model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope1 = model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope1.map((d, i) => d + data.emissionsSinks.Scope1[i] )	
												model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope2 = model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope2.map((d, i) => d + data.emissionsSinks.Scope2[i] )	
												model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope3 = model.inventory.referenceCase.summaryTotal.emissionsSinks.Scope3.map((d, i) => d + data.emissionsSinks.Scope3[i] )	
												model.inventory.referenceCase.summaryTotal.emissionsSinks.Total = model.inventory.referenceCase.summaryTotal.emissionsSinks.Total.map((d, i) => d + data.emissionsSinks.Total[i] )	
											}			
										})
									})		
								}
							}
						}

					console.log('Updated activity for '+selectedAgency, selectedSitegroup)
				} 
				break

			// CASE C. UPDATE FOR PRICE / WACC  CHANGE > ALL AFFECTED SOURCES
			case 'general':
				paramData = model.parameters.general[paramID]
				const paramType = paramData.type

				switch(paramType){
					case 'price':
					console.log('Updating price')
						// i. For an identified source (i.e. is a price to update) 
						if (paramData.source !== 'na'){
							const priceSource = paramData.source, 
								priceSector =  paramData.sector							
							// a. REFERENCE CASE by referenceCase.byAgency_sitegroup
							const agencySitegroupRefData = model.inventory.referenceCase.byAgency_sitegroup
							for( const agency of Object.keys(agencySitegroupRefData)){
								for( const sitegroup of Object.keys(agencySitegroupRefData[agency])) {
									if(sitegroup !== "Unassigned" && typeof agencySitegroupRefData[agency][sitegroup][priceSector] !== 'undefined' && typeof agencySitegroupRefData[agency][sitegroup][priceSector][priceSource] !== 'undefined'){
										agencySitegroupRefData[agency][sitegroup][priceSector][priceSource].cost 	 		=  agencySitegroupRefData[agency][sitegroup][priceSector][priceSource].cost.map((d, i) => agencySitegroupRefData[agency][sitegroup][priceSector][priceSource].cost[0] * settings.parameters.general[paramID]['value'][i]  / settings.parameters.general[paramID]['value'][0] )
										agencySitegroupRefData[agency][sitegroup][priceSector][priceSource].modelledTariff 	=  agencySitegroupRefData[agency][sitegroup][priceSector][priceSource].modelledTariff.map((d, i) => agencySitegroupRefData[agency][sitegroup][priceSector][priceSource]['modelledTariff'][0] * settings.parameters.general[paramID]['value'][i] / settings.parameters.general[paramID]['value'][0] )
									}	
								}
							}
							// b. REFERENCE CASE by model.inventory.referenceCase.byCluster_agency_sitegroup
							const clusterAgencySitegroupRefData = model.inventory.referenceCase.byCluster_agency_sitegroup
							for( const cluster of Object.keys(clusterAgencySitegroupRefData)) {
								for( agency of Object.keys(clusterAgencySitegroupRefData[cluster])) {
									for( sitegroup of Object.keys(clusterAgencySitegroupRefData[cluster][agency])) {
										if(sitegroup !== "Unassigned" && typeof clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector] !== 'undefined' && typeof clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource] !== 'undefined'){
											clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource].cost 	 		=  clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource].cost.map((d, i) => clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource]['cost'][0] * settings.parameters.general[paramID]['value'][i]  / settings.parameters.general[paramID]['value'][0] )
											clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource].modelledTariff 	=  clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource].modelledTariff.map((d, i) => clusterAgencySitegroupRefData[cluster][agency][sitegroup][priceSector][priceSource]['modelledTariff'][0] * settings.parameters.general[paramID]['value'][i] / settings.parameters.general[paramID]['value'][0] )
										}	
									}
								}
							}
							// c. REFERENCE CASE by model.inventory.referenceCase.byCluster
							const clusterRefData = model.inventory.referenceCase.byCluster
							for( const cluster of Object.keys(clusterRefData)){
								if(typeof clusterRefData[cluster][priceSector] !== 'undefined' && typeof clusterRefData[cluster][priceSector][priceSource] !== 'undefined'){
									clusterRefData[cluster][priceSector][priceSource].cost 	 			=  clusterRefData[cluster][priceSector][priceSource].cost.map((d, i) => clusterRefData[cluster][priceSector][priceSource]['cost'][0] * settings.parameters.general[paramID]['value'][i]  / settings.parameters.general[paramID]['value'][0] )
									clusterRefData[cluster][priceSector][priceSource].modelledTariff 	=  clusterRefData[cluster][priceSector][priceSource].modelledTariff.map((d, i) => clusterRefData[cluster][priceSector][priceSource]['modelledTariff'][0] * settings.parameters.general[paramID]['value'][i] / settings.parameters.general[paramID]['value'][0] )
								}	
							}
							// d. REFERENCE CASE by model.inventory.referenceCase.byAgency
							const agencyRefData = model.inventory.referenceCase.byAgency
							for( const agency of Object.keys(agencyRefData)) {
								if(typeof agencyRefData[agency][priceSector] !== 'undefined' && typeof agencyRefData[agency][priceSector][priceSource] !== 'undefined'){
									agencyRefData[agency][priceSector][priceSource].cost 	 		=  agencyRefData[agency][priceSector][priceSource].cost.map((d, i) => agencyRefData[agency][priceSector][priceSource]['cost'][0] * settings.parameters.general[paramID]['value'][i]  / settings.parameters.general[paramID]['value'][0] )
									agencyRefData[agency][priceSector][priceSource].modelledTariff 	=  agencyRefData[agency][priceSector][priceSource].modelledTariff.map((d, i) => agencyRefData[agency][priceSector][priceSource]['modelledTariff'][0] * settings.parameters.general[paramID]['value'][i] / settings.parameters.general[paramID]['value'][0] )
								}	
							}
						} 
						break
				}
				break
		}
	}; // end updateReference()

	// UPDATE THE ACTION MODELS 
	async function updateActionModel(calledFrom){
		const selectedAgency = (ui.state.agencyName !== 'All agencies') ? ui.state.agencyName : null,
			selectedsitegroup = (ui.state.sitegroup !== 'none') ? ui.state.sitegroup : null,
			paramName =  ui.dynamics.changedParameter.parameterName

		switch(ui.state.actionID){
			case 'none':
				// For a change to an EF, price or agency-level activity outlook
				switch(ui.dynamics.changedParameter.parameterType){
					// CASE A. UPDATE AFFECTED BUSINESS CASES FOR EMISSIONS FACTOR CHANGE			
					case 'emissionFactor':
						console.log('...update emissions factor impact '+model.parameters.emissionFactors[paramName].name +'for all '+efSource+' actions ***')
						paramData = model.parameters.emissionFactors[paramName]
						const efSector =  paramData.sector,
							efSource = paramData.source
						// Cycle through all actions and update any with affected sources
						for( const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
							for( const sitegrouop of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {
								for( const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {
									// Check if action is linked to source then recalculate the model with new settings									
									const reductionSource 	= model.action.parameters[actionID].impact.from[0].source,
										increaseSources 	= model.action.parameters[actionID].impact.to.map(d => d.source)
									if(reductionSource === efSource || increaseSources.indexOf(efSource) > -1){
										await updateAction(agency, sitegroup)	
										await updateActionUptake(actionID, agency, sitegroup, "Emissions Factor change")	
									}
								}
							}
						}
						break

					// CASE B. UPDATE FOR ACTVITY OUTLOOK CHANGE AT SITEGROUP LEVEL
					case 'activity':
						if(selectedAgency && selectedsitegroup){
							console.log('...updating activity growth impact '+model.parameters.emissionFactors[paramName].name +' for '+selectedAgency, selectedsitegroup+' actions ***')
							for(const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[selectedAgency][selectedsitegroup])){
								await updateAction(agency, sitegroup)	
								await updateActionUptake(actionID, agency, sitegroup, "Activity change")							
							}
						} 
						break

					// CASE C. UPDATE FOR PRICE / WACC  CHANGE > ALL AFFECTED SOURCES
					case 'general':
						paramData = model.parameters.general[paramName]
						const paramType = paramData.type
						switch(paramType){
							case 'price':
								// i. For an identified source (i.e. is a price to update) 
								if (paramData.source !== 'na'){
									console.log('...updating ALL '+paramData.source+' business cases updated for change in price')									
									// Cycle through all actions and update any with affected sources
									for( const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)) {
										for( const sitegroup of  Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {
											for( const actionOD of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {
												// Check if action is linked to source then recalculate the model with new setttings									
												const reductionSource 	= model.action.parameters[actionID].impact.from[0].source,
													increaseSources 	= model.action.parameters[actionID].impact.to.map(d => d.source)
												if(reductionSource === paramData.source || increaseSources.indexOf(paramData.source) > -1){
													await updateAction(agency, sitegroup)	
												}
											}
										}
									}
								// ii. Is the wacc, updated the discount factor and 
								} else if ( ui.dynamics.changedParameter.parameterName === 'wacc'){
									console.log('...updating ALL Business cases updated for change in WACC')										
									// Cycle through all actions and update ALL business cases
									for( const agency of Object.keys(model.action.businessCase.byAgency_sitegroup)){
										for( const sitegroup of Object.keys(model.action.businessCase.byAgency_sitegroup[agency])) {
											for( const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup])) {							
												await updateAction(agency, sitegroup)	
											}
										}
									}									
								} 
								break
							default:
								// Only prices is editable from general assumptions
						}					
				}				
				break

			default:			
				// For a change to a specific action model parameter
				if(selectedAgency && ui.state.sitegroup !== 'none'){			
					await updateAction(selectedAgency, ui.state.sitegroup)	
					await updateActionUptake(ui.state.actionID, selectedAgency, ui.state.sitegroup, "action model change")	
					// >> Need to trigger a recalc of each sitegroup to refresh the solar figures for building level sitegroups		
					const otherSitegroups = dataModel.schema.consumption.sitegroupsByAgency[selectedAgency].filter(d => d !== "All of agency" && d !== "Unassigned" && d !== ui.state.sitegroup)
					for(sitegroup of otherSitegroups){				
						if( typeof(model.action.businessCase.byAgency_sitegroup[selectedAgency][sitegroup]) !== 'undefined' ){
							const actionIDs = Object.keys(model.action.businessCase.byAgency_sitegroup[selectedAgency][sitegroup])
							if(actionIDs.length > 0){
								updateAction(selectedAgency, sitegroup)
							}
						}
					}
				} else {
					console.log('*** NO UPDATE MADE: AN ACTION AT AGENCY AND SITEGROUP LEVEL IS NOT IN FOCUS')
				}
		}
	}; // end updateActionModel()

		// UPDATE AN ACTION MODEL IMPACT AND BUSINESS CASE WITHOUT UPTAKE 
		// THIS COULD/CHOULD BE REFACTORED AS A COMPONENT OF  buildActionModels (i.e. is etremely simlar
		// BUT IS KEPT AS A SEPARATE FUNCTION FOR CODE EDITING
		async function updateAction(agency, sitegroup){		
			// Initiate  recalculating impact and solar generation variables
			let sitegroupElecConsumption = sitegroup ==='All of agency' ? null : typeof model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup]['Stationary energy']['Grid electricity'] !== 'undefined' ? model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup]['Stationary energy']['Grid electricity']['naturalVolume'] : null,
				onSiteConsumptionMWh = Array(dataModel.schema.modelHorizon).fill(0), 
				exportedElecMWh 	 = Array(dataModel.schema.modelHorizon).fill(0)

			// Loop through all actions in site group to account for interaction (solar)
			for(const actionID of Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup]).sort()) {
				const actionParameters 	= model.action.parameters[actionID],
						actionSettings = settings.action.byAgency_sitegroup[agency][sitegroup][actionID]
				let impactOutflow = [], 				
					activityOutflowImpact = [],
					impactInflow = [],  					// Inflow can be multiple sources (e.g solar consumed/exported)
					activityInflowImpact = [],
					referenceCaseFrom = [], 	
					totalActivityPropBySource = {},		// Tracks activity proportion affect						
					switchToCase,	
					activityCounter = 0,
					elecActionIDs = []

				// 1. REDUCTION IMPACT >> STOCK OUTFLOW
				for( const impactFrom of actionParameters.impact.from){
					impactRefCaseFrom = model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][impactFrom.sector][impactFrom.source]
					if(typeof(impactRefCaseFrom) !== 'undefined' && d3.sum(impactRefCaseFrom.naturalVolume) > 0) {		// Guard for undefined impactRefCaseFrom and zero volume	
						referenceCaseFrom.push(impactRefCaseFrom)
						let outflowObj = {
							costSaving: 			Array(dataModel.schema.modelHorizon).fill(0),
							emissionsReduction: 	{
								Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
								Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
								Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
								Total: 				Array(dataModel.schema.modelHorizon).fill(0)
							},											
							naturalVolume: 			Array(dataModel.schema.modelHorizon).fill(0),
							baselineNaturalVolume: 	Array(dataModel.schema.modelHorizon).fill(0)
						}
						// Calculate activity level impact for impact type: Efficiency, Reduction, Switch  Generation and Offset					
						switch(actionParameters.impact.type.toLowerCase()){					
							case 'efficiency':				
							case 'reduction':				
							case 'switch':	
								// 1. Loop to extract variables			
								for( const activityObj of impactFrom.reductionByActivity) {
									const activity 		=  activityObj.activity,
										activityProp 	= model.parameters.typology[sitegroup][activity],
										impactPct 		= actionSettings.reductionPct,  				// Use updated settings
										targetUptake 	= actionSettings.opportunity.targetUptake,		// Use updated settings						
										costImpact 		= impactRefCaseFrom.cost.map( d => actionParameters.meta.sector ==="Waste" ? 0 : d * activityProp * impactPct * targetUptake),
										scope1Impact	= impactRefCaseFrom.emissions.Scope1.map( d => d * activityProp * impactPct * targetUptake),
										scope2Impact	= impactRefCaseFrom.emissions.Scope2.map( d => d * activityProp * impactPct * targetUptake ),
										scope3Impact	= impactRefCaseFrom.emissions.Scope3.map( d => d * activityProp * impactPct * targetUptake ),
										totalEmissionsImpact	= impactRefCaseFrom.emissions.Total.map( d => d * activityProp * impactPct * targetUptake ),
										naturalVolumeImpact		= impactRefCaseFrom.naturalVolume.map( d => d * activityProp * impactPct * targetUptake ),
										baselineNaturalVolume	= impactRefCaseFrom.naturalVolume.map( d => d * activityProp )

									totalActivityPropBySource[actionParameters.impact.from[0].source] += activityProp // Track total activity affected for calculating per unit costs
									// Push to activityOutflow for each impactFrom object
									activityOutflowImpact.push({
										[activity]: {
											costSaving: 			costImpact,
											emissionsReduction: 	{
												Scope1: 			scope1Impact,
												Scope2: 			scope2Impact,
												Scope3: 			scope3Impact,
												Total: 				totalEmissionsImpact
											},									
											naturalVolume: 			naturalVolumeImpact,
											baselineNaturalVolume: 	baselineNaturalVolume,
											source: 				impactFrom.source,
										}
									})
								}
								// 2a. Re-loop to get cumulative (reduction) impact of all activities
								impactFrom.reductionByActivity.forEach((activityObj, i) => {
									const activity  		= activityObj.activity, 
										activityData 		= activityOutflowImpact[activityCounter][activity],
										cumCostImpact 		= outflowObj.costSaving.map((d, i) => d + activityData.costSaving[i]),
										cumScope1Impact		= outflowObj.emissionsReduction.Scope1.map( (d, i) => d + activityData.emissionsReduction.Scope1[i] ),
										cumScope2Impact		= outflowObj.emissionsReduction.Scope2.map( (d, i) => d + activityData.emissionsReduction.Scope2[i] ),
										cumScope3Impact		= outflowObj.emissionsReduction.Scope3.map( (d, i) => d + activityData.emissionsReduction.Scope3[i] ),
										cumTotalEmissionsImpact		= outflowObj.emissionsReduction.Total.map( (d, i) => d + activityData.emissionsReduction.Total[i] ),
										cumNaturalVolsImpact		= outflowObj.naturalVolume.map( (d, i) => d + activityData.naturalVolume[i] ),
										cumBaselineNaturalVols		= outflowObj.baselineNaturalVolume.map( (d, i) => d + activityData.baselineNaturalVolume[i] )
									activityCounter++
									outflowObj = {
										costSaving: 			cumCostImpact,
										emissionsReduction: 	{
											Scope1: 			cumScope1Impact,
											Scope2: 			cumScope2Impact,
											Scope3: 			cumScope3Impact,
											Total: 				cumTotalEmissionsImpact
										},
										naturalVolume: 			cumNaturalVolsImpact,
										baselineNaturalVolume: 	cumBaselineNaturalVols,
										naturalUnit: 			impactRefCaseFrom.naturalUnit,
										source: 				impactFrom.source,
									}
									impactOutflow.push(outflowObj)
								})

								//  2b. Update the sitegroup electricity for all efficiency and switch actions before assessing generation (solar) options.
									// Note: action impact hierarchy is enforced by the actionIDs: Electricity related actions with types of 'efficiency' (and 'switch') need to have a lower ID number (than 'generation' and 'offset') to execute first
									// Electrification switches at 'All of agency' level won't actually matter (as solar is modelled at sitegroup level) 
									const totalElecConsumption = impactOutflow.filter(d => d.source === 'Grid electricity').map(d => d.naturalVolume).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
									if(sitegroupElecConsumption && totalElecConsumption.length > 0 && elecActionIDs.indexOf(actionID) < 0){
										sitegroupElecConsumption = sitegroupElecConsumption.map( (d,i) => d - totalElecConsumption[i])
										elecActionIDs.push(actionID)
									}				
								break

							case 'generation':		
								const totalNoSites 					= impactRefCaseFrom.siteNames.length,	 			
									kWPerSite 	 					= actionSettings.opportunity.sizekWPerSite,
									targetUptake 					= actionSettings.opportunity.targetUptake,
									noSites 						= totalNoSites * targetUptake,
									generationMWh 					= model.parameters.general.CF_SolarIrradiance_MWh_per_kW.value.map(d => d * noSites * kWPerSite),
									solarLoadMatchPct 				= model.parameters.typology[sitegroup]['SOLAR - Matched load'],
									solarMatchedMWh     			= sitegroupElecConsumption.map( d => d * solarLoadMatchPct  * targetUptake)

								generationMWh.forEach((generatedMWh, i) => {
									if(generatedMWh > solarMatchedMWh[i]){ 			
										exportedElecMWh[i] = generatedMWh - solarMatchedMWh[i]  			
										onSiteConsumptionMWh[i] = solarMatchedMWh[i] 					
									}  else {
										exportedElecMWh[i] = 0	
										onSiteConsumptionMWh[i] = generatedMWh 	
									}
								})

								impactOutflow = [{
									costSaving: 			impactRefCaseFrom.modelledTariff.map( (d, i) => d * onSiteConsumptionMWh[i]),
									emissionsReduction: 	{
										Scope1: 			onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
										Scope2: 			onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
										Scope3: 			onSiteConsumptionMWh.map( (d, i) => d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
										Total: 				onSiteConsumptionMWh.map( (d, i) => d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i]) )
									},
									naturalVolume: 		onSiteConsumptionMWh,
									naturalUnit: 		impactRefCaseFrom.naturalUnit,
									source: 			impactFrom.source,
								}]
								// Record solar
								model.action.summaryCount[agency][sitegroup]['solar'] = {
									modelledCapacitykW: 		noSites * kWPerSite * targetUptake,
									modelledPenetration: 		targetUptake,
									modelledNoSites: 			noSites * targetUptake,
									modelledSitekWPerSite: 		kWPerSite,
									"Solar exported": 			exportedElecMWh,	
									"Solar consumed": 			onSiteConsumptionMWh,
									"Solar generated": 			generationMWh,
									modelledExportPct: 			d3.sum(exportedElecMWh) / (d3.sum(exportedElecMWh) + d3.sum(onSiteConsumptionMWh)),
									totalNoSites: 				noSites										
								}		
								//  Update the sitegroup electricity before assessing PPA opportunity
								if(impactFrom.source === 'Grid electricity' && elecActionIDs.indexOf(actionID) < 0){
									sitegroupElecConsumption = sitegroupElecConsumption.map( (d,i) => d - onSiteConsumptionMWh[i] )
									elecActionIDs.push(actionID)
								}
								break

							case 'offset':		
								const targetPerSite 	= actionSettings.opportunity.targetUptake							
								impactOutflow = [{
									costSaving: 			sitegroupElecConsumption.map((d,i) => d * impactRefCaseFrom.modelledTariff[i] * targetPerSite),
									emissionsReduction: 	{
										Scope1: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope2: 			Array(dataModel.schema.modelHorizon).fill(0),
										Scope3: 			Array(dataModel.schema.modelHorizon).fill(0),
										Total: 				Array(dataModel.schema.modelHorizon).fill(0)
									},
									naturalVolume: 			sitegroupElecConsumption.map(d => d * targetPerSite),
									baselineNaturalVolume: 	sitegroupElecConsumption.map(d => d * targetPerSite),
									naturalUnit: 			impactRefCaseFrom.naturalUnit,
									source: 				impactFrom.source
								}]
								break
						}
					}
				}

				// 2. GENERATION OR FUEL SWITCH IMPACT >> STOCK INFLOW		
				if((actionParameters.impact.type.toLowerCase() !== 'efficiency' || actionParameters.impact.type.toLowerCase() !== 'reduction') && typeof referenceCaseFrom !== 'undefined'){
					actionParameters.impact.to.forEach(impactTo => {
						switch(actionParameters.impact.type.toLowerCase()){
							case 'switch':	
								// a. Calculate switch impact (if there was an outflow object recorded)
								if(impactOutflow.length > 0){ 
									switchToCase = model.inventory.switchToCase.byAgency_sitegroup[agency][sitegroup][impactTo.sector][impactTo.source]
									const outflowNaturalVolume  = [...new Set(impactOutflow.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
										conversionFactor 		= model.parameters.general[impactTo.cf].value,
										sourceEF 				= model.parameters.emissionFactors[impactTo.sourceEF],
										newConsumption 			= outflowNaturalVolume.map( (d, i) => d * conversionFactor[i]),
										price 					= model.parameters.general[impactTo.price].value.map(d => d * model.parameters.general[impactTo.price].unitMultiplier),
										cost 					= newConsumption.map( (d, i) => d * price[i]),
										newScope1 				= newConsumption.map( (d, i) => d * sourceEF.scope1[i]),
										newScope2 				= newConsumption.map( (d, i) => d * sourceEF.scope2[i]),
										newScope3 				= newConsumption.map( (d, i) => d * sourceEF.scope3[i]),
										newTotal 				= newConsumption.map( (d, i) => d * (sourceEF.scope1[i] + sourceEF.scope2[i] + sourceEF.scope3[i]) )

									impactInflow.push({
										benefit: 			Array(dataModel.schema.modelHorizon).fill(0),
										cost: 				cost,
										emissions: { 		 // Push switch impact as negative reduction
											Scope1: 		newScope1,
											Scope2: 		newScope2,
											Scope3: 		newScope3,
											Total: 			newTotal
										},
										emissionsReduction: 	{
											Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
											Total: 			Array(dataModel.schema.modelHorizon).fill(0)
										},
										emissionsSinks: 	{
											Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
											Total: 			Array(dataModel.schema.modelHorizon).fill(0)
										},
										emissionsSinksBySource: {
											Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
											Total: 			Array(dataModel.schema.modelHorizon).fill(0)
										},
										naturalVolume: 		newConsumption,
										source: 			impactTo.source
									})
								}
								break

							case 'generation':
								if( typeof model.action.summaryCount[agency][sitegroup]['solar'] !== 'undefined' &&  Object.keys(model.action.summaryCount[agency][sitegroup]['solar']).length > 0){
									const noSites 	 	  = model.action.summaryCount[agency][sitegroup]['solar'].totalNoSites,
										kWPerSite 	 	  = actionSettings.opportunity.sizekWPerSite,
										targetUptake 	  = actionSettings.opportunity.targetUptake,
										sourceProportion  = d3.sum(model.action.summaryCount[agency][sitegroup]['solar']['Solar generated']) === 0 ? 0 : d3.sum(model.action.summaryCount[agency][sitegroup]['solar'][impactTo.source]) / d3.sum(model.action.summaryCount[agency][sitegroup]['solar']['Solar generated']),
										sourceElecMWh 	  = model.parameters.general.CF_SolarIrradiance_MWh_per_kW.value.map(d => d * noSites * kWPerSite * targetUptake * sourceProportion),
										sourceType 		  = dataModel.schema.inventory[impactTo.sector][impactTo.source].type										
									impactInflow.push({
										cost: 				Array(dataModel.schema.modelHorizon).fill(0),
										benefit: 			sourceElecMWh.map( (d, i) => d * (impactTo.source.toLowerCase() === 'solar exported' ? model.parameters.general.price_SolarFeedIn.value[i] : 0 ) ),
										emissionsReduction: 	{
											Scope1: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope1[i] ),
											Scope2: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope2[i] ),
											Scope3: 		sourceElecMWh.map( (d, i) => d * model.parameters.emissionFactors.EF_Zero_Emissions.scope3[i] ),
											Total: 			sourceElecMWh.map( (d, i) => d * (model.parameters.emissionFactors.EF_Zero_Emissions.scope1[i] + model.parameters.emissionFactors.EF_Zero_Emissions.scope2[i] + model.parameters.emissionFactors.EF_Zero_Emissions.scope3[i]) )
										},
										emissionsSinks: 	{
											Scope1: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] : 0 ) ),
											Scope2: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] : 0 ) ),
											Scope3: 		sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] : 0 ) ),
											Total: 			sourceElecMWh.map( (d, i) => d * (sourceType === 'sink' ? - (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i]) : 0 ) )
										},	
										emissionsSinksBySource: {
											Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
											Total: 			Array(dataModel.schema.modelHorizon).fill(0)
										},	
										naturalVolume: 		sourceElecMWh,
										source: 			impactTo.source,
									})
								}																		
								break

							case 'offset':
								// For a PPA like switch									
								const pctSourcePerSite 	  = actionParameters.opportunity[sitegroup].targetUptake, 						// Always 100% per site
									outflowNaturalVolume 		= [...new Set(impactOutflow.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
									referenceCaseFromTariff 	= [...new Set(referenceCaseFrom.map(obj => obj.modelledTariff))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
									impactInflow.push({
										benefit: 			Array(dataModel.schema.modelHorizon).fill(0),
										cost: 				outflowNaturalVolume.map((d, i) => d * (referenceCaseFromTariff[i] + settings.parameters.general.price_PPA.value[i]) ),
										emissionsReduction: 	{
											Scope1: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope2: 		Array(dataModel.schema.modelHorizon).fill(0),
											Scope3: 		Array(dataModel.schema.modelHorizon).fill(0),
											Total: 			Array(dataModel.schema.modelHorizon).fill(0)
										},
										emissionsSinks: 	{
											Scope1: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
											Scope2: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
											Scope3: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
											Total: 			outflowNaturalVolume.map((d, i) => -d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ))
										},	
										emissionsSinksBySource: {
											Scope1: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] ),
											Scope2: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] ),
											Scope3: 		outflowNaturalVolume.map((d, i) => -d * settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ),
											Total: 			outflowNaturalVolume.map((d, i) => -d * (settings.parameters.emissionFactors.agencyGridEF[agency].scope1[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope2[i] + settings.parameters.emissionFactors.agencyGridEF[agency].scope3[i] ))
										},																
										naturalVolume: 		Array(dataModel.schema.modelHorizon).fill(0),
										source: 			impactTo.source,
									})		
								break
						}
					})
				}

				// 3. ADD THE COMPLETED ACTION IMPACT OBJECT
				if(typeof referenceCaseFrom !== 'undefined'  && d3.sum([...new Set(referenceCaseFrom.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ) > 0){ 
					// I. CALC NET IMPACTS OBJECT IMPACT DATA
					const reducedNaturalVolume = 	d3.nest().key(d => d.source).entries(impactOutflow).map(d => { 
														return { 
															[d.key] : d.values.map(d => d.naturalVolume).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
														}
													}),
						outflowEmissionsReductionScope1   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						outflowEmissionsReductionScope2   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						outflowEmissionsReductionScope3   = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						outflowEmissionsReductionTotal 	  = [...new Set(impactOutflow.map(obj => obj.emissionsReduction.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						outflowSources = [...new Set(impactOutflow.map(obj => obj.source))],
						emissionsNew  = {  	// NEW EMISSIONS FROM SWTICHED TO FUELS
							Scope1: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Scope2: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Scope3: 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Total: 	 	 impactInflow.length === 0 || typeof(impactInflow[0].emissions) === 'undefined' ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissions.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
						},
						emissionsSinks = {  		// EMISISONS SINKS (OFFSETS)
							Scope1: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope1))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Scope2: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope2))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Scope3: 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Scope3))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) ,
							Total: 	 	 impactInflow.length === 0 ? Array(dataModel.schema.modelHorizon).fill(0) : [...new Set(impactInflow.map(obj => obj.emissionsSinks.Total))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []) 
						},
						emissionsReduction = { 		// NET REDUCTIONS: EFFICIENCY/GENERATION/SWITCH FROM OUTLFOW - (NEG SINKS) - NEW SWITCH TO
							Scope1: 	 outflowEmissionsReductionScope1.map( (d,i) => d - emissionsNew.Scope1[i] - emissionsSinks.Scope1[i] ),
							Scope2: 	 outflowEmissionsReductionScope2.map( (d,i) => d - emissionsNew.Scope2[i] - emissionsSinks.Scope2[i]),
							Scope3:  	 outflowEmissionsReductionScope3.map( (d,i) => d - emissionsNew.Scope3[i] - emissionsSinks.Scope3[i]),
							Total: 	 	 outflowEmissionsReductionTotal.map( (d,i) => d - emissionsNew.Total[i] - emissionsSinks.Total[i])
						},
						emissionsRedExSinks  = {  	// NET REDUCTION (FLOWS) EX SINKS
							Scope1: 	 emissionsReduction.Scope1.map((d, i) => d + emissionsSinks.Scope1[i]),
							Scope2: 	 emissionsReduction.Scope2.map((d, i) => d + emissionsSinks.Scope2[i]),
							Scope3: 	 emissionsReduction.Scope3.map((d, i) => d + emissionsSinks.Scope3[i]),
							Total: 	 	 emissionsReduction.Total.map((d, i) => d + emissionsSinks.Total[i])
						},
						emissionsGrossReduction = {
							Scope1: 	 emissionsSinks.Scope1.map((d, i) => -d + emissionsRedExSinks.Scope1[i]),
							Scope2: 	 emissionsSinks.Scope2.map((d, i) => -d + emissionsRedExSinks.Scope2[i]),
							Scope3:  	 emissionsSinks.Scope3.map((d, i) => -d + emissionsRedExSinks.Scope3[i]),
							Total: 	 	 emissionsSinks.Total.map((d, i)  => -d + emissionsRedExSinks.Total[i])
						}

						emissionsReductionBySource = {},	
						emissionsSinksBySource = {},									
						discountedNetEmissionsImpact = emissionsReduction.Total.map( (d,i) => (d  / settings.parameters.financial["Discount factor"][i])),
						switchToNaturalVolume 		 = actionParameters.impact.type.toLowerCase() !== 'switch' ? Array(dataModel.schema.modelHorizon).fill(0) 
														:  impactInflow[0].naturalVolume 	// This assumes only one switched to item
						// Initiate and record the  total emissions reduction by source
						outflowSources.forEach(source => emissionsReductionBySource[source] = {
							Scope1: 	 Array(dataModel.schema.modelHorizon).fill(0),
							Scope2: 	 Array(dataModel.schema.modelHorizon).fill(0),
							Scope3:  	 Array(dataModel.schema.modelHorizon).fill(0),
							Total: 	 	 Array(dataModel.schema.modelHorizon).fill(0),
						})																
						for( const obj of impactOutflow){
							emissionsReductionBySource[obj.source] = {
								Scope1: 	emissionsReductionBySource[obj.source].Scope1.map((d,i) => d + obj.emissionsReduction.Scope1[i]) ,
								Scope2: 	emissionsReductionBySource[obj.source].Scope2.map((d,i) => d + obj.emissionsReduction.Scope2[i] ) ,
								Scope3:  	emissionsReductionBySource[obj.source].Scope3.map((d,i) => d + obj.emissionsReduction.Scope3[i]) ,
								Total: 	 	emissionsReductionBySource[obj.source].Total.map((d,i) => d + obj.emissionsReduction.Total[i]) ,
							}
						}
						// Initiate and record the emissions sinks by source												
						for( const obj of impactInflow){
							if(typeof emissionsSinksBySource[obj.source] === 'undefined'){
								emissionsSinksBySource[obj.source] = {
									Scope1: 	 Array(dataModel.schema.modelHorizon).fill(0),
									Scope2: 	 Array(dataModel.schema.modelHorizon).fill(0),
									Scope3:  	 Array(dataModel.schema.modelHorizon).fill(0),
									Total: 	 	 Array(dataModel.schema.modelHorizon).fill(0),
								}
							}
							emissionsSinksBySource[obj.source] = {
								Scope1: 	emissionsSinksBySource[obj.source].Scope1.map((d,i) => d + obj.emissionsSinks.Scope1[i]) ,
								Scope2: 	emissionsSinksBySource[obj.source].Scope2.map((d,i) => d + obj.emissionsSinks.Scope2[i] ) ,
								Scope3:  	emissionsSinksBySource[obj.source].Scope3.map((d,i) => d + obj.emissionsSinks.Scope3[i]) ,
								Total: 	 	emissionsSinksBySource[obj.source].Total.map((d,i) => d + obj.emissionsSinks.Total[i]) ,
							}
						}
					// II. UPDATE THE IMPACT DATA
					const obj = model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID] 
						obj.impact.outflow 						= impactOutflow
						obj.impact.inflow 						= impactInflow
						obj.impact.emissionsRedExSinks 			= emissionsRedExSinks
						obj.impact.emissionsSinks 				= emissionsSinks
						obj.impact.emissionsSinksBySource 		= emissionsSinksBySource
						obj.impact.emissionsGrossReduction 		= emissionsGrossReduction
						obj.impact.emissionsReduction 			= emissionsReduction
						obj.impact.emissionsReductionBySource	= emissionsReductionBySource
						obj.impact.emissionsNew 				= emissionsNew
						obj.impact.reducedNaturalVolume 		= reducedNaturalVolume
						obj.impact.byActivity.outflow 			= activityOutflowImpact
						obj.impact.byActivity.inflow 			= activityInflowImpact

					// III. MODEL AND ADD THE BUSINESS CASE	å
					const refCaseFromNaturalVol 		= [...new Set(referenceCaseFrom.map(obj => obj.naturalVolume))].reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						refCaseFromSiteCount 			= d3.max([...new Set(referenceCaseFrom.map(obj => obj.siteNames))].map(d => d.length)),
						targetUptake 					= actionSettings.opportunity.targetUptake, 
						agencyIndexOfCustomSiteData 	= data.siteDataSitegroupByAgency.map(d => d.key).indexOf(agency),
						actionSource 					= actionParameters.impact.from[0].source,
						actionType 						= actionParameters.impact.type,
						actionAsset 					= actionParameters.impact.asset,
						customSiteDataSitegroup 		= agencyIndexOfCustomSiteData > -1 ? data.siteDataSitegroupByAgency[agencyIndexOfCustomSiteData].value[sitegroup] : null,
						customSiteCount 				= customSiteDataSitegroup ? customSiteDataSitegroup[actionSource] : null,
						totalNoSites 					= customSiteCount ? customSiteCount :  refCaseFromSiteCount,
						noSites 						= sitegroup === 'All of agency' ? 1 : totalNoSites * targetUptake,
						avoidedCostBySource 			=  d3.nest().key(d => d.source).entries(impactOutflow).map( d => {  
															return { [d.key] :  d.values.map(d=> d.costSaving).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
																					.slice(0, actionSettings.economicLife)
																					.map( d => targetUptake === 0 ? 0 : d / noSites) } 
														})

						ouflowCostSavings 				= impactOutflow.map(obj => obj.costSaving).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
						avoidedCost 					= ouflowCostSavings.slice(0, actionSettings.economicLife).map( d => targetUptake === 0 || noSites === 0 ? 0 : d / noSites),
						additionalCost					= impactInflow.length > 0 ?	impactInflow[0].cost.slice(0, actionSettings.economicLife).map( d => noSites === 0 ? 0 : d / noSites) :  Array(dataModel.schema.modelHorizon).fill(0),
						revenueByInflow 				= impactInflow.length > 0 ?	Array(actionSettings.economicLife).fill(0) : impactInflow.map(obj => obj.benefit).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []).slice(0, actionSettings.economicLife).map( d =>  d / noSites),													
						baselineVolPerSite 				= refCaseFromNaturalVol.map( d => d / totalNoSites)[0]

					let	capitalCost						= Array(actionSettings.economicLife).fill(0),
					 	omCost 							= Array(actionSettings.economicLife).fill(0),
						netCashFlow

					// Add the capital cost from settings
					switch(actionParameters.impact.type.toLowerCase()){
						case 'efficiency':
						case 'reduction':
						case 'switch':
							capitalCost[0] = targetUptake === 0 ? 0 : actionSettings.cost.capitalCost 
							omCost 	= Array(actionSettings.economicLife).fill(targetUptake === 0 ? 0 : actionSettings.cost.omCost)
							break
						case 'generation':
							capitalCost[0] = targetUptake === 0 ? 0 : actionSettings.cost.capitalCost 
							omCost 	= Array(actionSettings.economicLife).fill(targetUptake === 0 ? 0 : actionSettings.cost.omCost)		
							break
						case 'offset':
							capitalCost[0] = targetUptake === 0 ? 0 : actionSettings.cost.capitalCost 
							omCost 	= Array(actionSettings.economicLife).fill(targetUptake === 0 ? 0 : actionSettings.cost.omCost)
							break
					}

					// Add avoided cost and revenue if they apply
					netCashFlow = capitalCost.map((d,i) => - d - omCost[i])
					if(avoidedCost.length > 0){
						netCashFlow = netCashFlow.map( (d, i) => d + avoidedCost[i])
					} 
					if(revenueByInflow.length > 0){
						netCashFlow = netCashFlow.map( (d, i) => d + revenueByInflow[i])
					}
					if(additionalCost.length > 0){
						netCashFlow = netCashFlow.map( (d, i) => d - additionalCost[i])
					}	

					const discountedCashFlow = netCashFlow.map( (d, i) =>  d / settings.parameters.financial["Discount factor"][i]),
						cumNetCF 		= netCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
						cumDCF 			= discountedCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),
						npv 			= d3.sum(discountedCashFlow.slice(0, actionSettings.economicLife)),						
						abatementNPV 	= d3.sum(discountedNetEmissionsImpact.slice(0, actionSettings.economicLife)) / noSites,						
						levelisedCost	= (npv === 0 || abatementNPV === 0) ? 0 : - npv  / abatementNPV
				
					obj.businessCase = {
						"Cashflow items": 	{
							"Marginal capital cost": 						capitalCost,
							"Marginal operations and maintenance cost": 	omCost,
							"Avoided cost": 								avoidedCost,
							"Avoided cost by source": 						avoidedCostBySource,
							"Additional cost": 								additionalCost,
							"Revenue": 										revenueByInflow
						},
						"Net cash flow":	 								netCashFlow,
						"Discounted cash flow":								discountedCashFlow,
						"Cumulative cash flow": 							cumNetCF,
						"Cumulative DCF": 									cumDCF,
						"Emissions abatement": 								emissionsReduction.Total.slice(0, actionSettings.economicLife),
						"Natural volume abatement": 						reducedNaturalVolume.map(d => {return {[Object.keys(d)] : Object.values(d)[0].slice(0, actionParameters.meta.life)} }) ,
						"Natural volume new consumption (fuel switch)": 	switchToNaturalVolume.slice(0, actionParameters.meta.life),
						"Modelled tariffs":{
							"Added": 										actionParameters.impact.type.toLowerCase() === 'switch' ?  model.parameters.general[actionParameters.impact.to[0].price].value : null,
							"Added unit": 									actionParameters.impact.type.toLowerCase() === 'switch' ?  '$'+model.parameters.general[actionParameters.impact.to[0].price].unit : null,
							"Avoided": 										actionParameters.meta.sector === "Waste" ?  [Array(dataModel.schema.modelHorizon).fill(0)] : referenceCaseFrom.map(obj => obj.modelledTariff),
							"Avoided unit": 								referenceCaseFrom.map(obj => obj.tariffUnit),
							"Revenue": 										actionParameters.impact.type.toLowerCase() === 'generation' ? model.parameters.general.price_SolarFeedIn.value : null, 		// Only ever solar feedin so this is hard coded
							"Revenue unit": 								actionParameters.impact.type.toLowerCase() === 'generation' ? '$'+model.parameters.general.price_SolarFeedIn.unit : null, 	// and only accesssed for solar PV actions with export
						},						
						"Metrics": {
							"NPV": 											npv,
							"IRR": 											helpers.IRR(netCashFlow, 0),
							"Simple payback": 								helpers.payback(cumNetCF, actionSettings.economicLife),
							"Discounted payback": 							helpers.payback(cumDCF, actionSettings.economicLife),
							"Levelised cost of abatement": 					levelisedCost,
							"abatementNPV": 								abatementNPV
						}
					}
					// Update the action uptake
					await updateActionUptake(actionID, agency, sitegroup, "Update action")		
				}
			}
		}; // end updateAction()
	
		// UPDATE AN INDIVIDUAL ACTION MODEL UPTAKE
		async function updateActionUptake(actionID, agency, sitegroup, calledFrom){		
			if(settings.action.byAgency_sitegroup[agency][sitegroup][actionID]){
				const newUptake = settings.action.byAgency_sitegroup[agency][sitegroup][actionID].uptake,
					actionModel = model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]
				model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'] = {
					uptakePct: 				newUptake,
					emissionsRedExSinks: {
						Scope1: 			actionModel.impact.emissionsRedExSinks.Scope1.map((d, i) => d * newUptake[i] ),
						Scope2: 			actionModel.impact.emissionsRedExSinks.Scope2.map((d, i) => d * newUptake[i] ),
						Scope3: 			actionModel.impact.emissionsRedExSinks.Scope3.map((d, i) => d * newUptake[i] ),
						Total: 				actionModel.impact.emissionsRedExSinks.Total.map((d, i) => d * newUptake[i] )
					},
					emissionsSinks: {
						Scope1: 			actionModel.impact.emissionsSinks.Scope1.map((d, i) => d * newUptake[i] ),
						Scope2: 			actionModel.impact.emissionsSinks.Scope2.map((d, i) => d * newUptake[i] ),
						Scope3: 			actionModel.impact.emissionsSinks.Scope3.map((d, i) => d * newUptake[i] ),
						Total: 				actionModel.impact.emissionsSinks.Total.map((d, i) => d * newUptake[i] )
					},	
					emissionsReduction: {
						Scope1: 			actionModel.impact.emissionsReduction.Scope1.map((d, i) => d * newUptake[i] ),
						Scope2: 			actionModel.impact.emissionsReduction.Scope2.map((d, i) => d * newUptake[i] ),
						Scope3: 			actionModel.impact.emissionsReduction.Scope3.map((d, i) => d * newUptake[i] ),
						Total: 				actionModel.impact.emissionsReduction.Total.map((d, i) => d * newUptake[i] )
					},		
					emissionsReductionBySource: {},
					emissionsSinksBySource: {},
					reducedNaturalVolume: 	actionModel.impact.reducedNaturalVolume.map(d => {return {[Object.keys(d)] : Object.values(d)[0].map((d, i) => d * newUptake[i])} }),										
					addedNaturalVolume: 	actionModel.impact.addedNaturalVolume.map((d, i) => d * newUptake[i]),
				}	

				Object.entries(actionModel.impact.emissionsReductionBySource).forEach(([source, obj]) => {
					model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'].emissionsReductionBySource[source] = {
							Scope1: 		obj.Scope1.map((d, i) => d * newUptake[i]),
							Scope2: 		obj.Scope2.map((d, i) => d * newUptake[i]),
							Scope3: 		obj.Scope3.map((d, i) => d * newUptake[i]),
							Total: 			obj.Total.map((d, i) => d * newUptake[i]),
						}
					}
				)
				Object.entries(actionModel.impact.emissionsSinksBySource).forEach(([source, obj]) => {
					model.action.businessCase.byAgency_sitegroup[agency][sitegroup][actionID]['uptakeModel'].emissionsSinksBySource[source] = {
							Scope1: 		obj.Scope1.map((d, i) => d * newUptake[i]),
							Scope2: 		obj.Scope2.map((d, i) => d * newUptake[i]),
							Scope3: 		obj.Scope3.map((d, i) => d * newUptake[i]),
							Total: 			obj.Total.map((d, i) => d * newUptake[i]),
						}
					}
				)
			}
		}; // end updateActionUptake()

	// UPDATE THE ACTION CASE
	async function updateActionCase(){
		await buildActionAndSwitchToCase(true)
	}; // end updateActionCase()


////////////////////////////////////////////////
/// 4. USER INTERFACE AND NAVIGATION METHODS ///
////////////////////////////////////////////////

	// Add UI 
    async function addUserInterface(){
    	console.log('***** 4. ADDING USER INTERFACE ******')
	    ui.methods.nav.createClusterDropdown(dataModel.schema.interface.clusterList)    
	    ui.scenes.forEach( scene => { ui.methods.nav.createAgencyDropdown(scene+'-agencySelector', dataModel.schema.typologyMapping.modelAgencyList)	})  	
	    ui.methods.nav.createSettingsPage()
	    ui.methods.nav.createAboutSection()
	    ui.methods.nav.addNavListeners()  
    };

    // UI METHODS
	    // Create Settings page 
	    ui.methods.nav.createSettingsPage = () => {
	    	// 1. Add Target year
    		d3.select('#settings-modelHorizon').attr('value', settings.parameters.horizon)
				.on('change', async function(){
					settings.parameters.horizon = +this.value
					dataModel.uptake.updatePresets()
					await renderWedgesChart('pathways-vis', 'main')	
				})
	    	// 2. Add WACC
    		const waccData = settings.parameters.general.wacc
    		d3.select('#settings-wacc').attr('value', waccData.value * 100)
    			.on('change', function(){
    				settings.parameters.general.wacc.value = this.value/100
					settings.parameters.financial["Discount factor"] = Array(dataModel.schema.modelHorizon).fill(0).map( (d, i) => Math.pow((1 + settings.parameters.general.wacc.value), i) ) 
					ui.state.pendingActionCaseRecalc = true									
					ui.state.pendingChartUpdate = true	    				
    			})
	    	// 3. Add prices
    		ui.userSettings.financial.forEach(priceID => {
    			const priceData =  settings.parameters.general[priceID]
				d3.select('#settings-'+priceID).attr('value', priceData.value[0])
					.on('change', async function(){
						priceData.value = priceData.value.map(d => d * this.value	/ priceData.value[0] )						
						await updateReferenceCase()
						ui.state.pendingActionCaseRecalc = true									
						ui.state.pendingChartUpdate = true	
	    			})
    		})
	    	// 4. Add emission factors
    		ui.userSettings.emissions.forEach(emissionsFactorID => {
    			const emissionsData =  model.parameters.emissionFactors[emissionsFactorID],
    				scopes = ['scope1', 'scope2', 'scope3'],
    				usedScopes = []
    			scopes.forEach(scope => { 
    				if(d3.sum(emissionsData[scope]) > 0) { 	usedScopes.push(scope)	} 
    			})
    			usedScopes.forEach( scope => {
    				d3.select('#settings-'+emissionsFactorID+'-'+scope).attr('value', emissionsData[scope][0])
    					.on('change', async function(){						
							emissionsData[scope] = emissionsData[scope].map( d => d * this.value / emissionsData[scope][0])	
							await updateReferenceCase()
							ui.state.pendingActionCaseRecalc = true									
							ui.state.pendingChartUpdate = true	
		    			})
    			}) 				
    		})
	    	// 5. Add conversion factors
    		ui.userSettings.conversion.forEach(conversionID => {
    			const conversionData =  settings.parameters.general[conversionID]
				d3.select('#settings-'+conversionID).attr('value', conversionData.value[0])
					.on('change', async function(){
						conversionData.value = conversionData.value.map(d => d * this.value	/ conversionData.value[0] )						
						await updateReferenceCase()
						ui.state.pendingActionCaseRecalc = true									
						ui.state.pendingChartUpdate = true	
	    			})
			})

	    	// Add hover functionality for information
			d3.selectAll('.settingsHoverDetails')
				.on('click', function(){
					const parameterID = this.getAttribute('paramID'),
						parameterType = this.getAttribute('paramType'),
						paramData = model.parameters[parameterType][parameterID]
					d3.select('#settings-highlighted')
						.html('About '+paramData.name)
						.transition().duration(500).style('opacity', 1)
					d3.select('#settings-description-highlighted')
						.html(paramData.description)
						.transition().duration(500).style('opacity', 1)
				})
				.on('mouseout', () => { 
					d3.selectAll('#settings-highlighted, #settings-description-highlighted')
						.transition().duration(500).style('opacity', 0)
				})
	    }; 

	    // Update settings page
	    ui.methods.nav.updateSettingsPage = () => {
    		d3.select('#settings-modelHorizon').attr('value', settings.parameters.horizon)
    		d3.select('#settings-wacc').attr('value', settings.parameters.general.wacc.value * 100)
    		ui.userSettings.financial.forEach(priceID => { d3.select('#settings-'+priceID).attr('value', settings.parameters.general[priceID].value[0]) })
	    	// 4. Add emission factors
    		ui.userSettings.emissions.forEach(emissionsFactorID => {
    			const emissionsData =  model.parameters.emissionFactors[emissionsFactorID],
    				scopes = ['scope1', 'scope2', 'scope3'],
    				usedScopes = []
    			scopes.forEach(scope => { 
    				if(d3.sum(emissionsData[scope]) > 0) { 	usedScopes.push(scope)	} 
    			})
    			usedScopes.forEach( scope => {
    				d3.select('#settings-'+emissionsFactorID+'-'+scope).attr('value', emissionsData[scope][0])
    			}) 				
    		})
	    }; 

	    // Create About tool page
	    ui.methods.nav.createAboutSection = () => {
	    	const container = d3.select('#about-mainPain'),
	    		menu = d3.select('#about-menu'),
	    		contentBySection = d3.nest()
	    			.key( d => d.section)
	    			.entries(content.about),
	    		defaultSection = contentBySection[0].key
    			
	    	contentBySection.forEach(sectionContent => {
	    		container.append('div').attr('id', 'about-sectionContainer-'+sectionContent.key)
		    		.classed('about-sectionContainer hidden', true)
	    		sectionContent.values.forEach(contentObj => {
				  d3.select('#about-sectionContainer-'+contentObj.section).append('div')
				 	.classed('about-sectionContainer', true)
				  	.attr('id', contentObj.id)  		
				  	.attr('class', 'about-'+contentObj.type)  		
				  	.html(contentObj.content)  	

					if(contentObj.type === 'header'){
					 	menu.append('div').classed('about-menu-option', true)
					 		.attr('id', 'about-menu-option-'+contentObj.section)
					 		.attr('section', contentObj.section)
					 		.html('&#8594; '+contentObj.content)
					 		.on('click', function(){
					 			d3.selectAll('.about-menu-option').classed('selected', false)
					 			d3.select(this).classed('selected', true)
					 			d3.selectAll('.about-sectionContainer').classed('hidden', true)
					 			d3.select('#about-sectionContainer-'+d3.select(this).attr('section')).classed('hidden', false)
					 				.style('opacity', 0)
					 				.transition().duration(500)
					 				.style('opacity', null)					 			
					 		})
				 	}	
	    		})
	    	})

	    	// Set opening 
			d3.selectAll('.about-menu-option').classed('selected', false)
			d3.select('#about-menu-option-'+defaultSection).classed('selected', true)
			d3.selectAll('.about-sectionContainer').classed('hidden', true)
			d3.select('#about-sectionContainer-'+defaultSection).classed('hidden', false)	

			// Set up data dependent content and headers
			d3.selectAll('.emissions-boundary-text').html(
				`<p>Emissions are estimated from either consumption data:</p>
					<ul>
						<li>Sourced from  the CASPER database for the ${(dataModel.schema.baselineYear-1)} / ${(dataModel.schema.baselineYear-2000)} financial year (for Government electricity, gas and water)</li>
						<li>Supplied by individual agencies for waste, fleet transport and all Supply chain sources for the ${(dataModel.schema.baselineYear-1)} / ${(dataModel.schema.baselineYear-2000)} financial year.</li>
					</ul> 
					<p>The use of agency data on an 'as available' basis means that the coverage of inventory for those sources is limited.</p>
					
					<p>Greenhouse gas emissions - categorised by "Scope" - have been calculated by applying National Greenhouse Accounts (NGA) Factors for each source. 
						Solar data comes from the GREP projects database which tracks solar installations on Government sites from 2012/13.</p>`)
			d3.select('#inventory-header').html('Emissions by sector and source in '+(dataModel.schema.baselineYear-1)+'/'+(dataModel.schema.baselineYear-2000))
	    }; 	    

	    // Create Cluster dropdown list
	    ui.methods.nav.createClusterDropdown = (clusterList) => {
	        clusterList.forEach((agency, i) => {
	            d3.select('#viewLevel-selector').append('option')
	                .attr('value', 'cluster_'+i)
	                .html(agency)
	            d3.select('#header-clusterSelector').append('option')
	                .attr('value', 'cluster_'+i)
	                .html(agency)
	        })
	    };

	    // Create Agency dropdown list
	    ui.methods.nav.createAgencyDropdown = (selectorID, agencyList) => {
	    	d3.selectAll('#'+selectorID+' *').remove()
	    	d3.select('#'+selectorID).append('option')
	    		.attr('value', 'allAgency')
	    		.html(ui.state.clusterID === 'allClusters' ? 'All agencies' : 'All agencies under '+ui.state.clusterName)
	    	d3.select('#'+selectorID).append('option')
	    		.attr('disabled', true)
	    		.html('------------')
	        agencyList.forEach((agency, i) => {
	            d3.select('#'+selectorID).append('option')
	                .attr('value', 'agency_'+i)
	                .html(agency)
	        })
	    };

	    // Show/hide main menu (rotate to right of screen)
	    ui.methods.nav.toggleMainMenu = async function(){
	    	ui.elements.mainMenu.classList.remove('hidden')	    	
	    	ui.elements.infoPane.classList.add('hidden')	   
	    	ui.elements.detailsPane.classList.add('hidden')	 
	    	ui.elements.contentPane.classList.remove('effect-rotateLeft')
	    	ui.elements.contentPane.classList.add('effect-rotateRight')
	    	ui.elements.contentPane.classList.remove('effect-moveback')

	        if(ui.elements.contentPane.classList.contains('modalview')){
	            ui.elements.contentPane.classList.remove('modalview')
	            ui.elements.centralPane.removeEventListener("click", ui.methods.nav.toggleMainMenu )   	                         
	            ui.state.focus = "centralPane"
	            d3.select('#message-help-container')
	            	.style('transform', 'translateX(-10px)')
	            	.style('opacity', null)
	            	.transition().duration(750).delay(800)
	            	.style('transform', null)
	            		.transition().duration(750).delay(7250)
	            		.style('opacity', 0)	            		
	        } else {
	            ui.elements.contentPane.classList.add('modalview')
	            ui.state.focus = "mainMenu"            
	            setTimeout( () => ui.elements.centralPane.addEventListener("click", ui.methods.nav.toggleMainMenu), 500)
	        }
	        setTimeout( async() => { 
		        if(ui.state.pendingActionCaseRecalc) { 
	        		console.log('Updating action models and action case')
		        	await buildActionModels(true)
					await updateActionModel('Emissions reduction opportunities')
		        	await aggregateActionModels(true)  	
		        	await buildActionAndSwitchToCase(true)
		        }
		        if(ui.state.pendingChartUpdate){
		        	console.log('Updating charts')
		        	await updateWedgesChart('main')
		        	await updateCostCurve()
		        	ui.state.pendingChartUpdate = false
		        }		        
		    }, 750)		    
	    };

	    // Show/hide information pane (rotate to left of screen)
	    ui.methods.nav.toggleInformationView = async () => {
	    	d3.select('#infoPane-content-container').html(content.infoPane[ui.state.scene])
	    	ui.elements.mainMenu.classList.add('hidden')	    	
	    	ui.elements.infoPane.classList.remove('hidden')	    	
	    	ui.elements.detailsPane.classList.add('hidden')	
	    	ui.elements.contentPane.classList.remove('effect-rotateRight')
	    	ui.elements.contentPane.classList.add('effect-rotateLeft')
	    	ui.elements.contentPane.classList.remove('effect-moveback')	    	

	        if(ui.elements.contentPane.classList.contains('modalview')){
	            ui.elements.contentPane.classList.remove('modalview')
	            ui.elements.centralPane.removeEventListener("click", ui.methods.nav.toggleInformationView )                
	            ui.state.focus = "centralPane"
	        } else {
	            ui.elements.contentPane.classList.add('modalview')
	            ui.state.focus = "informationPage"            
	            setTimeout( () => ui.elements.centralPane.addEventListener("click", ui.methods.nav.toggleInformationView), 500)
	        }
	        setTimeout( async() => { 
		        if(ui.state.pendingActionCaseRecalc) { 
					await updateActionModel('Menu')
		        	await buildActionModels(true)
		        	await buildActionAndSwitchToCase(true)
		        	await aggregateActionModels(true)  	
		        	ui.state.pendingActionCaseRecalc = false
		        }
		    }, 750)
	    };

	    // Show/hide deatils pane (zoom screen back)
	    ui.methods.nav.toggleDetailsView = () => {
	    	ui.elements.mainMenu.classList.add('hidden')	    	
	    	ui.elements.infoPane.classList.add('hidden')	    	
	    	ui.elements.detailsPane.classList.remove('hidden')
	    	ui.elements.contentPane.classList.remove('effect-rotateRight')
	    	ui.elements.contentPane.classList.remove('effect-rotateLeft')
	    	ui.elements.contentPane.classList.add('effect-moveback')	  	

	        if(ui.elements.contentPane.classList.contains('modalview')){
	            ui.elements.contentPane.classList.remove('modalview')
	            ui.elements.centralPane.removeEventListener("click", ui.methods.nav.toggleInformationView )                
	            ui.state.focus = "centralPane"
	        } else {
	            ui.elements.contentPane.classList.add('modalview')
	            ui.state.focus = "informationPage"            
	            setTimeout( () => ui.elements.centralPane.addEventListener("click", ui.methods.nav.toggleInformationView), 500)
	        }
	    };

	    // Event listeners for navigation
	    ui.methods.nav.addNavListeners = async () => {
	    	// Cluster main view  dropdown
			ui.elements.clusterSelector.addEventListener("change",  async function(){
				ui.state.clusterID = this.value
				ui.state.clusterName = (ui.state.clusterID === "allClusters") ? "Whole of Government" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allClusters") ? "aggregate" : "cluster" 
				d3.select('#header-clusterSelector').style('opacity', null).style('pointer-events', null)
				if(ui.state.clusterID === "allClusters"){ document.querySelector('#action-agencySelector [value="allAgency"]').selected = true;	}
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }
				ui.methods.nav.changeClusterView(this)
	        	await ui.methods.dataView.updateAgencyActions()
			})   
			// Cluster header dropdown
			ui.elements.clusterHeader.addEventListener("change",  async function(){
				ui.state.clusterID = this.value
				ui.state.clusterName = (ui.state.clusterID === "allClusters") ? "Whole of Government" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allClusters") ? "aggregate" : "cluster" 
				if(ui.state.clusterID === "allClusters"){ document.querySelector('#action-agencySelector [value="allAgency"]').selected = true;	}
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }				
				ui.methods.nav.changeClusterView(this)	
	        	await ui.methods.dataView.updateAgencyActions()
				await updateWedgesChart('main')	
				await renderCostCurve()										
			})   
			// Inventory scene agency dropdown
			ui.elements.emissionsAgencySelector.addEventListener("change", async function(){
				ui.state.agencyID = this.value
				ui.state.agencyName = (ui.state.agencyID === "allAgency") ? "All agencies" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allAgency") ? "cluster" : "agency" 
				d3.select('#header-clusterSelector').style('opacity', 0).style('pointer-events', 'none')	
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }
				ui.methods.nav.changeAgencyView(this)		
	        	await ui.methods.dataView.updateAgencyActions()
			}) 
			// Action scene agency dropdown
			ui.elements.actionAgencySelector.addEventListener("change",  async function(){
				ui.state.agencyID = this.value
				ui.state.agencyName = (ui.state.agencyID === "allAgency") ? "All agencies" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allAgency") ? "cluster" : "agency" 
				ui.state.actionID = "none" 
				ui.state.sitegroup = "none" 
				d3.select('#header-clusterSelector').style('opacity', 0).style('pointer-events', 'none')
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }
				ui.methods.nav.changeAgencyView(this)			
	        	await ui.methods.dataView.updateAgencyActions()
			}) 
			// Pathways scene agency dropdown
			ui.elements.pathwaysAgencySelector.addEventListener("change", async function(){
				ui.state.agencyID = this.value
				ui.state.agencyName = (ui.state.agencyID === "allAgency") ? "All agencies" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allAgency") ? "cluster" : "agency" 
				ui.state.actionID = "none" 
				ui.state.sitegroup = "none" 				
				d3.select('#header-clusterSelector').style('opacity', 0).style('pointer-events', 'none')
				ui.methods.nav.changeAgencyView(this)
	        	await ui.methods.dataView.updateAgencyActions()
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }


				await updateActionModel('Pathways dropdown')
				await aggregateActionModels()
				await buildActionAndSwitchToCase(true)
	        	await updateWedgesChart('main')	

			}) 
			// Cost curve scene agency dropdown
			ui.elements.costCurveAgencySelector.addEventListener("change", async function(){
				ui.state.agencyID = this.value
				ui.state.agencyName = (ui.state.agencyID === "allAgency") ? "All agencies" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allAgency") ? "cluster" : "agency" 
				d3.select('#header-clusterSelector').style('opacity', 0).style('pointer-events', 'none')
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }
	        	await ui.methods.dataView.updateAgencyActions()
				ui.methods.nav.changeAgencyView(this)			
				await updateActionModel('Cost curve dropdown')
				await aggregateActionModels()
				await buildActionAndSwitchToCase(true)
				await updateCostCurve()
			}) 
			// Report scene agency dropdown
			ui.elements.reportAgencySelector.addEventListener("change", async function(){
				ui.state.agencyID = this.value
				ui.state.agencyName = (ui.state.agencyID === "allAgency") ? "All agencies" : this.options[this.selectedIndex].text
				ui.state.dataMode = (ui.state.agencyID === "allAgency") ? "cluster" : "agency" 
	        	if(!ui.state.modelsAggregated){  aggregateActionModels() }
	        	await ui.methods.dataView.updateAgencyActions()
				await ui.methods.updateReport()						
			}) 
			// Main menu options
			d3.selectAll('.menuOption').on("click",  ui.methods.nav.changeContentView)
			// Details buttons
			d3.selectAll('.detailsButton').on("click",  ui.methods.dataView.showDetails)
	    };

	    // Change between main pages
	    ui.methods.nav.changeContentView = async function(){
	        const contentName = this.getAttribute('content'),
	        	contentHeader = d3.selectAll('#header-contentName'),
	        	contentSubheader = d3.select('#subheader-contentName'),
	        	duration = 250
	        ui.state.scene = contentName
	        ui.elements.reportSelector.classList.add('hidden')
	        d3.selectAll('#header-clusterSelector, #icon-help-container, #message-help-container').classed('hidden', false)
	        contentHeader.transition().duration(duration).style('opacity', 0)
	        contentSubheader.transition().duration(duration).style('opacity', 0)
	        setTimeout( () =>{	ui.methods.nav.showScene(contentName)  }, duration)

	        switch(contentName){
	        	case 'about':
	        		d3.selectAll('#header-clusterSelector, #icon-help-container, #message-help-container').classed('hidden', true)
	        		setTimeout( () =>{
	        			contentHeader.html('About the Net Zero Pathways tool').transition().duration(duration).style('opacity', null)	      
	        			contentSubheader.html('').transition().duration(duration).style('opacity', null)	      
						document.getElementById('about-sectionContainer-development').scrollTop = 0
	        		}, duration)
	        		break
	        	case 'emissions':
	        		setTimeout( () => {
	        			contentHeader.html('Emissions profile').transition().duration(duration).style('opacity', null)	        			
	        			contentSubheader.html('').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('About the emissions profile')
						d3.select('#emissions-activity-text').html("This tool allows you to forecast business as usual emissions 'activity' to measure the impact of planned changes to future operations. These year-by-year 'activity changes' can be set for seven different building types for each agency")
						document.getElementById('emissions-controls-container').scrollTop = 0
						document.getElementById('inventoryTable-container').scrollTop = 0
	        		}, duration)
	        		break
	        	case 'actions':
	        		setTimeout( () =>{
						contentHeader.html('Modelling reduction options').transition().duration(duration).style('opacity', null)
	        			contentSubheader.html('').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('About the emission reduction actions')						
						ui.methods.dataView.updateActionDataTable()
						document.getElementById('actions-siteSummary').scrollTop = 0
						document.getElementById('actions-sitegroupAction-container').scrollTop = 0
	        		}, duration)
	        		break
	        	case 'pathways':
	        		await ui.methods.dataView.updateAgencyActions()
	        		setTimeout( () => {
						contentHeader.html('Emissions pathways').transition().duration(duration).style('opacity', null)
	        			contentSubheader.html('Across all projects – Scope 1, 2 and 3 emissions').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('About the emission pathways')											
	        		}, duration)
	        		break
	        	case 'costCurve':
					renderCostCurve()	
		        	await ui.methods.dataView.updateAgencyActions()
	        		setTimeout( () =>{
						contentHeader.html('Comparing the costs and impact of action').transition().duration(duration).style('opacity', null)
	        			contentSubheader.html('Across Scope 1, 2 and 3 emissions').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('About the MAC curves')											

	        		}, duration)
					document.getElementById('scene-costCurve').scrollTop = 0        		
	        		break
	        	case 'report':
	        		d3.select('#header-clusterSelector').classed('hidden', true)
	        		ui.elements.reportSelector.classList.remove('hidden')
					ui.methods.updateReport()
					// Remove and re-render charts
	        		setTimeout( () =>{
						contentHeader.html('Net Zero Pathways Summary').transition().duration(duration).style('opacity', null)
	        			contentSubheader.html('').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('About the tool outputs')										
	        		}, duration)
					document.getElementById('scene-report').scrollTop = 0        		
	        		break
	        	case 'settings':
	        		ui.elements.clusterSelector.classList.add('hidden')
	        		setTimeout( () =>{
						contentHeader.html('Global model settings').transition().duration(duration).style('opacity', null)
						d3.select('#infoPane-mainHeader').html('How settings are applied')									
	        		}, duration)
	        		break
	        	case 'file':
	        		ui.elements.clusterSelector.classList.remove('hidden')
	        		setTimeout( () =>{
						contentHeader.html('Save and load settings').transition().duration(duration).style('opacity', null)
	        			contentSubheader.html('').transition().duration(duration).style('opacity', null)	      
						d3.select('#infoPane-mainHeader').html('How save and load your settings')										
	        		}, duration)
	        		break
	        }
	    };

	    // Change agency 
	    ui.methods.nav.changeAgencyView = async (el) => {
			d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', 0)
			ui.methods.dataView.updateActionDataTable()
			// Update all agency selectors
			document.querySelector('#emissions-agencySelector [value="' + el.value + '"]').selected = true;	
			document.querySelector('#action-agencySelector [value="' + el.value + '"]').selected = true;	
			document.querySelector('#pathways-agencySelector [value="' + el.value + '"]').selected = true;	
			document.querySelector('#costCurve-agencySelector [value="' + el.value + '"]').selected = true;	
			document.querySelector('#report-agencySelector [value="' + el.value + '"]').selected = true;	
	    };

	    // Change cluster 
	    ui.methods.nav.changeClusterView = (el) => {
			// Set UI state and reset agency selectors
			ui.state.agencyID = 'allAgency'
			ui.state.agencyName = 'All agencies'
			ui.scenes.forEach( scene => {document.querySelector('#'+scene+'-agencySelector [value="allAgency"]').selected = true; } )

	    	// Define other cluster selectors
			const otherSelector = (el.id === 'viewLevel-selector') ? d3.select('#header-clusterSelector') :  d3.select('#viewLevel-selector'), 
				duration = 250
			otherSelector.transition().duration(duration).style('opacity', 0)
			
			// Update for selected cluster
			ui.state.clusterName = el.options[el.selectedIndex].text
			setTimeout( () => {
				if(el.id === 'viewLevel-selector'){
					document.querySelector('#header-clusterSelector [value="' + el.value + '"]').selected = true;					
				} else {
					document.querySelector('#viewLevel-selector [value="' + el.value + '"]').selected = true;					
				}
				otherSelector.transition().duration(duration).style('opacity', null)
				d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', 0)
				// Update each scene and the agency dropdown for selected cluster
				ui.methods.dataView.updateActionDataTable()	
				if(ui.state.clusterID === "allClusters"){
					ui.scenes.forEach( scene => { ui.methods.nav.createAgencyDropdown(scene+'-agencySelector', dataModel.schema.typologyMapping.modelAgencyList) } ) 
				} else {
					ui.scenes.forEach( scene => { ui.methods.nav.createAgencyDropdown(scene+'-agencySelector', dataModel.schema.clusterMapping.agencyByCluster[ui.state.clusterName].filter(agency => dataModel.schema.typologyMapping.modelAgencyList.indexOf(agency) > -1 )  ) })  			
				}
				ui.state.agencyName === 'All agencies'
			}, duration)
	    };

	    // Bring scene into view
	    ui.methods.nav.showScene = (sceneName) => {
	    	const fadeOut = 250, fadeIn = 500
			d3.selectAll('.central-pane-scene').transition().duration(fadeOut).style('opacity', 0)
			ui.methods.nav.toggleMainMenu()				
			setTimeout( () => {
				d3.selectAll('.central-pane-scene').classed('hidden', true)
				d3.select('#scene-'+sceneName).classed('hidden', false)
					.transition().duration(fadeIn)
					.style('opacity', null)
			 }, fadeOut)
	    };

	    // Update the Emission inventory (and report version) scene data table
	    ui.methods.dataView.updateActionDataTable = () => {
	    	// 0. Start with action pane hidden
				d3.select('#sitegroupAction-details-container').transition().duration(500).style('opacity', 0)
				d3.select('#sites-moreInfo').style('opacity', 0).classed('siteDetails', false).style('pointer-events', 'none')
				setTimeout( () => { d3.select('#sitegroupAction-details-container').classed('data', false)}, 500)	

			// 1. GET BASELINE DATA BASED ON SELECTED CLUSTER/AGENCY
				// Set data based on three cluster/agency selector cases..
				let noSites, solarData, solarInstallations, solarCapacity, solarGeneration, grepData, refCaseData, siteGroupList, sitesBySources = [],
					siteNoContainerVisible = true

				switch(ui.state.agencyID){
					case 'allAgency':
						switch(ui.state.clusterID){
							// CASE A: WHOLE OF GOV | ALL AGENCIES 
							case 'allClusters':	
								d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', 0)									
								noSites 				= dataModel.schema.consumption.sites.length		
								solarData 				= data.grepProjectsBy.solarProjectsAllAgency
								solarInstallations 		= 'at '+helpers.numberFormatters.formatComma(solarData['No installations'])+ (solarData['No installations'] === 1 ? ' site' : ' sites') 
								solarCapacity 			= solarData['Solar installed (kW)'] > 1000 ? helpers.numberFormatters.formatComma1dec(solarData['Solar installed (kW)'] / 100)+' MW' : helpers.numberFormatters.formatComma(solarData['Solar installed (kW)'])+' kW'
								solarGeneration 		= solarData['Elec saving (kWh)'] > 1000000 ? helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)'] / 1000000)+' GWh' : helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)']/1000 )+' MWh'						
								grepData 				= data.grepProjectsBy.projectsByType.map(function(d){ return {[d.key]: [d.values]} })	
								refCaseData 			= model.inventory.referenceCase.bySectorSource							
								siteGroupList 			= Object.keys(model.action.businessCase.byWholeOfGov_sitegroup).sort()
								break

							// CASE B:  ALL AGENCIES FOR A SPECIFIED CLUSTER 
							default:
								d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', 0)									
								const solarClusterIndex = Object.values(data.grepProjectsBy.solarProjectsByCluster).map(d => d.key).indexOf(ui.state.clusterName),
									grepClusterIndex  	= Object.values(data.grepProjectsBy.projectsByCluster).map(d => d.key).indexOf(ui.state.clusterName)
								noSites 				= dataModel.schema.consumption.sitesByCluster[ui.state.clusterName].length									
								solarData 				= typeof data.grepProjectsBy.solarProjectsByCluster[solarClusterIndex] !== 'undefined' ? data.grepProjectsBy.solarProjectsByCluster[solarClusterIndex].value : null						
								solarInstallations 		= solarData ? 'at '+helpers.numberFormatters.formatComma(solarData['No installations'])+ (solarData['No installations'] === 1 ? ' site' : ' sites')  : 'None'
								solarCapacity 			= solarData ? solarData['Solar installed (kW)'] > 1000 ? helpers.numberFormatters.formatComma1dec(solarData['Solar installed (kW)'] / 100)+' MW' : helpers.numberFormatters.formatComma(solarData['Solar installed (kW)'])+' kW' : 'None'
								solarGeneration 		= solarData ? solarData['Elec saving (kWh)'] > 1000000 ? helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)'] / 1000000)+' GWh' : helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)']/1000 )+' MWh' : 'None'						
								grepData 				= grepClusterIndex > -1 ? Object.values(data.grepProjectsBy.projectsByCluster[grepClusterIndex])[1].map(function(d){ return {[d.key]: [d.values]} })	: null
								refCaseData 			= model.inventory.referenceCase.byCluster[ui.state.clusterName]
								siteGroupList 			= Object.keys(model.action.businessCase.byCluster_sitegroup[ui.state.clusterName]).sort().filter(d => d !== "Unassigned")				
								break
						}
					 	break

					// CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
					default: 
						d3.select('#sites-moreInfo').classed('siteDetails', true).style('pointer-events', null).transition().duration(500).style('opacity', null)			
						// i. No. sites: 
						noSites =  d3.sum(Object.values(dataModel.schema.consumption.sitesByAgencySitegroup[ui.state.agencyName]).map(d => d.length))
						// ii. Solar data						
						const solarAgencyList 	= data.grepProjectsBy.solarProjectsByAgency.map(d => d.key)			
						if(solarAgencyList.indexOf(ui.state.agencyName) > -1){				
							solarData 			= data.grepProjectsBy.solarProjectsByAgency[solarAgencyList.indexOf(ui.state.agencyName)].value
							solarInstallations  = 'at '+helpers.numberFormatters.formatComma(solarData['No installations'])+ (solarData['No installations'] === 1 ? ' site' : ' sites') 
							solarCapacity 		= solarData['Solar installed (kW)'] > 1000 ? helpers.numberFormatters.formatComma1dec(solarData['Solar installed (kW)'] / 100)+' MW' : helpers.numberFormatters.formatComma(solarData['Solar installed (kW)'])+' kW'
							solarGeneration 	= solarData['Elec saving (kWh)'] > 1000000 ? helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)'] / 1000000)+' GWh' : helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)']/1000 )+' MWh'
						} else {
							solarData 			= null
							solarInstallations 	= 'None'
							solarCapacity 		= 'None'
							solarGeneration 	= 'None'
						}
						// iii. GREP data
						data.grepProjectsBy.projectsByAgency.forEach( d => {
							if(Object.values(d)[0] === ui.state.agencyName){
								grepData = Object.values(d)[1].map( (d) => { 
									return {[d.key]: [d.values]} 
								})			
							}
						})		
						/// iv. Reference case data
						refCaseData = model.inventory.referenceCase.byAgency[ui.state.agencyName] 
						// v. Site group list
						siteGroupList = Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).sort()				
				}

			// 2A. UPDATE DOM ELEMENTS: ACTIVITY TABLES
				const totalEmissions = {
					Scope1: Array(dataModel.schema.modelHorizon).fill(0),
					Scope2: Array(dataModel.schema.modelHorizon).fill(0),
					Scope3: Array(dataModel.schema.modelHorizon).fill(0),
					Total: Array(dataModel.schema.modelHorizon).fill(0),
					bySector: {}
				}
				// i. Build main table for Emissions inventory scene and Report scene inventory
				buildInventoryTable('inventoryTable-emissions-container', 'inventoryTable-sinks-container') 	
					function buildInventoryTable(emissionsID, sinksID){
						const emissionsContainer = d3.select('#'+emissionsID),
							sinksContainer = d3.select('#'+sinksID)
						// Find totalEmissions object: Divide by 2 as two inventory tables are built 
						for( const inventoryObj of ui.inventoryOrder){
							const sector = Object.keys(inventoryObj)[0],
								sourceList = Object.values(inventoryObj)[0]	
							if(refCaseData[sector] && Object.keys(refCaseData[sector]).length > 0){
								if (typeof totalEmissions.bySector[sector] === 'undefined'){ 
									totalEmissions.bySector[sector] = 0
								}
								for( const source of sourceList){	
									if(typeof refCaseData[sector][source] !== 'undefined'){
										totalEmissions.Scope1 = totalEmissions.Scope1.map((d,i)  => d + refCaseData[sector][source].emissions.Scope1[i] )  
										totalEmissions.Scope2 = totalEmissions.Scope2.map((d,i)  => d + refCaseData[sector][source].emissions.Scope2[i] ) 
										totalEmissions.Scope3 = totalEmissions.Scope3.map((d,i)  => d + refCaseData[sector][source].emissions.Scope3[i] )	
										totalEmissions.Total = totalEmissions.Total.map((d,i)  => d + refCaseData[sector][source].emissions.Total[i]  )									
										totalEmissions.bySector[sector] += refCaseData[sector][source].emissions.Total[0]
									}
								}
							}
						}
						//  Add sectors and sources
						d3.selectAll('#'+emissionsID+' *').remove()

						//  Add sectors and sources table
						ui.inventoryOrder.forEach( (inventoryObj, i) => {
							const sector = Object.keys(inventoryObj)[0],
								sourceList = Object.values(inventoryObj)[0]	

							if(refCaseData[sector] && Object.keys(refCaseData[sector]).length > 0){
								const sectorContainer = emissionsContainer.append('div').classed('inventoryTable-sector-container', true)
								sectorContainer.append('div').attr('id', 'inventoryTable-sector-'+i)
									.classed('inventoryTable-sector-label', true)
									.html(`${sector}<br><span class = 'inventoryTable-emissionsPct'>(${helpers.numberFormatters.formatPct1dec( totalEmissions.bySector[sector] / totalEmissions.Total[0])} )</span>`)
								const sourceAllContainer = sectorContainer.append('div').classed('inventoryTable-sourceAll-container', true)
								
								sourceList.forEach(source => {	
									if(typeof refCaseData[sector][source] !== 'undefined'){
										const sourceContainer = sourceAllContainer.append('div').classed('inventoryTable-source-container', true)
										sourceContainer.append('div').classed('inventoryTable-label', true)
											.html(source)
										sourceContainer.append('div').classed('inventoryTable-natural', true)
											.html(helpers.numberFormatters.formatComma(refCaseData[sector][source]['naturalVolume'][0])+' '+refCaseData[sector][source]['naturalUnit'] )
										sourceContainer.append('div').classed('inventoryTable-emissions', true)
											.html(helpers.numberFormatters.formatComma(refCaseData[sector][source]['emissions']['Total'][0])+' tCO<sub>2</sub>-e' )
										sourceContainer.append('div').classed('inventoryTable-emissionsPct', true)
											.html(helpers.numberFormatters.formatPct1dec(refCaseData[sector][source]['emissions']['Total'][0] / (totalEmissions.Total[0] ) ))
									}		
								})

							}
						})
					}; // end buildInventoryTable()

				// ii. Update renewables
				d3.selectAll('.inventorySolarGeneration-emissions').html(solarGeneration+' p.a.' )
				d3.selectAll('.inventorySolarExported-emissions').html('TBA')
				d3.selectAll('.inventorySolarGeneration-natural').html(solarCapacity+' installed' )
				d3.selectAll('.inventorySolarExported-natural').html('TBA')
				// i. Add Net emissions
				d3.selectAll('.inventoryTable-scope1-data').html(helpers.numberFormatters.formatComma(totalEmissions.Scope1[0]) )
				d3.selectAll('.inventoryTable-scope2-data').html(helpers.numberFormatters.formatComma(totalEmissions.Scope2[0]) )
				d3.selectAll('.inventoryTable-scope3-data').html(helpers.numberFormatters.formatComma(totalEmissions.Scope3[0]) )
				d3.selectAll('.inventoryTable-total-data').html(helpers.numberFormatters.formatComma(totalEmissions.Total[0]) )

			// 2B. UPDATE DOM ELEMENTS: ACTION DATA TABLES (INCL. REPORT VERSION)
				// i. Update No. sites and installed solar
					d3.selectAll('.baseline-noSites').html(helpers.numberFormatters.formatComma(noSites))
					d3.selectAll('.baseline-solarCapacity').html(solarCapacity)
					d3.selectAll('.baseline-solarSites').html(solarInstallations)
					d3.selectAll('.baseline-solarGeneration').html(solarGeneration)

				// ii. Update baseline consumption label
					const baselineYear = (dataModel.schema.baselineYear - 1)+'/'+(dataModel.schema.baselineYear - 2000)
					d3.selectAll('.baseline-label-consumptionCostHeader').html('Consumption and cost in '+baselineYear)

				// iii. Construct the contracts data summary (incl. report version)
					buildConsumptionTable('baseline-dataConsumption-container')
					function buildConsumptionTable(containerID){
						d3.selectAll('#'+containerID+'> *').remove()
						const consumptionContainer = d3.select('#'+containerID)
						ui.inventoryOrder.forEach( inventoryObj => {
							const sector = Object.keys(inventoryObj)[0],
								sourceList = Object.values(inventoryObj)[0]
							if(refCaseData[sector] && Object.keys(refCaseData[sector]).length > 0){
								sourceList.forEach(source => {
									const sourceData = refCaseData[sector][source]
									if(typeof sourceData !== 'undefined' && d3.sum(sourceData.naturalVolume) > 0) {
										const sourceContainer = consumptionContainer.append('div').classed('baseline-dataConsumption', true),
											consumption = sourceData.naturalVolume[0],
											consumptionUnit = sourceData.naturalUnit,
											cost = sourceData.cost[0]
										sourceContainer.append('div').classed('label', true).html(source)
										sourceContainer.append('div').classed('consumption', true).html(helpers.numberFormatters.formatComma(consumption)+' '+consumptionUnit)
										sourceContainer.append('div').classed('cost', true).html(helpers.numberFormatters.formatCostInteger(cost))
									}
								})
							}
						})
					};

				// iv. Update the GREP data
					buildGREPtable('grep-data-container')
					function buildGREPtable(containerID){
						d3.selectAll('#'+containerID+' > *').remove()

						const grepContainer = d3.select('#'+containerID)
						if(typeof grepData === 'undefined' || !grepData){
							grepContainer.append('div').classed('grep-message', true)
								.html('There are no project records under GREP')
						} else {
							const grepHeaders = grepContainer.append('div').classed('grep-headers-container', true)
							grepHeaders.append('div').classed('label', true).html('Project type')
							grepHeaders.append('div').classed('field1', true).html('Completed by end of '+baselineYear)
							grepHeaders.append('div').classed('field2', true).html('Planned')
							grepContainer.append('hr').classed('actionDivider', true)

							// For all classified projects
							dataModel.schema.grepProjects.projectTypes.sort().forEach(projectType => {
								grepData.forEach((obj, i) => {												
									if(Object.keys(obj)[0]  === projectType){										
										const completed = obj[projectType][0].filter(d => d.baseImpact !== 0),
											planned = obj[projectType][0].filter(d => d.baseImpact === 0)

										const grepItem = grepContainer.append('div').classed('grep-item-container', true)
										grepItem.append('div').classed('label', true).html(projectType)
										grepItem.append('div').classed('field1', true).html(completed.length)
										grepItem.append('div').classed('field2', true).html(planned.length)
									}
								})
							})
							// For all unclassified projects
							grepData.forEach((obj, i) => {						
								if(Object.keys(obj)[0]  === ""){										
									const completed = obj[""][0].filter(d => d.baseImpact !== 0),
										planned = obj[""][0].filter(d => d.baseImpact === 0)
									const grepItem = grepContainer.append('div').classed('grep-item-container', true)
									grepItem.append('div').classed('label', true).html("Not classified")
									grepItem.append('div').classed('field1', true).html(completed.length)
									grepItem.append('div').classed('field2', true).html(planned.length)
								}
							})
						}

					};

				// v. Update the sitegroup selector
					d3.selectAll('#action-sitegroup-selector > *').remove()	
					d3.select('#action-sitegroup-selector').append('option').attr('disabled', true).attr('value', 'choose').html('Choose a building or asset type')
					document.querySelector('#action-sitegroup-selector [value="choose"]').selected = true;					

					siteGroupList.forEach(sitegroup => {
						if(sitegroup !== 'Unassigned'){
							d3.select('#action-sitegroup-selector').append('option')
								.attr('value', sitegroup)
								.html(sitegroup)							
						}
					})

					d3.selectAll('#sitegroupAction-menu  > *').remove()
					if(siteGroupList.length === 1 && siteGroupList.indexOf('Unassigned')  === 0){
						d3.select('#sitegroupAction-menu').append('div').classed('sitegroupAction-message', true)
							.html("There are currently no action models available for this agency's building types. The scope of the tool will be expanded in the future to cover more building types.")
					}
					d3.selectAll('#sitegroupAction-header, #action-sitegroup-siteNo-container').transition().duration(250).style('opacity', 0)
					setTimeout(() => { d3.selectAll('#sitegroupAction-header, #action-sitegroup-siteNo-container').classed('hidden', true)}, 250)
				
				// vi. Update the modelled actions titles
					d3.selectAll('#action-sitegroup-selector').on('change', function(){
						ui.state.sitegroup = this.value		
						siteNoContainerVisible = ui.state.sitegroup === "All of agency" ? false : true	
						d3.selectAll('#sitegroupAction-header, #action-sitegroup-siteNo-container').classed('hidden', false).transition().duration(250).style('opacity', null)	
						let actionListObjects, actionLabelList, actionIDList
						if(ui.state.agencyID !== 'allAgency') {
							actionListObjects = Object.values(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][this.value]).map( (d, i) => {									
								return {
									label: 	d.actionName, 
									id:  	Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][this.value])[i]
								}
							})
						} else if(ui.state.clusterName !== 'Whole of Government')  {
							actionListObjects = Object.values(model.action.businessCase.byCluster_sitegroup_action[ui.state.clusterName][ui.state.sitegroup]).map( (d, i) => {
								return {
									label: 	d.name, 
									id:  	Object.keys(model.action.businessCase.byCluster_sitegroup_action[ui.state.clusterName][ui.state.sitegroup])[i]
								}
							})
						} else {
							actionListObjects = Object.values(model.action.businessCase.byWholeOfGov_sitegroup_action[ui.state.sitegroup]).map( (d, i) => {									
								return {
									label: 	d.name, 
									id:  	Object.keys(model.action.businessCase.byWholeOfGov_sitegroup_action[ui.state.sitegroup])[i]
								}
							})
						}	
						// Sort list object and create label and id lists
						actionListObjects.sort((a, b) => (a.label > b.label) ? 1 : -1)
						actionLabelList = actionListObjects.map(d => d.label)
						actionIDList 	= actionListObjects.map(d => d.id)
						d3.selectAll('#sitegroupAction-menu  > *').remove()				
						actionLabelList.forEach((actionLabel, i) => {
							d3.select('#sitegroupAction-menu').append('div').classed('sitegroupAction-menu-item', true)
								.attr('actionID', actionIDList[i])
								.html(actionLabel)
								.style('opacity', 0)
								.transition().duration(250).delay(i * 100)
									.style('opacity', null)
						})
						if(actionLabelList.length === 0){
							const actionMessage = ui.state.sitegroup === 'All of agency' ? 'There are no modelled actions available at the all of agency level this because there is no consumption data available the available modelled actions and initiatives at this time.'
								: 'There are no modelled actions available for this agency and building type: this because there is no consumption data available for these building types that matches the available modelled actions / technologies at this time.'
							d3.select('#sitegroupAction-menu').append('div').classed('sitegroupAction-message', true).html(actionMessage)
						}

					// vii. Hide the action details and reset action 
						d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', 0)
						d3.select('#sitegroupAction-details-container').classed('data', false).transition().duration(500).style('opacity', null)	

					// viii. Update the site no. (and visibility)
						noSiteGroupSites = ui.state.sitegroup === 'All of agency' ? null 
							: (ui.state.clusterName === "Whole of Government" && ui.state.agencyName === "All agencies" )? d3.sum(Object.values(dataModel.schema.consumption.sitesByAgencySitegroup).map(d => d[ui.state.sitegroup]).filter(d => typeof d !== 'undefined').map(d => d.length))
								: (ui.state.clusterName !== "Whole of Government" && ui.state.agencyName === "All agencies") ? d3.sum(dataModel.schema.consumption.agenciesByCluster[ui.state.clusterName].map(d => dataModel.schema.consumption.sitesByAgencySitegroup[d]).map(d => d[ui.state.sitegroup]).filter(d => typeof d !== 'undefined').map(d => d.length) )
									: dataModel.schema.consumption.sitesByAgencySitegroup[ui.state.agencyName][ui.state.sitegroup].length

						d3.select('#action-sitegroup-siteNo-container').classed('hidden', !siteNoContainerVisible)
						d3.select('#actionSitegroup-noSitesLabel').html(`Total number of ${ui.state.sitegroup.toLowerCase()} sites`)
						d3.select('#actionSitegroup-noSites').html( helpers.numberFormatters.formatComma(noSiteGroupSites))

					// ix. Update the action case
						d3.selectAll('.sitegroupAction-menu-item').on('click', ui.methods.dataView.updateActionDataFields)
					})
		}; 

		// Update the emission reduction action details
		ui.methods.dataView.updateActionDataFields = function(){
			ui.state.actionID = this.getAttribute('actionID')	

			d3.selectAll('#sitegroupAction-details-container *').transition().duration(500).style('opacity', null)			
			d3.select('#sitegroupAction-details-container').style('opacity', 0).classed('data', true).transition().duration(500).style('opacity', null)	
			d3.selectAll('.sitegroupAction-impactItem-container, .sitegroupAction-metricsItem-container').classed('hidden', false)
			d3.selectAll('#action-sitegroup-siteNo-container, #action-adjustUptake').classed('hidden', true)

			// Get key action objects and determine input variables
			const actionID = this.getAttribute('actionID'),
			 	actionSector = model.action.parameters[actionID].impact.from[0].sector,
			 	actionSource = model.action.parameters[actionID].impact.from[0].source 

			let noSites,
				actionData, actionSettings, actionParameters, actionType, assetType,
				uptakeVisible = true, uptake, uptakeNoSites, uptakeNoSiteMax, uptakeNoSiteMin, uptakeNoSiteStep, 
				impactVisible = true, impactReduction, impactReductionMin, impactReductionMax, impactReductionLabel, impactReductionNumberType,
				unitCostDisplay, impactCapitalCostLabel, impactCapitalCost, impactOmCostLabel, impactOmCost, omCostStep,
				
				consumption, emissions, consumptionUnit,
				impactLifeLabel, impactLife, 
				actionLabel, sitegroupConsumptionLabel, sitegroupConsumptionLabelVisible = true,
				noSitegroupSitesLabel, 
				noSiteGroupVisible,
				sitegroupEmissionsLabel,uptakeLabel, 
				modelAssumptionsLabel, baselineDatalabel,
				actionCount = 0,
				editUptake = true, editReduction = true, editCapitalCost = true, editOmCost = true, editLife = true,
				grepInstalledNoSites = 0,
				siteNoContainerVisible = ui.state.sitegroup === "All of agency" ? false : true	

			switch(ui.state.agencyID){
				case 'allAgency': 		// WoG and Cluster level
					switch(ui.state.clusterID){
						// CASE A: WHOLE OF GOV | ALL AGENCIES 
						case 'allClusters':	
							noSites 				= model.inventory.referenceCase.bySitegroup[actionSector][actionSource][ui.state.sitegroup].siteNames.length
							actionParameters		= model.action.parameters[actionID]
							actionType				= actionParameters.impact.type
							assetType				= actionParameters.impact.asset
							actionData 	  			= model.action.businessCase.byWholeOfGov_action[actionID]							
							uptakeNoSites 			= 0
							uptakeNoSiteMax 		= 0
							impactReduction 		= 0 
							impactOmCost 			= 0
							impactLife 				= 0						
							impactCapitalCost 		= 0
							// Update averages
							Object.keys(model.action.businessCase.byAgency_sitegroup).forEach(agency => {
								Object.keys(model.action.businessCase.byAgency_sitegroup[agency]).forEach(sitegroup => {
									Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup]).forEach(bcActionID => {
										if(bcActionID === actionID){
											actionCount++												
											const actionSettings = settings.action.byAgency_sitegroup[agency][sitegroup][actionID],
												noAgencySitegroupSites = model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][actionSector][actionSource].siteNames.length,
												targetUptakePct = actionSettings.opportunity.targetUptake 									
											uptakeNoSites 		+= noAgencySitegroupSites * targetUptakePct
											uptakeNoSiteMax 	+= noAgencySitegroupSites
											impactReduction 	+= (actionType !== 'generation' ||actionType !== 'offset'  )? actionSettings.reductionPct : actionSettings.opportunity.sizekWPerSite * uptakeNoSites
											impactCapitalCost 	+= actionSettings.cost.capitalCost
											impactOmCost 		+= actionSettings.cost.omCost
											impactLife 			+= actionSettings.economicLife
										}
									})
								})
							})		

							uptake 						= ui.state.sitegroup === 'All of agency' && actionType !== 'efficiency' ? 100 // Set a number to trigger business case pane (this will be hidden
														: Math.round(uptakeNoSites / uptakeNoSiteMax * 1000) / 10
							uptakeVisible 				= ui.state.sitegroup === 'All of agency'  ? false : true
							impactVisible 				= true 
							impactReduction 			= (actionType === 'efficiency' || actionType === 'reduction') ? Math.round(impactReduction / actionCount * 100) : Math.round(impactReduction / actionCount ) 		// average reduction or kW
							impactReductionMin 			= impactReduction	
							impactReductionMax 			= impactReduction 	
							impactCapitalCost 			= Math.round(impactCapitalCost, 0)
							impactOmCost 				= Math.round(impactOmCost)
							impactLife 					= Math.round(impactLife / actionCount, 1)
							impactReductionStep 		= 1
							impactReductionLabel 		= actionType === 'efficiency' && assetType !== 'vehicle' ? 'Efficiency gain (% of targeted equipment)' 
														: actionType === 'efficiency' && assetType === 'vehicle' ? 'Vehicle efficiency gain (%)' 
														: actionType === 'reduction' ? 'Reduction (% of baseline consumption)' 
														: actionType === 'switch' && assetType !== 'vehicle' ? 'Proportion of consumption switched (%)'
														: actionType === 'switch' && assetType === 'vehicle' ? 'Proportion of targeted vehicles switched (%)'
														: 'New ave. solar capacity (kW per site)' 
							unitCostDisplay 			= false 
							impactCapitalCostLabel 		= ui.state.sitegroup === 'All of agency' && assetType !== 'vehicle' ? 'Capital cost (across all of agency)' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'reduction'? 'Capital cost' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'efficiency'? 'Capital cost (all efficient vehicles)' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'switch' ? 'Capital cost (all switched vehicles)' 
														: 'Capital cost (all sites)'
							impactOmCostLabel 			= ui.state.sitegroup === 'All of agency' && assetType !== 'vehicle' ? 'Annual O&M cost'
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' ? 'Annual O&M cost (all vehicles)' 
														: 'Annual O&M cost (all sites)' 
							impactLifeLabel 			= 'Project economic life (years)'
							modelAssumptionsLabel  		= 'Model assumptions'
							actionLabel 				= 'Action types modelled'
							baselineDatalabel 	 		= 'Baseline '+(actionSource.slice(0,1).toLowerCase()+actionSource.slice(1, actionSource.length))+' activity for all '+ui.state.sitegroup.toLowerCase()
							sitegroupConsumptionLabel 	= 'Total consumption'
							sitegroupEmissionsLabel 	= 'Total emissions'												
							impactReductionNumberType 	= (actionType === 'efficiency' || actionType === 'reduction' || actionType === 'switch')? 'pct' : '1dec'
							uptakeLabel 				= actionType !== 'offset' 
															? 'Proportion (%) of sites with uptake by '+settings.parameters.horizon 
															: 'Proportion (%) of energy under PPA'
							emissions 					= helpers.numberFormatters.formatComma(model.inventory.referenceCase.bySitegroup[actionSector][actionSource][ui.state.sitegroup].emissions.Total[0])
							consumption 				= helpers.numberFormatters.formatComma(model.inventory.referenceCase.bySitegroup[actionSector][actionSource][ui.state.sitegroup].naturalVolume[0])
							consumptionUnit 			= model.inventory.referenceCase.bySitegroup[actionSector][actionSource][ui.state.sitegroup].naturalUnit
							// Make metrics uneditable
							editUptake 					= false
							editReduction				= false
							editCapitalCost 			= false
							editOmCost 					= false 
							editLife 					= false								

							// Update the business case metrics
							updateBCmetricFields(model.action.businessCase.byWholeOfGov_sitegroup_action[ui.state.sitegroup][actionID], actionSettings, uptakeNoSites )	
							break

						// CASE B:  ALL AGENCIES FOR A SPECIFIED CLUSTER 
						default:
							noSites 				= model.inventory.referenceCase.byCluster[ui.state.clusterName][actionSector][actionSource].siteNames.length
							actionParameters		= model.action.parameters[actionID]
							actionType				= actionParameters.impact.type
							assetType				= actionParameters.impact.asset
							actionData 	  			= model.action.businessCase.byWholeOfGov_action[actionID]							
							uptakeNoSites 			= 0
							uptakeNoSiteMax 		= 0
							impactReduction 		= 0 
							impactOmCost 			= 0
							impactLife 				= 0						
							impactCapitalCost 		= 0
							// Update averages
							Object.keys(model.action.businessCase.byAgency_sitegroup).forEach(agency => {
								Object.keys(model.action.businessCase.byAgency_sitegroup[agency]).forEach(sitegroup => {
									Object.keys(model.action.businessCase.byAgency_sitegroup[agency][sitegroup]).forEach(bcActionID => {
										if(bcActionID === actionID && dataModel.schema.consumption.agenciesByCluster[ui.state.clusterName].indexOf(agency) > -1 ){
											actionCount++												
											const actionSettings = settings.action.byAgency_sitegroup[agency][sitegroup][actionID],
												noAgencySitegroupSites = model.inventory.referenceCase.byAgency_sitegroup[agency][sitegroup][actionSector][actionSource].siteNames.length,
												targetUptakePct = actionSettings.opportunity.targetUptake 									
											uptakeNoSites 		+= noAgencySitegroupSites * targetUptakePct
											uptakeNoSiteMax 	+= noAgencySitegroupSites
											impactReduction 	+= (actionType !== 'efficiency' || actionType === 'reduction'  || actionType === 'switch') ? actionSettings.reductionPct : actionType === 'generation' ? actionSettings.opportunity.sizekWPerSite * uptakeNoSites : 0
											impactCapitalCost 	+= actionSettings.cost.capitalCost
											impactOmCost 		+= actionSettings.cost.omCost
											impactLife 			+= actionSettings.economicLife
										}
									})
								})
							})		
							uptake 						= ui.state.sitegroup === 'All of agency' && actionType !== 'efficiency' ? 100 // Set a number to trigger business case pane (this will be hidden
														: Math.round(uptakeNoSites / uptakeNoSiteMax * 1000) / 10
							uptakeVisible 				= ui.state.sitegroup === 'All of agency'  ? false : true
							impactVisible 				= true 
							impactReduction 			= actionType !== 'generation' ? Math.round(impactReduction / actionCount * 100) : Math.round(impactReduction / actionCount ) 		// average reduction or kW
							impactReductionMin 			= impactReduction
							impactReductionMax 			= impactReduction
							impactCapitalCost 			= Math.round(impactCapitalCost, 0)
							impactOmCost 				= Math.round(impactOmCost)
							impactLife 					= Math.round(impactLife / actionCount, 1)
							impactReductionStep 		= 1
							impactReductionLabel 		= actionType === 'efficiency' && assetType !== 'vehicle' ? 'Efficiency gain (% of targeted equipment)' 
														: actionType === 'efficiency' && assetType === 'vehicle' ? 'Vehicle efficiency gain (%)' 
														: actionType === 'reduction' ? 'Reduction (% of baseline consumption)' 
														: actionType === 'switch' && assetType !== 'vehicle' ? 'Proportion of consumption switched (%)'
														: actionType === 'switch' && assetType === 'vehicle' ? 'Proportion of targeted vehicles switched (%)'
														: 'New ave. solar capacity (kW per site)' 
							unitCostDisplay 			= false 
							impactCapitalCostLabel 		= ui.state.sitegroup === 'All of agency' && assetType !== 'vehicle' ? 'Capital cost (across all of agency)' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'reduction'? 'Capital cost' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'efficiency'? 'Capital cost (all efficient vehicles)' 
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' && actionType === 'switch' ? 'Capital cost (all switched vehicles)' 
														: 'Capital cost (all sites)'
							impactOmCostLabel 			= ui.state.sitegroup === 'All of agency' && assetType !== 'vehicle' ? 'Annual O&M cost'
														: ui.state.sitegroup === 'All of agency' && assetType == 'vehicle' ? 'Annual O&M cost (all vehicles)' 
														: 'Annual O&M cost (all sites)' 
							impactLifeLabel 			= 'Project economic life (years)'
							modelAssumptionsLabel  		= 'Model assumptions'
							actionLabel 				= 'Action types modelled'
							baselineDatalabel 	 		= 'Baseline '+(actionSource.slice(0,1).toLowerCase()+actionSource.slice(1, actionSource.length))+' activity for all '+ui.state.sitegroup.toLowerCase()
							sitegroupConsumptionLabel 	= 'Total consumption'
							sitegroupEmissionsLabel 	= 'Total emissions'		
							impactReductionNumberType 	= (actionType === 'efficiency' || actionType === 'reduction' || actionType === 'switch')? 'pct' : '1dec'
							uptakeLabel 				= actionType !== 'offset' 
															? 'Proportion (%) of sites with uptake by '+settings.parameters.horizon 
															: 'Proportion (%) of energy under PPA'

							emissions 					= helpers.numberFormatters.formatComma(model.inventory.referenceCase.byCluster[ui.state.clusterName][actionSector][actionSource].emissions.Total[0])
							consumption 				= helpers.numberFormatters.formatComma(model.inventory.referenceCase.byCluster[ui.state.clusterName][actionSector][actionSource].naturalVolume[0])
							consumptionUnit 			= model.inventory.referenceCase.byCluster[ui.state.clusterName][actionSector][actionSource].naturalUnit
							// Make metrics uneditable
							editUptake 					= false
							editReduction				= false
							editCapitalCost 			= false
							editOmCost 					= false 
							editLife 					= false			
							// Update the business case metrics
							updateBCmetricFields(model.action.businessCase.byCluster_sitegroup_action[ui.state.clusterName][ui.state.sitegroup][actionID], uptakeNoSites )														
							break
					}
				 	break

				// CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
				default: 
					// Find number of sites if a custome list is used; and threshold
					const agencyIndexOfCustomSiteData = data.siteDataSitegroupByAgency.map(d => d.key).indexOf(ui.state.agencyName),
						customSiteDataSitegroup = agencyIndexOfCustomSiteData > -1 ? data.siteDataSitegroupByAgency[agencyIndexOfCustomSiteData].value[ui.state.sitegroup] : null,
						customSiteCount 		= customSiteDataSitegroup ? customSiteDataSitegroup[actionSource] : null
					// Count the grep projects
					data.grepProjectsBy.projectsByAgency_sitegroup.forEach( obj => {
						if(obj.key === ui.state.agencyName){
							obj.values[0].values.forEach(projectTypeObj => {															
								if(projectTypeObj.key === model.action.parameters[actionID].meta.grepName){
									grepInstalledNoSites = d3.sum(projectTypeObj.values.filter(d => d.sitegroup === ui.state.sitegroup).map(d => d.baseImpact))
								}
							})
						}
					})
					// Update all metrics and labels
					actionData 	   				= model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionID]
					actionParameters			= model.action.parameters[actionID]
					actionSettings 				= settings.action.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionID]
					actionType 					= actionParameters.impact.type 	
					assetType					= actionParameters.impact.asset		
					noSites 					= customSiteCount ? customSiteCount 
												: (ui.state.sitegroup === 'All of agency' && assetType ===  'vehicle' ) ? d3.sum(data.agencyConsumption.filter(d => d.agencyName === ui.state.agencyName && d.sector === actionParameters.impact.from[0].sector && d.source === actionParameters.impact.from[0].source).map(d => d.number)) 
												: model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionSector][actionSource].siteNames.length

					uptakeNoSites 				= actionSettings.opportunity.targetUptake * noSites
					uptake 						= actionType === 'switch' || actionType === 'reduction' ? Math.round(actionSettings.opportunity.targetUptake * 100) 
												: ui.state.sitegroup === 'All of agency' && actionType === 'efficiency' ? Math.round(actionSettings.opportunity.targetUptake * 100) 												
												: ui.state.sitegroup === 'All of agency' && actionType !== 'efficiency' ? 1 	// Set a number to trigger business case pane (this will be hidden)
												: Math.round(uptakeNoSites*10)/10 

					uptakeNoSiteMax 			=  actionType === 'switch' || actionType === 'reduction'  ?  100 
													: actionType === 'efficiency' && ui.state.sitegroup === 'All of agency' ? 100
													: (noSites - Math.round(grepInstalledNoSites))
					uptakeNoSiteMin 			= 0 
					uptakeNoSiteStep 			= 1	
					uptakeLabel 				= actionType === 'offset' ? 'No. sites under a PPA (100% renewable)'
												: actionType === 'reduction' ? 'Proportion (% of baseline consumption targeted)' 
												: actionType === 'efficiency' && ui.state.sitegroup === 'All of agency' ? `Proportion of consumption targeted for efficiency action by ${settings.parameters.horizon} (%)`
												: (actionType === 'efficiency' && ui.state.sitegroup !== 'All of agency') ? 'No. sites with new uptake by '+settings.parameters.horizon 
												: actionType === 'generation' ? 'No. sites with new installations by '+settings.parameters.horizon 
												: 'No identified case (check uptake label)'
					uptakeVisible 				= (ui.state.sitegroup === 'All of agency' && actionType === 'reduction' || ui.state.sitegroup === 'All of agency' && actionType === 'switch') ? false : true
					impactReduction 			= actionType === 'generation' ?  actionSettings.opportunity.sizekWPerSite
												: actionType === 'offset' || actionType === 'switch' || actionType === 'reduction'? Math.round(actionSettings.reductionPct * 100)  
												: actionType === 'efficiency' ? Math.round(actionSettings.reductionPct * 100) 
												: 'No case'
					impactReductionMin 			= actionType === 'generation' ? 0 : 0
					impactReductionMax 			= actionType === 'generation' ? 1000 : 100
					impactReductionStep 		= actionType === 'generation' ? 1 : 1
					impactReductionLabel 		= actionType === 'efficiency' && assetType !== 'vehicle' ? 'Efficiency gain (% of targeted equipment)' 
												: actionType === 'efficiency' && assetType === 'vehicle' ? 'Vehicle efficiency gain (%)' 										
												: actionType === 'reduction' ?  'Reduction (%) of targeted consumption' 	
												: actionType === 'switch' && assetType !== 'vehicle' ? 'Proportion of consumption switched (%)'
												: actionType === 'switch' && assetType === 'vehicle' ? 'Proportion of vehicles switched (%)'
												: actionType === 'generation' ? 'New ave. solar capacity (kW per site)' 
												: 'No identified case (check impact label)'
					unitCostDisplay 			= actionType !== 'generation' ? false : true
					impactCapitalCostLabel 		= ui.state.sitegroup === 'All of agency' ? `Capital cost (${actionParameters.cost.omCost.unit})`: 'Capital cost (ave. $ per site)'
					impactCapitalCost 			= Math.round(actionSettings.cost.capitalCost)
					impactOmCostLabel 			= ui.state.sitegroup === 'All of agency' ? `Annual O&M cost (${actionParameters.cost.omCost.unit})`	: 'Annual O&M cost ($ per site)' 
					impactOmCost 				= Math.round(actionSettings.cost.omCost)
					omCostStep 					= 10
					impactLifeLabel 			= 'Project economic life (years)'
					impactLife 					= actionSettings.economicLife
					impactReductionNumberType 	= actionParameters.impact.type !== 'generation' ? 'pct' : '1dec'
		
					modelAssumptionsLabel  		= 'Model assumptions <span class = "scene-subHeader-highlight">(editable)</span>'
					actionLabel 				= 'Available action models:'						
					baselineDatalabel 			= ui.state.sitegroup === 'All of agency' ? 'Baseline '+(actionSource.slice(0,1).toLowerCase()+actionSource.slice(1, actionSource.length))+' activity for '+ui.state.agencyName
													: 'Baseline '+(actionSource.slice(0,1).toLowerCase()+actionSource.slice(1, actionSource.length))+' activity for '+ui.state.agencyName+' '+ui.state.sitegroup.toLowerCase()
					noSitegroupSitesLabel 		= assetType !== 'vehicle' ? 'No. '+ui.state.sitegroup.toLowerCase()+' with '+actionSource.slice(0,1).toLowerCase()+actionSource.slice(1,actionSource.length)
													: `${actionParameters.impact.from[0].source} vehicles in agency fleet` 
					noSiteGroupVisible			=  ui.state.sitegroup === 'All of agency' && assetType !== 'vehicle' ? false : true
					sitegroupConsumptionLabel 	= ui.state.sitegroup === 'All of agency' ? 'Reported consumption' 
													: 'Average consumption per '+content.loadProfile[ui.state.sitegroup].unitName 				
					sitegroupEmissionsLabel 	= ui.state.sitegroup === 'All of agency' ? 'Estimated baseline annual emissions' 
													: 'Average emissions per '+content.loadProfile[ui.state.sitegroup].unitName 	

					const sectorFrom 			= actionParameters.impact.from[0].sector, 			// Sector and source specified 
						sourceFrom 				= actionParameters.impact.from[0].source, 	
						tempRefCaseFrom 		= ui.state.sitegroup === 'All of agency' ? null  			// Agency level actions have no threshold checks and there are no byAgency_sitegroup reference case where agencies without agency level data
													: model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][sectorFrom][sourceFrom],
				 		sitegroupNoSites 		= ui.state.sitegroup === 'All of agency' ? 1 
													: tempRefCaseFrom.siteNames.length

					emissions					= helpers.numberFormatters.formatComma(model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionSector][actionSource].emissions.Total[0] / sitegroupNoSites)
					consumption					= helpers.numberFormatters.formatComma1dec(	model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionSector][actionSource].naturalVolume[0] / sitegroupNoSites)
					consumptionUnit 			= model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionSector][actionSource].naturalUnit 

					// Show the site counter only at agency level
					d3.selectAll('#action-sitegroup-siteNo-container, #action-adjustUptake').classed('hidden', false)
					updateBCmetricFields(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionID], actionSettings)	
			}

			// Hide unnecessary objects from DOM
			if(actionType === 'offset'){
				d3.selectAll('#impact-capitalCost-container, #impact-omCost-container, #impact-life-container, #impact-reduction-container, #metrics-discountedPayback-container, #metrics-irr-container, #metrics-simplePayback-container').classed('hidden', true)
			}

			if(actionSettings.opportunity.targetUptake === 0 || ((actionParameters.impact.type === 'reduction' || actionParameters.impact.type === 'switch') && actionSettings.reductionPct === 0)) {
				d3.selectAll('.sitegroupAction-metricsItem-container, #action-viewBusinessCase').classed('hidden', true)
				d3.selectAll('.sitegroupAction-metricsMessage-container').classed('hidden', false)
			} else {
				d3.selectAll('.sitegroupAction-metricsItem-container, #action-viewBusinessCase').classed('hidden', false)
				d3.selectAll('.sitegroupAction-metricsMessage-container').classed('hidden', true)				
			}
			d3.select('#action-sitegroup-siteNo-container').classed('hidden', !siteNoContainerVisible)

			// Select action tile
			d3.selectAll('.sitegroupAction-menu-item').classed('selected', false)
			d3.select(this).classed('selected', true)
			// Update action description, labels  and fields	
			d3.selectAll('#action-description').html(model.action.parameters[actionID].meta.description )	
			d3.select('#action-moreInfo').html('Read more about '+model.action.parameters[actionID].meta.label)	
			// Update the baseline activity section
			d3.select('#action-sitegroupNoSitesLabel').html(noSitegroupSitesLabel ).classed('hidden', !noSiteGroupVisible)
			d3.select('#action-sitegroupNoSites').html(helpers.numberFormatters.formatComma(noSites)).classed('hidden', !noSiteGroupVisible)					
			d3.select('#sitegroupAction-baselineActivtyLabel').html(baselineDatalabel)	
			d3.select('#action-sitegroupConsumptionLabel').html(sitegroupConsumptionLabel)
			d3.select('#action-sitegroupConsumption').html(consumption+' '+consumptionUnit)
			d3.select('#action-sitegroupEmissionsLabel').html(sitegroupEmissionsLabel)
			d3.select('#action-sitegroupEmissions').html(emissions+' tCO2-e')
			// Update the Model assumptions impact fields
			d3.select('#sitegroupAction-modelAssumptionsLabel').html(modelAssumptionsLabel)			
			d3.select('#impact-uptakeLabel').html(uptakeLabel)
				.classed('hidden', !uptakeVisible)			
			d3.select('#impact-uptake').classed('bc-input', true)
				.attr('value', uptake)
				.attr('min', uptakeNoSiteMin)
				.attr('max', uptakeNoSiteMax)
				.attr('step', uptakeNoSiteStep)
				.attr('settings', 'uptake')
				.classed('hidden', !uptakeVisible)	
			document.getElementById('impact-uptake').value = uptake
			document.getElementById('impact-uptake').disabled = !editUptake

			d3.select('#impact-reductionLabel').html(impactReductionLabel)
				.attr('settings', 'opportunity')
				.classed('hidden', !impactVisible)						
			d3.select('#impact-reduction').classed('bc-input', true)
				.attr('value',impactReduction)
				.attr('min', impactReductionMin)
				.attr('max', impactReductionMax)
				.attr('step', impactReductionStep)
				.attr('numberType', impactReductionNumberType)
				.attr('settings', 'reduction')	
				.classed('hidden', !impactVisible)		
			document.getElementById('impact-reduction').value = impactReduction
			document.getElementById('impact-reduction').disabled = !editReduction

			d3.select('#impact-capitalCostLabel').html(impactCapitalCostLabel)
			d3.select('#impact-capitalCost').classed('bc-input', true)
				.attr('value', Math.round(impactCapitalCost))
				.attr('step', 100)
				.attr('numberFormatter', 'cost')	
				.attr('settings', 'capitalCost')	
				.attr('disabled', !editCapitalCost)								
			document.getElementById('impact-capitalCost').value = Math.round(impactCapitalCost)
			document.getElementById('impact-capitalCost').disabled = !editCapitalCost	

			d3.select('#impact-omCostLabel').html(impactOmCostLabel)
			d3.select('#impact-omCost').classed('bc-input', true)
				.attr('value',Math.round(impactOmCost))
				.attr('step', omCostStep)
				.attr('numberFormatter', 'cost')	
				.attr('settings', 'omCost')	
				
			document.getElementById('impact-omCost').value = Math.round(impactOmCost)				
			document.getElementById('impact-omCost').disabled = !editOmCost	

			d3.select('#impact-lifeLabel').html(impactLifeLabel)
			d3.select('#impact-life').classed('bc-input', true)
				.attr('value',impactLife)
				.attr('min', 0)
				.attr('max', 40)
				.attr('step', 1)
				.attr('numberFormatter', 'years')	
				.attr('settings', 'economicLife')	

			document.getElementById('impact-life').value = Math.round(impactLife)	
			document.getElementById('impact-life').disabled = !editLife

			// Update settings and action business case for Agency level actions ONLY
			d3.selectAll('.bc-input').on('change', bcInputUpdate)
			d3.selectAll('.bc-input').on('onblur', onblur )

			async function bcInputUpdate(){
				switch(this.getAttribute('settings')){
					case 'uptake':
						if(ui.state.sitegroup === 'All of agency'){
							actionSettings.opportunity.targetUptake = +this.value / 100	
						} else {
							actionSettings.opportunity.targetUptake = +this.value / noSites	
							actionSettings.uptakeTotalSites = +this.value	
						}
						break

					case 'reduction':
						if(actionParameters.impact.type === 'efficiency' || actionParameters.impact.type === 'reduction' || actionParameters.impact.type === 'switch'){
							actionSettings.reductionPct = +this.value / 100
						} else {
							actionSettings.opportunity.sizekWPerSite = +this.value
						}		
						break

					case 'capitalCost':
						if(actionParameters.impact.type === 'efficiency' || actionParameters.impact.type === 'reduction' || actionParameters.impact.type === 'switch'){
							actionSettings.cost.capitalCost = +this.value 
						} else {
							actionSettings.cost.capitalCost = +this.value 
						}							
						break

					case 'omCost':
						if(actionParameters.impact.type === 'efficiency' || actionParameters.impact.type === 'reduction' || actionParameters.impact.type === 'switch'){
							actionSettings.cost.omCost = +this.value
						} else {
							actionSettings.cost.omCost = +this.value 
						}	
						break

					case 'economicLife':
						actionSettings.economicLife =  +this.value
						break							
				}

				// Update UI
				if(actionSettings.opportunity.targetUptake === 0 || ((actionParameters.impact.type === 'reduction' || actionParameters.impact.type === 'switch') && actionSettings.reductionPct === 0)) {
					d3.selectAll('.sitegroupAction-metricsItem-container, #action-viewBusinessCase').classed('hidden', true)
					d3.selectAll('.sitegroupAction-metricsMessage-container').classed('hidden', false)
				} else {
					d3.selectAll('.sitegroupAction-metricsItem-container, #action-viewBusinessCase').classed('hidden', false)
					d3.selectAll('.sitegroupAction-metricsMessage-container').classed('hidden', true)				
				}

				await updateActionModel('BC Input')					
				await updateBCmetricFields(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][actionID], actionSettings)

				actionSettings.userUpdated = actionSettings.opportunity.targetUptake !== 0 ? true : false
				ui.state.pendingActionCaseRecalc = true
				ui.state.pendingChartUpdate = true
 			};

	
			async function updateBCmetricFields(actionData, actionSettings, uptakeNoSites){		
				let noSites, npv, emissionReduction, abatementCost, irr, discountedPayback, simplePayback

				// For actions where there is no uptake
				if(actionSettings && actionSettings.reductionPct === 0){
					abatementCost 		= "Not available",
					irr 				= "Not available"
					discountedPayback 	= "Not available"
					simplePayback 		= "Not available"
					npv 				= 0
					emissionReduction 	= helpers.numberFormatters.formatComma1dec(0)+' tCO2e p.a.'
				// Settings for actions at different view levels (cases)
				} else {
				 	abatementCost 		= (typeof(actionData) !== 'undefined' && typeof(actionData.businessCase.Metrics['Levelised cost of abatement']) !== 'undefined') ? helpers.numberFormatters.formatCost1dec(actionData.businessCase.Metrics['Levelised cost of abatement'])+' per tCO2-e' : 'Not available',
				 	irr 				= actionData.businessCase.Metrics.IRR === "#NUM!" ? "Above 100%" : typeof actionData.businessCase.Metrics.IRR !== 'undefined' || !isNaN(actionData.businessCase.Metrics.IRR ) || actionData.businessCase.Metrics.IRR  !== "#NUM!" ? helpers.numberFormatters.formatPct1dec(actionData.businessCase.Metrics.IRR)+' p.a.' : 'No return',
				 	discountedPayback 	= actionData.businessCase.Metrics['Discounted payback'] === "Under one year" ? "Under 1 yr." : typeof actionData.businessCase.Metrics['Discounted payback'] !== 'undefined'  || !isNaN(actionData.businessCase.Metrics['Discounted payback']) ? helpers.numberFormatters.formatComma1dec(actionData.businessCase.Metrics['Discounted payback'])+' years' : 'No payback',
				 	simplePayback 		= actionData.businessCase.Metrics['Simple payback'] === "Under one year" ? "Under 1 yr." : typeof actionData.businessCase.Metrics['Simple payback'] !== 'undefined' || !isNaN(actionData.businessCase.Metrics['Simple payback']) ? helpers.numberFormatters.formatComma1dec(actionData.businessCase.Metrics['Simple payback'])+' years' : 'No payback' 

					switch(ui.state.agencyID){
						case 'allAgency':
							switch(ui.state.clusterID){
								// CASE A: WHOLE OF GOV | ALL AGENCIES 
								case 'allClusters':	
									npv 			  = typeof actionData.businessCase.Metrics.NPV !== 'undefined' || !isNaN(actionData.businessCase.Metrics.NPV* uptakeNoSites) ? helpers.numberFormatters.formatCostInteger(actionData.businessCase.Metrics.NPV)  : 'Not available'
									emissionReduction = helpers.numberFormatters.formatComma1dec(actionData.impact.emissionsReduction.Total[0] )  +' tCO2e p.a.'
									break
								// CASE B:  ALL AGENCIES FOR A SPECIFIED CLUSTER 
								default:
									npv 			  = typeof actionData.businessCase.Metrics.NPV !== 'undefined' || !isNaN(actionData.businessCase.Metrics.NPV  * uptakeNoSites) ? helpers.numberFormatters.formatCostInteger(actionData.businessCase.Metrics.NPV)  : 'Not available'
									emissionReduction = helpers.numberFormatters.formatComma1dec(actionData.impact.emissionsReduction.Total[0] )  +' tCO2e p.a.'							
									break
							}
							break
						// CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
						default: 
							noSites 			= ui.state.sitegroup === 'All of agency' ? null : dataModel.schema.consumption.sitesByAgencySitegroup[ui.state.agencyName][ui.state.sitegroup].length	
							npv 				= typeof actionData.businessCase.Metrics.NPV !== 'undefined' || !isNaN(actionData.businessCase.Metrics.NPV ) ? helpers.numberFormatters.formatCostInteger(actionData.businessCase.Metrics.NPV) : 'Not available'
							emissionReduction 	= helpers.numberFormatters.formatComma1dec(d3.mean(actionData.impact.emissionsReduction.Total.slice(0, actionSettings.economicLife)) )+' tCO2e p.a.'
					}
				}

				d3.select('#metrics-abatementCost').html(abatementCost)									
				d3.select('#metrics-npv').html(npv)
				d3.select('#metrics-irr').html(irr)
				d3.select('#metrics-discountedPayback').html(discountedPayback)
				d3.select('#metrics-simplePayback').html(simplePayback)		
				d3.select('#metrics-emissionReduction').html(emissionReduction)		
			}
			// Flag modelAggregetaion as pending
			ui.state.modelsAggregated = false
		};

		// Update the pathways and cost chart action options
		ui.methods.dataView.updateAgencyActions = async () => {
			// Clear the available options
			d3.selectAll('#pathways-allActions-container > *, #costCurve-allActions-container > *').remove()
			d3.select('#pathways-actions-message').html("<p>This chart shows the combined emissions reduction pathway for actions modelled for all agencies for the selected cluster.</p><p>By choosing an agency to view and explore from the selector above, you will be able to adjust the:</p><ul><li>Total new uptake of an action, by number of the number of sites by "+settings.parameters.horizon+"</li><li>Uptake profile of each action, which models how many sites implement the action, year by year</li>")			
			d3.select('#costCurve-actions-message').html(
				'<p>This chart shows a marginal abatement cost curve for '+ 
				((ui.state.agencyID === 'allAgency' && ui.state.clusterID === 'allClusters') ? 'all agencies, across all of Government. ': (ui.state.clusterID === 'allClusters') ? 'all agencies in the '+ui.state.clusterName+' cluster.'  : '' )
				 +"</p><p>A cost curve is a tool that helps to compare the cost of each action to reduce each tonne of carbon (the 'height'), and how much carbon that action can reduce for the modelled uptake in "+settings.parameters.horizon+
				'. Each block represents a different type of emissions reduction action whose costs, impact and uptake have been modelled at the agency level for specific building types, and then aggregated to a '+
				 ((ui.state.clusterID === 'allClusters' ? ui.state.clusterName +' cluster view.' : 'Whole of Government view.'))
				+'</p><p>By choosing to explore a cost curve for specific agency, you will also be able to see and directly adjust the total uptake for every modelled action, at the more granular building type-level.'		
			)
			d3.selectAll('#emissions-activity-container, #action-adjustUptake').classed('hidden', true)

			// For a chosen agency
			if(ui.state.agencyID !== 'allAgency'){
				const allPathwayActionContainer = d3.select('#pathways-allActions-container'), 
				 	allCostCurveActionContainer = d3.select('#costCurve-allActions-container'), 
					agencyActionSettings = settings.action.byAgency_sitegroup[ui.state.agencyName],
					sliderIDs = [],
					sitegroupList = Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).sort(),
				 	sitegroupIndexes  =[]
				 	filteredSitegroups = sitegroupList.filter(d => d !== 'Unassigned' && Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][d]).length > 0)

				filteredSitegroups.filter(d => d !== 'Unassigned' && Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][d]).length > 0).forEach( (sitegroup, i) => {
					if(Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][sitegroup]).length > 0){
						sitegroupIndexes.push(i)
						const pathawaySitegroupActions = allPathwayActionContainer.append('div').attr('id', 'pathwaysActionSitegroup-container-'+i).classed('pathways-actionSitegroup-container', true),
						 	costCurveSitegroupActions = allCostCurveActionContainer.append('div').attr('id', 'costCurveActionSitegroup-container-'+i).classed('costCurve-actionSitegroup-container', true)

						// Setup pathways sitegroup header menu
							const pathwaysSitegroupHeader =  pathawaySitegroupActions.append('div').classed('actionSitegroup-header-container', true),
								 pathwaysForward = pathwaysSitegroupHeader.append('div').classed('actionSitegroup-header-forward', true).html('>'),
								 pathwaysBack = pathwaysSitegroupHeader.append('div').classed('actionSitegroup-header-back', true).html('<')
																			
							pathwaysForward.on('click', () => {
								d3.selectAll('.pathways-actionSitegroup-container').classed('hidden', true)
								d3.select('#pathwaysActionSitegroup-container-'+(i+1)).classed('hidden', false).style('opacity', 0).transition().duration(200).style('opacity', null)
								ui.state.sitegroup  = sitegroupList[i+1]
								updateSliderMessage()
							})
							pathwaysBack.on('click', () => {
								d3.selectAll('.pathways-actionSitegroup-container').classed('hidden', true)
								d3.select('#pathwaysActionSitegroup-container-'+(i-1)).classed('hidden', false).style('opacity', 0).transition().duration(200).style('opacity', null)
								ui.state.sitegroup  = sitegroupList[i-1]
								updateSliderMessage()
							})
							pathwaysSitegroupHeader.append('div').classed('pathways-actionSitegroup-header', true).html(sitegroup)						

						// Setup costCurve sitegroup header menu
							const costCurveSitegroupHeader =  costCurveSitegroupActions.append('div').classed('actionSitegroup-header-container', true),
								 costCurveForward = costCurveSitegroupHeader.append('div').classed('actionSitegroup-header-forward', true).html('>'),
								 costCurvesBack = costCurveSitegroupHeader.append('div').classed('actionSitegroup-header-back', true).html('<')						

							costCurveForward.on('click', () => {
								d3.selectAll('.costCurve-actionSitegroup-container').classed('hidden', true)
								d3.select('#costCurveActionSitegroup-container-'+(i+1)).classed('hidden', false).style('opacity', 0).transition().duration(200).style('opacity', null)
								ui.state.sitegroup  = sitegroupList[i+1]
								updateSliderMessage()
							})
							costCurvesBack.on('click', () => {
								d3.selectAll('.costCurve-actionSitegroup-container').classed('hidden', true)
								d3.select('#costCurveActionSitegroup-container-'+(i-1)).classed('hidden', false).style('opacity', 0).transition().duration(200).style('opacity', null)
								ui.state.sitegroup  = sitegroupList[i-1]
								updateSliderMessage()
							})							
							costCurveSitegroupHeader.append('div').classed('costCurve-actionSitegroup-header', true).html(sitegroup)		

							ui.state.sitegroup = filteredSitegroups[0]
							if(i === 0){
								pathwaysBack.style('opacity', 0).on('click', null) 
								costCurvesBack.style('opacity', 0).on('click', null) 
							} 
							if(filteredSitegroups.length === 1 || i === filteredSitegroups.length - 1){
								costCurveForward.style('opacity', 0).on('click', null) 
								pathwaysForward.style('opacity', 0).on('click', null)
							} 			

						// Add each action slider
						Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][sitegroup]).sort().forEach(actionID => {	
							// Count the grep projects
							let grepInstalledNoSites = 0
							data.grepProjectsBy.projectsByAgency_sitegroup.forEach( obj => {
								if(obj.key === ui.state.agencyName){
									obj.values[0].values.forEach(projectTypeObj => {															
										if(projectTypeObj.key === model.action.parameters[actionID].meta.grepName){
											grepInstalledNoSites = d3.sum(projectTypeObj.values.filter(d => d.sitegroup === ui.state.sitegroup).map(d => d.baseImpact))
										}
									})
								}
							})

							const actionParameters 				= model.action.parameters[actionID],
								actionType  					= actionParameters.impact.type,
								actionSettings 					= agencyActionSettings[sitegroup][actionID],
								actionSector 					= actionParameters.impact.from[0].sector,
								actionSource 					= actionParameters.impact.from[0].source,
								actionLabel 					= actionParameters.meta.label,
								// Custom site data is legacy code to support cusotmer override sites: ise left here in case it is later reactiviated but does not affect the calculations when there is no customs sites entered
									agencyIndexOfCustomSiteData 	= data.siteDataSitegroupByAgency.map(d => d.key).indexOf(ui.state.agencyName),
									customSiteDataSitegroup 		= agencyIndexOfCustomSiteData > -1 ? data.siteDataSitegroupByAgency[agencyIndexOfCustomSiteData].value[ui.state.sitegroup] : null,
									customSiteCount 				= customSiteDataSitegroup ? customSiteDataSitegroup[actionSource] : null,

								noSites  						= sitegroup ==='All of agency' ? 100 // Out ot 100%
																: customSiteCount ? customSiteCount 
																: model.inventory.referenceCase.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionSector][actionSource].siteNames.length,
								modelledUptake 					= sitegroup ==='All of agency' && (actionType === 'reduction' || actionType === 'switch') ? actionSettings.reductionPct * noSites 
																: actionSettings.opportunity.targetUptake * noSites,
								actionBCsettings 				= settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID],
								maxUptake 						= sitegroup ==='All of agency' ? 100 : noSites - grepInstalledNoSites

							if(maxUptake > 0){
								// PATHWAYS CHART: Add sliders to the DOM if 
								const pathwayActionContainer = pathawaySitegroupActions.append('div').classed('pathways-action-container', true),
								 	pathwayLabelContainer = pathwayActionContainer.append('div').classed('pathways-action-label-container', true),
								 	pathwaySliderContainer = pathwayActionContainer.append('div').classed('range-wrap', true)

								pathwayLabelContainer.append('div').classed('pathways-action-name', true)
									.html(actionParameters.meta.label)
								pathwayLabelContainer.append('div').classed('pathways-action-uptake', true)
									.html('Adjust uptake profile')
									.attr('detailstype', 'uptake')
									.attr('actionID', actionID)
									.attr('sitegroup', sitegroup)
									.on('click', ui.methods.dataView.showDetails)

								pathwaySliderContainer.append('div').classed('range-value', true)
									.attr('id', 'valuepathwayRange-'+actionID+helpers.camelize(sitegroup))
								pathwaySliderContainer.append('input').attr('id', 'pathwayRange-'+actionID+helpers.camelize(sitegroup))
									.attr('type', 'range')
									.attr('min', 0)
									.attr('max', maxUptake)
									.attr('value', modelledUptake)
									.attr('step', 1)
									.on('change', async function(){
										ui.state.actionID = actionID
										ui.state.sitegroup = sitegroup 
										if(sitegroup ==='All of agency' && (actionType === 'reduction' || actionType === 'switch')){
											actionSettings.reductionPct =  +this.value / 100
										} else {
											actionSettings.uptakeTotalSites =  +this.value
											actionSettings.opportunity.targetUptake = this.value / noSites
										}
										actionSettings.userUpdated = +this.value === 0 ? false : true
										await updateActionModel('Pathways slider')
										await aggregateActionModels()
										await buildActionAndSwitchToCase(true)
										await updateWedgesChart('main')
										await updateCostCurve()
									})
								sliderIDs.push('pathwayRange-'+actionID+helpers.camelize(sitegroup))

								// COST CURVE: Add sliders to the DOM
								const costCurveActionContainer = costCurveSitegroupActions.append('div').classed('costCurve-action-container', true),
								 	costCurveLabelContainer = costCurveActionContainer.append('div').classed('costCurve-action-label-container', true),
								 	costCurveSliderContainer = costCurveActionContainer.append('div').classed('range-wrap', true)

								costCurveLabelContainer.append('div').classed('costCurve-action-name', true)
									.html(actionParameters.meta.label)
		
								costCurveLabelContainer.append('div').classed('costCurve-action-uptake', true)
									.html('See the business case')
									.attr('detailstype', 'businessCase')
									.attr('actionID', actionID)
									.attr('sourceType', 'costCurve')															
									.on('click', ui.methods.dataView.showDetails)

								costCurveSliderContainer.append('div').classed('range-value', true)
									.attr('id', 'valuecostCurveRange-'+actionID+helpers.camelize(sitegroup))
								costCurveSliderContainer.append('input').attr('id', 'costCurveRange-'+actionID+helpers.camelize(sitegroup))
									.attr('type', 'range')
									.attr('min', 0)
									.attr('max', maxUptake)
									.attr('value', modelledUptake)
									.attr('step', 1)
									.on('change', async function(){
										ui.state.actionID = actionID
										ui.state.sitegroup = sitegroup 
										if(sitegroup ==='All of agency' && (actionType === 'reduction' || actionType === 'switch')){
											actionSettings.reductionPct =  +this.value / 100
										} else {
											actionSettings.uptakeTotalSites =  +this.value
											actionSettings.opportunity.targetUptake = this.value / noSites
										}	
										actionSettings.userUpdated = +this.value === 0 ? false : true	
										await updateActionModel('MACC slider')
										await aggregateActionModels()
										await buildActionAndSwitchToCase(true)
										await updateCostCurve()
										await updateWedgesChart('main')
									})
								sliderIDs.push('costCurveRange-'+actionID+helpers.camelize(sitegroup))
								// SHOW THE INVENTORY ACTIVTY GROWTH BUTTON & UPTAKE OPTION 
								d3.selectAll('#emissions-activity-container, #action-adjustUptake').classed('hidden', false).style('opacity', 0)
									.transition().duration(500)
									.style('opacity', null)
							}
						})
					}
				})

				//  Trigger a redraw (to ensure any loaded action data is automatically shown)
				if(typeof(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup]) !== 'undefined'){
					ui.state.actionID =  Object.keys(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup])[0] 		// Any existing action required to be set
				}
				await updateActionModel('Update agency actions')
				await updateSliderMessage()

				// Set sitegroup to visible group
				ui.state.sitegroup = filteredSitegroups[0]	
				d3.selectAll('.pathways-actionSitegroup-container:not(#pathwaysActionSitegroup-container-0').classed('hidden', true)
				d3.selectAll('.costCurve-actionSitegroup-container:not(#costCurveActionSitegroup-container-0').classed('hidden', true)
				sliderIDs.forEach(id => ui.methods.dataView.addBubbleSliders(id))

				// Function to update slider message for sitegroups
				async function updateSliderMessage(){
					const sliderInstruction =  ui.state.sitegroup ==='All of agency' ? `For each of these actions that apply to <span class = "message-highlight-red">all agency assets and purchases</span>, use the sliders to model  <span class = "message-highlight-aqua">the proportional (%) uptake</span> for its targeted consumption by ${settings.parameters.horizon}`
						: `For this <span class = "message-highlight-red">type of building</span>, use the sliders to model how many <span class = "message-highlight-aqua">sites</span> implement each action by ${settings.parameters.horizon}`,
						sliderNullMessage =  ui.state.sitegroup ==='All of agency' ? 'Unfortunately at present, the Net Zero Pathways tool does not include emissions reduction action models that apply to sources modelled at the all of agency level. New models for more building types will be added in the future.'
						: 'Unfortunately at present, the Net Zero Pathways tool does not include emissions reduction action models that apply to the building types of '+ui.state.agencyName+'. New models for more building types will be added in the future.'

					if(filteredSitegroups.length !== 0){
						d3.select('#pathways-actions-message').html(sliderInstruction)
						d3.select('#costCurve-actions-message').html(sliderInstruction)
					} else {
						d3.select('#pathways-actions-message').html(sliderNullMessage)
						d3.select('#costCurve-actions-message').html(sliderNullMessage)
					}
				}
			}
		};

		// Add slider bubble effect
	    ui.methods.dataView.addBubbleSliders = (id) =>{
			const range = document.getElementById(id),
				rangeV = document.getElementById('value'+id),
				setValue = function(){
					d3.select('#value'+id).style('opacity', 1)
					const newValue = Number( (range.value - range.min) * 100 / (range.max - range.min) ),
						newPosition = 10 - (newValue * 0.2);
					rangeV.innerHTML = `<span>${range.value}</span>`;
					rangeV.style.left = `calc(${newValue}% + (${newPosition}px))`;
					setTimeout(() => {
						d3.selectAll('.range-value').transition().duration(250).style('opacity', 0)
					}, 5000)
				};
			document.addEventListener("DOMContentLoaded", setValue);
			range.addEventListener('input', setValue);	       
			range.addEventListener('click', setValue);	       
	    };

	    // Show details pages
	    ui.methods.dataView.showDetails = function(){
	    	d3.selectAll('#detailsPane-content-container *').remove()   	
	    	// Common structure
	    	const contentContainer 	= d3.select('#detailsPane-content-container'),
	    		detailsHeader 		= contentContainer.append('div').classed('details-header', true),
	    		detailsDesc 		= contentContainer.append('div').classed('details-description', true),
	    		detailsContent  	= contentContainer.append('div').classed('details-content', true),
	    		modelYears 			= dataModel.schema.modelYears.slice(0, settings.parameters.horizon - dataModel.schema.baselineYear + 1)
	    	
			let actionBCdata, actionSettings, actionParameters, actionLife, modelTime, 
				tableContainer, tableHeaderRow, tableSliderRow, tableValuesRow, invTableContainer, tableButtonUpRow, tableButtonDownRow, 
				invTableHeaderRow, paramType, paramID, settingsSliderTableContainer, name

	    	switch(this.getAttribute('detailstype')){
	    		case 'activity':
	    			tableContainer  = contentContainer.append('div').classed('activity-table-container', true)
					tableHeaderRow  = tableContainer.append('div').classed('details-table-headerRow', true)
	    			detailsHeader.html("Modelling changes emissions activity for "+ui.state.agencyName)
					detailsDesc.html("<p>This feature allows you to forecast any changes to activity levels at "+ui.state.agencyName+" sites over time. This creates a 'business as usual' emissions pathway which the impact of modelled emissions reduction actions can be compared. 'Growth' is set as a multiplier of baseline year ("+dataModel.schema.baselineYear+") emissions. This means that setting a multiplier of 1.05 for a year will set the forecast emissions activity for that year to 105% of the baseline year. ")
					detailsContent.append('div').classed('activity-table-header', true).html('Forecast changes in emissions activity by building type')
					settingsSliderTableContainer = detailsContent.append('div').attr('id', 'sliderTable')			
					ui.dynamics.changedParameter.parameterType = 'activity'
					
					const siteData = dataModel.schema.consumption.sitesByAgencySitegroup[ui.state.agencyName]
					d3.selectAll('.details-content, .details-description').classed('slider', true)
				
					Object.keys(siteData).forEach((sitegroup, j) => {
						if(sitegroup !== "Unassigned"){
		    				settingsSliderTableContainer.append('div').classed('activity-table-header', true).html('Activity forecast (multiplier) for '+sitegroup)
							let tableContainer 		= settingsSliderTableContainer.append('div').classed('activity-table-container', true),
								tableHeaderRow 		= tableContainer.append('div').classed('details-table-headerRow', true),
								tableButtonUpRow 	= tableContainer.append('div').classed('details-table-buttonUpRow', true),
								tableSliderRow 		= tableContainer.append('div').classed('details-table-sliderRow', true),
								tableButtonDownRow 	= tableContainer.append('div').classed('details-table-buttonDownRow', true),								
								tableValuesRow 		= tableContainer.append('div').classed('details-table-inputRow', true),
								step = 0.01

							modelYears.forEach( (year, i) => { 
								tableHeaderRow.append('div').classed('slider-table-year', true).html(year).attr('sitegroup', sitegroup)
								tableButtonUpRow.append('div').classed('slider-button', true).html('+').attr('sitegroup', sitegroup)
									.attr('id', 'buttonUp-'+j+'-'+year)
									.on('click', async function(){ 
										const increasedValue = Math.round((+d3.select('#slider-'+j+'-'+year+' > input').attr('value') + step) *100) / 100								
										d3.select("#slider-"+j+'-'+year+' > input').attr('value', increasedValue)
										d3.select('#input-'+j+'-'+year).attr('value', increasedValue) 
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] = increasedValue
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].userUpdated = true
										ui.state.sitegroup = this.getAttribute('sitegroup')
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true		
									})								
								tableButtonDownRow.append('div').classed('slider-button', true).html('-').attr('sitegroup', sitegroup)
									.attr('id', 'buttonDown-'+j+'-'+year)
									.on('click', async function(){ 
										const decreasedValue = Math.round((+d3.select('#slider-'+j+'-'+year+' > input').attr('value') - step) *100) / 100								
										d3.select("#slider-"+j+'-'+year+' > input').attr('value', decreasedValue)
										d3.select('#input-'+j+'-'+year).attr('value', decreasedValue) 
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] = decreasedValue
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].userUpdated = true
										ui.state.sitegroup = this.getAttribute('sitegroup')
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true		
									})	
								tableSliderRow.append('div').classed('table-sliderContainer', true)
									.attr('id', 'slider-'+j+'-'+year)
									.append('input').classed('table-slider', true).attr('sitegroup', sitegroup)
									.attr('type', 'range')
									.attr('step', step)													
									.attr('min', 0)													
									.attr('max', settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[0] * 5)													
									.attr('orient', 'vertical')
									.attr('value', settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] )
									.on('change', async function(){ 
										d3.select("#input-"+j+'-'+year).attr('value', this.value)
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] = +this.value
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].userUpdated = true
										ui.state.sitegroup = this.getAttribute('sitegroup')
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true
										ui.state.pendingChartUpdate = true									
									})
								tableValuesRow.append('div').classed('table-inputContainer', true).attr('sitegroup', sitegroup)
									.append('input').attr('id', 'input-'+j+'-'+year)
									.classed('table-input', true)
									.attr('value', settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] )
									.on('input', async function(){ 
										d3.select("#slider-"+j+'-'+year+' > input').html(this.value)
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i] = +this.value
										settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].userUpdated = true										
										ui.state.sitegroup = this.getAttribute('sitegroup')
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true							
									})	
							})
						}
					})
	    			break

	    		case 'settings':
					const parameterID = this.getAttribute('paramID'),
						parameterType = this.getAttribute('paramType'),
						paramData = model.parameters[parameterType][parameterID]
					ui.dynamics.changedParameter.parameterName = parameterID
	    			d3.selectAll('.details-content, .details-description').classed('slider', true)

	    			switch(paramData.type){
						case 'price':
							ui.dynamics.changedParameter.parameterType = 'general'						
							let forecastDesc = paramData.type === 'price' ? paramData.name+' ($ '+paramData.unit+')' : name+' emissions factor (t CO2-e '+paramData.unit+')',
								forecastMultiplier =  4, 
								step =  0.01,
								min = parameterID === 'price_PPA' ? -100 : 0

							name = paramData.name.slice(0,1).toLowerCase()+paramData.name.slice(1, paramData.name.length) 						
							settingsSliderTableContainer = detailsContent.append('div').attr('id', 'sliderTable')
			    			settingsSliderTableContainer.append('div').classed('activity-table-header', true).html('Forecast '+ forecastDesc)
			    			detailsHeader.html("Modelling future "+forecastDesc)
							detailsDesc.html("<p>This feature allows you to adjust the future "+forecastDesc  +" used in the model, out to 2050.</p><p><strong>All modelled prices and economic analysis is presented in real $"+dataModel.schema.baselineYear+"</strong></p>" )
							
							tableContainer 		= settingsSliderTableContainer.append('div').classed('activity-table-container', true)
							tableHeaderRow 		= tableContainer.append('div').classed('details-table-headerRow', true)
							tableButtonUpRow 	= tableContainer.append('div').classed('details-table-buttonUpRow', true)
							tableSliderRow 		= tableContainer.append('div').classed('details-table-sliderRow', true)
							tableButtonDownRow 	= tableContainer.append('div').classed('details-table-buttonDownRow', true)
							tableValuesRow 		= tableContainer.append('div').classed('details-table-inputRow', true)

							modelYears.forEach( (year, i) => { 
								tableHeaderRow.append('div').classed('slider-table-year', true).html(year)
								tableButtonUpRow.append('div').classed('slider-button', true).html('+')
									.attr('id', 'buttonUp-'+year)
									.on('click', async function(){ 
										const increasedValue = Math.round((+d3.select('#slider-'+year+' > input').attr('value') + step) * 100) / 100								
										d3.select("#slider-"+year+' > input').attr('value', increasedValue)
										d3.select('#input-'+year).attr('value', increasedValue) 
										settings.parameters.general[parameterID].value[i] = increasedValue
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true	
										document.getElementById('settings-'+parameterID).value = settings.parameters.general[parameterID].value[0]																																			
									})		

								tableButtonDownRow.append('div').classed('slider-button', true).html('-')
									.attr('id', 'buttonDown-'+year)
									.on('click', async function(){ 
										const decreasedValue = Math.round((+d3.select('#slider-'+year+' > input').attr('value') - step) *100) / 100								
										d3.select('#slider-'+year+' > input').attr('value', decreasedValue)
										d3.select('#input-'+year).attr('value', decreasedValue) 
										settings.parameters.general[parameterID].value[i] = decreasedValue
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true		
										document.getElementById('settings-'+parameterID).value = settings.parameters.general[parameterID].value[0]												
									})	
								tableSliderRow.append('div').classed('table-sliderContainer', true)
									.attr('id', 'slider-'+year)
									.append('input').classed('table-slider', true)
									.attr('type', 'range')
									.attr('step', step)													
									.attr('min', min)													
									.attr('max', Math.abs(settings.parameters[parameterType][parameterID].value[0]) * forecastMultiplier)													
									.attr('orient', 'vertical')
									.attr('value', Math.round(settings.parameters[parameterType][parameterID].value[i] * 100) / 100 )
									.on('change', async function(){ 
										d3.select("#input-"+year).attr('value', this.value)
										settings.parameters.general[parameterID].value[i] = +this.value									
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true	
										document.getElementById('settings-'+parameterID).value = settings.parameters.general[parameterID].value[0]																				
									})
								tableValuesRow.append('div').classed('table-inputContainer', true)
									.append('input').attr('id', 'input-'+year)
									.classed('table-input', true)
									.attr('value', Math.round(settings.parameters[parameterType][parameterID].value[i] * 100) /100 )
									.on('input', async function(){ 										
										d3.select("#slider-"+year+' > input').html(this.value)
										settings.parameters.general[parameterID].value[i] = +this.value	
										await updateReferenceCase()
										ui.state.pendingActionCaseRecalc = true									
										ui.state.pendingChartUpdate = true		
										document.getElementById('settings-'+parameterID).value = settings.parameters.general[parameterID].value[0]																		
									})	
							})
							break

						default:
							ui.dynamics.changedParameter.parameterType = 'emissionFactor'								
			    			const scopes = ['scope1', 'scope2', 'scope3'], usedScopes = []
			    			name = paramData.name.slice(0,1).toLowerCase()+paramData.name.slice(1, paramData.name.length) 			
			    			scopes.forEach(scope => { 	if(d3.sum(paramData[scope]) > 0) { 	usedScopes.push(scope)} })
							settingsSliderTableContainer = detailsContent.append('div').attr('id', 'sliderTable')	
		    				detailsHeader.html("Modelling future emission factors for "+name+' (tCO2-e '+paramData.unit+')')
							detailsDesc.html("<p>This feature allows you to adjust future changes in emission factors used in the model, out to 2050.</p><p>Emission factors are expected to reduce in the future as fuels and fuels used in delivery and Supply chains become 'cleaner' over time.</p>" )			    			

			    			usedScopes.forEach( scope => {
			    				settingsSliderTableContainer.append('div').classed('activity-table-header', true).html('Scope '+scope.slice(5,6)+' factor for '+name+' (tCO2-e '+paramData.unit+')')
								let tableContainer = settingsSliderTableContainer.append('div').classed('activity-table-container', true),
									tableHeaderRow = tableContainer.append('div').classed('details-table-headerRow', true),
									tableButtonUpRow 	= tableContainer.append('div').classed('details-table-buttonUpRow', true),
									tableSliderRow 		= tableContainer.append('div').classed('details-table-sliderRow', true),
									tableButtonDownRow 	= tableContainer.append('div').classed('details-table-buttonDownRow', true),		
									tableValuesRow = tableContainer.append('div').classed('details-table-inputRow', true),
									step = 0.01

								modelYears.forEach( (year, i) => { 
									tableHeaderRow.append('div').classed('slider-table-year', true).html(year)
	
									tableButtonUpRow.append('div').classed('slider-button', true).html('+')
										.attr('id', 'buttonUp-'+scope+'-'+year)
										.on('click', async function(){ 
											const increasedValue = Math.round((+d3.select('#slider-'+scope+'-'+year+' > input').attr('value') + step) * 100) / 100								
											d3.select("#slider-"+scope+'-'+year+' > input').attr('value', increasedValue)
											d3.select('#input-'+scope+'-'+year).attr('value', increasedValue) 
											settings.parameters.emissionFactors[parameterID][scope][i] = increasedValue
											await updateReferenceCase()
											ui.state.pendingActionCaseRecalc = true									
											ui.state.pendingChartUpdate = true					
											document.getElementById('settings-'+parameterID+'-'+scope).value = settings.parameters.emissionFactors[parameterID][scope][0]																			
										})		

									tableButtonDownRow.append('div').classed('slider-button', true).html('-')
										.attr('id', 'buttonDown-'+scope+'-'+year)
										.on('click', async function(){ 
											const decreasedValue = Math.round((+d3.select('#slider-'+scope+'-'+year+' > input').attr('value') - step) *100) / 100						
											d3.select('#slider-'+scope+'-'+year+' > input').attr('value', decreasedValue)
											d3.select('#input-'+scope+'-'+year).attr('value', decreasedValue) 
											settings.parameters.emissionFactors[parameterID][scope][i] = decreasedValue
											await updateReferenceCase()
											ui.state.pendingActionCaseRecalc = true									
											ui.state.pendingChartUpdate = true		
											document.getElementById('settings-'+parameterID+'-'+scope).value = settings.parameters.emissionFactors[parameterID][scope][0]										
										})	

									tableSliderRow.append('div').classed('table-sliderContainer', true)
										.attr('id', 'slider-'+scope+'-'+year)
										.append('input').classed('table-slider', true)
										.attr('type', 'range')
										.attr('step', step)													
										.attr('min', 0)													
										.attr('max', settings.parameters[parameterType][parameterID][scope][0] * 1.1)													
										.attr('orient', 'vertical')
										.attr('value', Math.round(settings.parameters[parameterType][parameterID][scope][i] * 100) / 100 )
										.on('change', async function(){ 
											d3.select("#input-"+scope+'-'+year).attr('value', this.value)
											settings.parameters.emissionFactors[parameterID][scope][i] = +this.value										
											ui.state.actionRecalcPending = true	
											ui.state.pendingChartUpdate = true													
											await updateReferenceCase()		
											document.getElementById('settings-'+parameterID+'-'+scope).value = settings.parameters.emissionFactors[parameterID][scope][0]																													
										})
									tableValuesRow.append('div').classed('table-inputContainer', true)
										.append('input').attr('id', 'input-'+scope+'-'+year)
										.classed('table-input', true)
										.attr('value', settings.parameters[parameterType][parameterID][scope][i] )
										.on('input', async function(){ 										
											d3.select('#slider-'+scope+'-'+year+' > input').html(this.value)
											settings.parameters.emissionFactors[parameterID][scope][i]= +this.value	
											await updateReferenceCase()
											ui.state.pendingActionCaseRecalc = true									
											ui.state.pendingChartUpdate = true			
											document.getElementById('settings-'+parameterID+'-'+scope).value = settings.parameters.emissionFactors[parameterID][scope][0]	
										})	
								})
			    			}) 	
							break
	    			}
	    			break

	    		case 'uptake':
	    			const selActionID = this.getAttribute('actionID') ? this.getAttribute('actionID')  : ui.state.actionID,  
	    				selSitegroup =  this.getAttribute('sitegroup') ? this.getAttribute('sitegroup')  : ui.state.sitegroup,
						uptakeLabel = ui.state.sitegroup !== "All of agency" ? 'Modelled uptake by number of sites' : `Modelled uptake by percentage of targeted ${settings.parameters.horizon} uptake`
						actionParameters = model.action.parameters[selActionID]
						actionBCdata = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][selSitegroup][selActionID]
						actionSettings = settings.action.byAgency_sitegroup[ui.state.agencyName][selSitegroup][selActionID]
						actionLife = actionSettings.economicLife === 1 ? actionSettings.economicLife+' year' :  actionSettings.economicLife+' years'
						modelTime = [...Array(actionSettings.economicLife).keys()],
						uptakeDesc = ui.state.sitegroup !== "All of agency" ? 
								`<p>This feature allows you to model the uptake of ${actionParameters.meta.label} by number of (currently existing) sites, over time until ${settings.parameters.horizon}. 
								Each vertical slider represents uptake by no. of ${ui.state.sitegroup} over time, allowing you to model different scenarios. </p>
								<p> The lower table shows the estimated capital cost in each year, corresponding to the modelled uptake.`
								: `<p>This feature allows you to model the gradual uptake of this action from now until ${settings.parameters.horizon}. 
								Each vertical slider represents uptake by % of the final uptake, allowing you to model different scenarios for reach the targed in ${settings.parameters.horizon}.</p>
								<p> The lower table shows the estimated capital cost in each year, corresponding to the modelled uptake.`
						

	    			d3.selectAll('.details-content, .details-description').classed('slider', true)
	    			detailsHeader.html('Modelling uptake of '+actionParameters.meta.label+' in '+ui.state.agencyName+' '+ui.state.sitegroup.toLowerCase()+' to '+settings.parameters.horizon)
					detailsDesc.html(uptakeDesc )
					
					const sliderTableContainer = detailsContent.append('div').attr('id', 'sliderTable'),
					 	investmentTableContainer = detailsContent.append('div').attr('id', 'investmentTable'),
						imapctTableContainer = detailsContent.append('div').attr('id', 'impactTable'),
						noSites = ui.state.sitegroup !== "All of agency" ? actionSettings.uptakeTotalSites : 100, 	// Make it 100 for all of ageny actions
						unitCapitalCost = ui.state.sitegroup !== "All of agency" ? actionSettings.cost.capitalCost : actionSettings.cost.capitalCost / 100

					sliderTableContainer.append('div').classed('activity-table-header', true).html(uptakeLabel)
					tableContainer = sliderTableContainer.append('div').classed('activity-table-container', true)
					tableHeaderRow = tableContainer.append('div').classed('details-table-headerRow', true)
					tableButtonUpRow 	= tableContainer.append('div').classed('details-table-buttonUpRow', true)
					tableSliderRow 		= tableContainer.append('div').classed('details-table-sliderRow', true)
					tableButtonDownRow 	= tableContainer.append('div').classed('details-table-buttonDownRow', true)
					tableValuesRow 		= tableContainer.append('div').classed('details-table-inputRow', true)

					investmentTableContainer.append('div').classed('activity-table-header second', true).html('Estimated capital expenditure (in real $'+dataModel.schema.baselineYear+')')
					invTableContainer = investmentTableContainer.append('div').classed('activity-table-container', true)
					invTableHeaderRow = invTableContainer.append('div').classed('details-table-headerRow', true)
					const invCapexContainer = invTableContainer.append('div').classed('table-dataRow-container', true)

					modelYears.forEach( (year, i) => { 
						tableHeaderRow.append('div').classed('slider-table-year', true).html(year)
						tableButtonUpRow.append('div').classed('slider-button', true).html('+')
							.attr('id', 'buttonUp-'+year)
							.on('click', async function(){ 							
								const increasedValue = Math.round((+d3.select('#slider-'+year).attr('value')  + 1) * 100) / 100,	
								 	capex = (unitCapitalCost * increasedValue) > 1000000000 ?  helpers.numberFormatters.formatComma1dec((unitCapitalCost * increasedValue)/1000000000)+'bn' : (unitCapitalCost * increasedValue) > 1000000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost * increasedValue)/1000000)+' m' : (unitCapitalCost * increasedValue) > 1000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost * increasedValue)/1000)+' k' :  helpers.numberFormatters.formatComma(unitCapitalCost * increasedValue)
								d3.select("#slider-"+year).attr('value', increasedValue)
								d3.select('#input-'+year).attr('value', increasedValue) 
								d3.select("#capex-"+year).html(capex)	
								actionSettings.uptake[i] = increasedValue / noSites
								await updateActionUptake(ui.state.actionID, ui.state.agencyName, ui.state.sitegroup, "Uptake change")	
								await aggregateActionModels()	
								await updateActionCase()	
								await updateWedgesChart('main')																								
							})		

						tableButtonDownRow.append('div').classed('slider-button', true).html('-')
							.attr('id', 'buttonDown-'+year)
							.on('click', async function(){ 
								const decreasedValue = Math.round((+d3.select('#slider-'+year).attr('value') - 1) *100) / 100,								
								 	capex = (unitCapitalCost * decreasedValue) > 1000000000 ?  helpers.numberFormatters.formatComma1dec((unitCapitalCost * decreasedValue)/1000000000)+'bn' : (unitCapitalCost * decreasedValue) > 1000000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost * decreasedValue)/1000000)+' m' : (unitCapitalCost * decreasedValue) > 1000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost * decreasedValue)/1000)+' k' :  helpers.numberFormatters.formatComma(unitCapitalCost * decreasedValue)
								d3.select('#slider-'+year).attr('value', decreasedValue)
								d3.select('#input-'+year).attr('value', decreasedValue) 
								d3.select("#capex-"+year).html(capex)					
								actionSettings.uptake[i] = decreasedValue / noSites												
								await updateActionUptake(ui.state.actionID, ui.state.agencyName, ui.state.sitegroup, "Uptake change")	
								await aggregateActionModels()	
								await updateActionCase()	
								await updateWedgesChart('main')								
							})	
						tableSliderRow.append('div').classed('table-sliderContainer', true)
							.append('input').classed('table-slider', true)
							.attr('id', 'slider-'+year)
							.attr('type', 'range')
							.attr('step', 1)				
							.attr('max', noSites)										
							.attr('orient', 'vertical')
							.attr('value', Math.round(actionSettings.uptake[i] * noSites))
							.on('change', async function(){ 
								d3.select("#input-"+year).attr('value', Math.round(this.value))
								d3.select("#slider-"+year).attr('value', Math.round(this.value)) 			// For some reason the native slider value update isn't being picked up by the +/- buttons
								actionSettings.uptake[i] = Math.round(this.value) / noSites
								const capex = (unitCapitalCost * this.value) > 1000000000 ?  helpers.numberFormatters.formatComma1dec((unitCapitalCost * this.value)/1000000000)+'bn' : (unitCapitalCost * this.value) > 1000000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost *  this.value)/1000000)+' m' : (unitCapitalCost * this.value) > 1000 ? helpers.numberFormatters.formatComma1dec((unitCapitalCost * this.value)/1000)+' k' :  helpers.numberFormatters.formatComma(unitCapitalCost * this.value)
								d3.select("#capex-"+year).html(capex)						
								await updateActionUptake(ui.state.actionID, ui.state.agencyName, ui.state.sitegroup, "Uptake change")	
								await aggregateActionModels()	
								await updateActionCase()	
								await updateWedgesChart('main')	
							})

						tableValuesRow.append('div').classed('table-inputContainer', true)
							.append('input').classed('table-input', true)
							.attr('id', 'input-'+year)
								.attr('type', 'number')
								.attr('min', 0)
								.attr('max', noSites)
								.attr('step', 1)							
								.attr('value', Math.round(actionSettings.uptake[i] * noSites, 1))
								.on('input', async function(){
									d3.select("#slider-"+year+' > input').attr('value', +this.value)
									actionSettings.uptake[i] = Math.round(this.value) / noSites
									document.getElementById("capex-"+year).value = this.value * unitCapitalCost						
									await updateActionUptake(ui.state.actionID, ui.state.agencyName, ui.state.sitegroup, "Uptake change")	
									await aggregateActionModels()	
									await updateActionCase()	
									await updateWedgesChart('main')	
								})

						invTableHeaderRow.append('div').classed('slider-table-year', true).html(year)				 		
						const capex = unitCapitalCost * Math.round(actionSettings.uptake[i] * noSites) > 1000000000 ? helpers.numberFormatters.formatComma1dec(unitCapitalCost *  Math.round(actionSettings.uptake[i] * noSites)/1000000000)+'bn' 
							: unitCapitalCost *  Math.round(actionSettings.uptake[i] * noSites) > 1000000 ? helpers.numberFormatters.formatComma1dec(unitCapitalCost * Math.round(actionSettings.uptake[i] * noSites)/1000000)+' m' 
								: unitCapitalCost * Math.round(actionSettings.uptake[i] * noSites) > 1000 ? helpers.numberFormatters.formatComma1dec(unitCapitalCost *  Math.round(actionSettings.uptake[i] * noSites)/1000)+' k' 
									:  helpers.numberFormatters.formatComma(unitCapitalCost *  Math.round(actionSettings.uptake[i] * noSites))
				 		
				 		invCapexContainer.append('div').attr('id', 'capex-'+year).classed('table-dataRow-data capex', true).html(capex) 
					})
	    			break

	    		case 'businessCase':   		
	    			ui.state.actionID =  this.getAttribute('sourceType') === 'costCurve' ? this.getAttribute('actionID') : ui.state.actionID
					actionParameters = model.action.parameters[ui.state.actionID]
	    			// Setup and  the details container
					tableContainer  = detailsContent.append('div').classed('activity-table-container', true)
					tableHeaderRow  = tableContainer.append('div').classed('details-table-headerRow', true)	  	    		
	    			detailsHeader.html("Business case for "+actionParameters.meta.label)
					let modelDescription
		    			// Get parameters by case type
		    			switch(ui.state.agencyID){
							case 'allAgency':
								switch(ui.state.clusterID){
									// CASE A: WHOLE OF GOV | ALL AGENCIES 
									case 'allClusters':	
										actionBCdata = model.action.businessCase.byWholeOfGov_sitegroup_action[ui.state.sitegroup][ui.state.actionID]
										actionLife = actionParameters.meta.life === 1 ? actionParameters.meta.life+' year' :  actionParameters.meta.life+' years'
										modelTime = [...Array(actionParameters.meta.life).keys()]					
										// Uptake the details context fields

										modelDescription = ui.state.sitegroup !== 'All of agency' ? `<p>This table details the supporting discounted cash flow (DCF) business case analysis for an average ${actionParameters.meta.label} modelled (i.e. with average costs and emissions reduction impact modelled for one site). This economic analysis supports the indicative summary metrics presented for each action and assumes implementation 'today' (year 0) and is conducted across an indicative economic life of the ${actionParameters.meta.techName} (modelled as being ${actionLife} years.</p>`
											: `<p>This table details the supporting discounted cash flow (DCF) business case analysis for the aggregated ${actionParameters.meta.label} modelled (i.e. across all assets modelled). This economic analysis supports the indicative summary metrics presented for each action and assumes implementation 'today' (year 0) and is conducted across an indicative economic life of the ${actionParameters.meta.techName} (modelled as being ${actionLife} years.</p>`
										detailsDesc.html(modelDescription)
										tableHeaderRow.append('div').attr('id', 'activity-table-header').classed('activity-table-header', true).html('Model of costs and benefits over the life of '+actionParameters.meta.techName)
										break
									// CASE B:  ALL AGENCIES FOR A SPECIFIED CLUSTER 
									default:
										actionBCdata = model.action.businessCase.byCluster_sitegroup_action[ui.state.clusterName][ui.state.sitegroup][ui.state.actionID]
										actionLife = actionParameters.meta.life === 1 ? actionParameters.meta.life+' year' :  actionParameters.meta.life+' years'
										modelTime = [...Array(actionParameters.meta.life).keys()]	
										modelDescription = ui.state.sitegroup !== 'All of agency' ? `<p>This table details the supporting discounted cash flow (DCF) business case analysis for an average ${actionParameters.meta.label} modelled (i.e. with average costs and emissions reduction impact modelled for one site, in the "+ui.state.clusterName+" cluster). This economic analysis supports the indicative summary metrics presented for each action and assumes implementation 'today' (year 0) and is conducted across an indicative economic life of the ${actionParameters.meta.techName}  (modelled as being ${actionLife} years.</p>`
											: `<p>This table details the supporting discounted cash flow (DCF) business case analysis for  the aggregated ${actionParameters.meta.label} modelled (i.e. across all assets modelled in the ${ui.state.clusterName} cluster). This economic analysis supports the indicative summary metrics presented for each action and assumes implementation 'today' (year 0) and is conducted across an indicative economic life of the ${actionParameters.meta.techName}  (modelled as being ${actionLife} years.</p>`
										// Uptake the details context fields
										detailsDesc.html(modelDescription)
										tableHeaderRow.append('div').attr('id', 'activity-table-header').classed('activity-table-header', true).html('Model of costs and benefits over the life of '+actionParameters.meta.techName+' in the '+ui.state.clusterName+' cluster')
										break
								}
							 	break

							// CASE C: AGENCY SPECIFIED | ANY CLUSTER SELECTION 
							default: 
								actionBCdata = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][ui.state.actionID]
								actionSettings = settings.action.byAgency_sitegroup[ui.state.agencyName][ui.state.sitegroup][ui.state.actionID]
								actionLife = actionSettings.economicLife === 1 ? actionSettings.economicLife+' year' :  actionSettings.economicLife+' years'
								modelTime = [...Array(actionSettings.economicLife).keys()]
								modelDescription !== 'All of agency' ? `<p>This table details the supporting discounted cash flow (DCF) business case analysis for ${actionParameters.meta.techName} action (i.e. with costs and emissions reduction impact modelled for one site). 
									This economic analysis supports the indicative summary metrics presented for each action. 
									It models the implementation of a 'unit of action today' (in year 0) and considers the cash flow and emissions impacts over the ${actionLife} year economic life of the action.</p>`
								 	: `<p>This table details the supporting discounted cash flow (DCF) business case analysis for ${actionParameters.meta.techName} action, with costs and emissions reduction impact modelled for all targeted assets. 
									This economic analysis supports the indicative summary metrics presented for the action. 
									It models the implementation of the action 'today' (in year 0) and considers the cash flow and emissions impacts over the ${actionLife} year economic life of the action.</p>`

								// Update the details context fields
								detailsDesc.html(modelDescription)
								tableHeaderRow.append('div').attr('id', 'activity-table-header').classed('activity-table-header', true)
									.html('Model of costs and benefits over the life of '+actionParameters.meta.techName)
						} 			


					tableHeaderRow.append('div').classed('table-dataRow-label', true).html('Model year')				
					modelTime.forEach( year => { tableHeaderRow.append('div').classed('table-year', true).html('Yr. '+year)	})

					const cashOutflowContainer = tableContainer.append('div').classed('cashOutflow-container', true),
						cashInflowContainer = tableContainer.append('div').classed('cashInflow-container', true),
					 	summaryCashflow = tableContainer.append('div').classed('summaryCashFlow-container', true),
					 	impactContainer = tableContainer.append('div').classed('netCashflow-container', true),
					 	assumptionsContainer = tableContainer.append('div').classed('assumptions-container', true)

					if(actionParameters.impact.type === 'offset'){
						detailsDesc.html(`<p>This table details the supporting discounted cash flow (DCF) business case analysis for a power purchase agreement. 
							This is simplified model where the premium or discount of PPA electricity represents the only financial difference to otherwise contracted grid electricity price. 
							It should be noted that this analysis is used for determining the levelised coat of abatement; while the implementation 'uptake' is modelled separately.</p>`)
						d3.select('#activity-table-header').html('Model of costs and benefits of a '+actionParameters.meta.techName+' (uptake from year zero')
						cashOutflowContainer.classed('hidden', true)
						cashInflowContainer.classed('hidden', true)
					}

					// Cash outflows: Capital, annual O&M and any switched to costs
					cashOutflowContainer.append('div').classed('table-subHeader', true).html('Costs')
						const capitalCost = cashOutflowContainer.append('div').classed('table-dataRow-container', true)
					 	capitalCost.append('div').classed('table-dataRow-label', true).html('Capital cost')
					 	modelTime.forEach(year => {
					 		capitalCost.append('div').classed('table-dataRow-data financial', true)
								.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Marginal capital cost'][year]) )
					 	})
						// For added O&M costs
						if(d3.sum(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'] ) >= 0){
							const omCost = cashOutflowContainer.append('div').classed('table-dataRow-container', true)
							omCost.append('div').classed('table-dataRow-label', true).html('Operations and maintenance costs')
							modelTime.forEach(year => {
								omCost.append('div').classed('table-dataRow-data financial', true)
									.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'][year]) )
							})
						}
						// Optional: for switches
						if(d3.sum(actionBCdata.businessCase['Cashflow items']['Additional cost'] ) > 0){
							const switchCosts = cashOutflowContainer.append('div').classed('table-dataRow-container', true),
								switchCostsLabel = (actionParameters.impact.to[0].sector === 'Stationary energy' || actionParameters.impact.to[0].sector === 'Transport') ? `Switched to fuel costs (${actionParameters.impact.to[0].source})`
												: "Switched to item costs"
						 	switchCosts.append('div').classed('table-dataRow-label', true).html(switchCostsLabel)
						 	modelTime.forEach(year => {
						 		switchCosts.append('div').classed('table-dataRow-data financial', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Additional cost'][year]) )
						 	})
						}

					// Cash inflows: Energy savings/avoided spend and revenue from generation
					cashInflowContainer.append('div').classed('table-subHeader', true).html('Benefits')
						const financialSaving = cashInflowContainer.append('div').classed('table-dataRow-container', true),
							financialSavingLabel = (actionParameters.impact.from[0].sector === 'Stationary energy') ? "Energy cost saving"
												: actionParameters.impact.from[0].sector === 'Transport'  ? "Fuel cost saving" 
												: "Avoided spend"
					 	financialSaving.append('div').classed('table-dataRow-label', true).html(financialSavingLabel)
					 	modelTime.forEach(year => {
					 		financialSaving.append('div').classed('table-dataRow-data financial', true)
								.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Avoided cost'][year]) )
					 	})
						// For reduced O&M costs
						if(d3.sum(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'] ) < 0){
							const omCost = cashInflowContainer.append('div').classed('table-dataRow-container', true)
							omCost.append('div').classed('table-dataRow-label', true).html('Operations and maintenance benefits')
							modelTime.forEach(year => {
								omCost.append('div').classed('table-dataRow-data financial', true)
									.html(helpers.numberFormatters.formatComma(-actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'][year]) )
							})
						}

						// Optional for generation
						if(d3.sum(actionBCdata.businessCase['Cashflow items']['Revenue'] ) > 0){
							const energyRevenue = cashInflowContainer.append('div').classed('table-dataRow-container', true)
						 	energyRevenue.append('div').classed('table-dataRow-label', true).html('Revenue from generation')
						 	modelTime.forEach(year => {
						 		energyRevenue.append('div').classed('table-dataRow-data financial', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Revenue'][year]) )
						 	})
						}
					// Cash flow summary: Net CF, cumulative cash and discounted net cash
					summaryCashflow.append('div').classed('table-subHeader', true).html('Cash flow summary')
						const netCashflow = summaryCashflow.append('div').classed('table-dataRow-container', true)
					 	netCashflow.append('div').classed('table-dataRow-label', true).html('Net cash flow')
					 	modelTime.forEach(year => {
					 		netCashflow.append('div').classed('table-dataRow-data financial', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Net cash flow'][year]) )
					 	})

					 	const cumulativeCashflow = summaryCashflow.append('div').classed('table-dataRow-container', true)
					 	cumulativeCashflow.append('div').classed('table-dataRow-label', true).html('Cumulative cash position')
					 	modelTime.forEach(year => {
					 		cumulativeCashflow.append('div').classed('table-dataRow-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cumulative cash flow'][year]) )
					 	})
					 	const discountedCashflow = summaryCashflow.append('div').classed('table-dataRow-container', true)
					 	discountedCashflow.append('div').classed('table-dataRow-label', true).html('Discounted net cash flow (at '+helpers.numberFormatters.formatPct1dec(settings.parameters.financial["Discount factor"][1]-1)+' p.a.)')
					 	modelTime.forEach(year => {
					 		discountedCashflow.append('div').classed('table-dataRow-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Discounted cash flow'][year]) )
					 	})
					 	const discountedCumCashflow = summaryCashflow.append('div').classed('table-dataRow-container', true)
					 	discountedCumCashflow.append('div').classed('table-dataRow-label', true).html('Cumulative discounted net cash flow')
					 	modelTime.forEach(year => {
					 		discountedCumCashflow.append('div').classed('table-dataRow-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cumulative DCF'][year]) )
					 	})

					// Emissions and natural unit impacts
					impactContainer.append('div').classed('table-subHeader', true).html('Action impacts')
						const emissionsImpact = impactContainer.append('div').classed('table-dataRow-container', true)
					 	emissionsImpact.append('div').classed('table-dataRow-label', true).html('Net emissions reduction (tCO2-e)')
					 	modelTime.forEach(year => {
					 		emissionsImpact.append('div').classed('table-dataRow-data financial', true)
								.html(helpers.numberFormatters.formatComma1dec(actionBCdata.businessCase['Emissions abatement'][year] / actionSettings.uptakeTotalSites  ) )
					 	})
						const naturalVolSources = actionParameters.impact.from.map(d => d.source),
							rolledUpSources = {} 
								
						for( const source of naturalVolSources){
							rolledUpSources[source] = actionBCdata.impact.outflow.filter(d => d.source === source).map(d => d.naturalVolume).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), [])
						}

						naturalVolSources.forEach( (source , i) => {
							if(!isNaN(rolledUpSources[source][0])){
								const reduceNaturalImpact = impactContainer.append('div').classed('table-dataRow-container', true),
									reducedSource = actionParameters.impact.from[i]['source']
									reducedUnit = dataModel.schema.inventory[actionParameters.impact.from[0]['sector']][actionParameters.impact.from[i]['source']].unit
								reduceNaturalImpact.append('div').classed('table-dataRow-label', true).html('Reduced '+reducedSource.toLowerCase()+' demand ('+reducedUnit+')')
								modelTime.forEach(year => {
									reduceNaturalImpact.append('div').classed('table-dataRow-data financial', true)
										.html(helpers.numberFormatters.formatComma1dec(rolledUpSources[source][year] / actionSettings.uptakeTotalSites ) )
								})
							}
						})

						// Optional: volume fuel switch to
						if(typeof(actionBCdata.businessCase['Natural volume new consumption (fuel switch)']) !== 'undefined' && d3.sum(actionBCdata.businessCase['Natural volume new consumption (fuel switch)']) > 0){
							const addedConsumption = impactContainer.append('div').classed('table-dataRow-container', true),
								addedSource = actionParameters.impact.to[0]['source'],
								addedUnit = dataModel.schema.inventory[actionParameters.impact.to[0]['sector']][actionParameters.impact.to[0]['source']].unit
					 		addedConsumption.append('div').classed('table-dataRow-label', true).html('Increased '+addedSource.toLowerCase()+' demand ('+addedUnit+')')
							modelTime.forEach(year => {
								addedConsumption.append('div').classed('table-dataRow-data financial', true)
					 			 	.html(helpers.numberFormatters.formatComma1dec(actionBCdata.businessCase['Natural volume new consumption (fuel switch)'][year] / actionSettings.uptakeTotalSites ) )
							})
						}

					 // Key assumptions only at agency level
					if(ui.state.agencyID !== 'allAgency'){
						assumptionsContainer.append('div').classed('table-subHeader', true).html('Key assumptions')
						// Add all avoided prices
						if(actionBCdata.businessCase['Modelled tariffs']['Avoided']){
							actionBCdata.businessCase['Modelled tariffs']['Avoided'].forEach((avoidedCostObj, i) => {
								const priceAvoided = assumptionsContainer.append('div').classed('table-dataRow-container', true),
									priceAvoidedUnit = actionBCdata.businessCase['Modelled tariffs']['Avoided unit'][i]

								priceAvoided.append('div').classed('table-dataRow-label', true).html('Modelled avoided price ('+priceAvoidedUnit+')')
								modelTime.forEach(year => {
									priceAvoided.append('div').classed('table-dataRow-data financial', true)
										.html(helpers.numberFormatters.formatComma1dec(avoidedCostObj[year]) )
								})	
							})
						}
						// Optional: Add revenue prices (solar)
						if(d3.sum(actionBCdata.businessCase['Cashflow items']['Revenue'] ) > 0){
							const energyRevenuePrice = assumptionsContainer.append('div').classed('table-dataRow-container', true),
							 	energyRevenueUnit = actionBCdata.businessCase['Modelled tariffs']['Revenue unit']
						 	energyRevenuePrice.append('div').classed('table-dataRow-label', true).html('Exported solar price  ('+energyRevenueUnit+')')
						 	modelTime.forEach(year => {
					 			energyRevenuePrice.append('div').classed('table-dataRow-data financial', true).html(helpers.numberFormatters.formatComma1dec(actionBCdata.businessCase['Modelled tariffs']['Revenue'][year]) )
						 	})
						}
					}					 	
	    			break

	    		case 'actionInfo':
				 	actionParameters = model.action.parameters[ui.state.actionID]
	    			detailsHeader.html(actionParameters.meta.label+' in '+ui.state.sitegroup.toLowerCase() )
	    			detailsDesc.style('background', 'url("'+actionParameters.meta.imageURL+'")').style('background-size', 'cover')
					detailsHeader.html('About '+actionParameters.meta.label)
					detailsContent.append('div').html(actionParameters.meta.longDescription)
	    			break

	    		case 'siteDetails':
	    			if(ui.state.agencyName !== 'All agencies'){
		    			const siteData = dataModel.schema.consumption.sitesByAgencySitegroup[ui.state.agencyName]
		    			detailsHeader.html("Sites included in the model for "+ui.state.agencyName)
						detailsDesc.html("<p>The dataset used to provide annual consumption and cost data (from the CASPER system for FY"+dataModel.schema.baselineYear+") reports at the 'meter' level. The dataset contains consumption and emissions activity for all facilities on Government contracts, and is categorised and aggregated by building 'type'. Data is also available to group each meter reading to a site (usually an address, however it should be noted that a particular building can span multiple addresses in CASPER). This 'count' of sites is useful for presenting action cost and impact data on an easier to understand 'per site' basis. The table here shows all the site names / addresses that make up this 'count' of sites.<p>")
						
						Object.keys(siteData).forEach( sitegroup => {
							detailsContent.append('div').classed('site-table-header', true).html( (sitegroup === "Unassigned" ? "Other" : sitegroup)+' ('+siteData[sitegroup].length+')')
							const sitegroupListContainer = detailsContent.append('div').classed('site-table-listContainer', true)
								.append('ul').classed('sitelist', true)
							siteData[sitegroup].forEach( sitename => {
								if(typeof siteMeta[sitename] !== 'undefined') { sitename = siteMeta[sitename].names[0]}	
								sitegroupListContainer.append('li').html(sitename) 
							})					
						})
					}
	    			break

	    		case 'practicalSiteInfo':
	    			detailsHeader.html("Load profile assumptions and practical considerations for implementing upgrades in "+ui.state.sitegroup.toLowerCase())
					const siteInfoContainer = detailsContent.append('div').classed('sitegroup-info', true)
					siteInfoContainer.append('div').classed('activity-table-header', true).html('Load profile characteristics for '+ui.state.sitegroup.toLowerCase())
					siteInfoContainer.append('div').html(content.loadProfile[ui.state.sitegroup].description)
	    			break
	    	}
	    	
			ui.methods.nav.toggleDetailsView()
	    };

	    // Tracks the parameter being changed in settings
		ui.methods.dataView.idParameterChange = function(){
			ui.dynamics.changedParameter = {
				elementId: 				'',
				parameterType: 			'general',
				parameterName: 			'wacc',
				agency: 				'',
				sitegroup: 				'',
			}
			// Call the reference case
			updateReferenceCase(settings)
		};// end idParameterChange()

		// Update the report
		ui.methods.updateReport = async() => {
			console.log('Rendering report for '+ui.state.agencyName)
			// Setup report on initilisation
			d3.select('#report-agencySelector option').attr('disabled', true).html("Select an agency")
			d3.selectAll('#report-index-contaner input').attr('checked', null).attr('disabled', true)	
			d3.selectAll('.report-page-container, .report-section-divider').classed('hidden', true)

			if(ui.state.agencyName !== 'All agencies'){
				const testMode = false
				const userActions = [],
					userAgencyActions = []
					userActionObj = {}

				let totalUserActions = 0,
					totalUserAgencyActions = 0

				// Default all sections to visible
					d3.selectAll('#report-index-contaner input').attr('checked', true).attr('disabled', null)
						.on('click', function(){ 
							document.getElementById('report-'+this.value).classList.toggle('hidden')
							if(!document.getElementById('report-'+this.value).classList.contains('hidden')){
								document.getElementById('report-'+this.value).scrollIntoView()
							}
						})	
					d3.selectAll('.report-page-container, .report-section-divider').classed('hidden', false)
				//  Turn off business case details as default
					document.getElementById('report-index-option-businessCaseDetails').checked = false
					d3.select('#report-businessCaseDetails').classed('hidden', true)

					Object.entries(settings.action.byAgency_sitegroup).forEach(([agency, agencyObj]) => {
						userActionObj[agency] = {}
						Object.entries(agencyObj).forEach(([sitegroup, sitegroupObj]) => {
						userActionObj[agency][sitegroup] = []
							Object.entries(sitegroupObj).forEach(([actionID, actionObj]) => {
								if(actionObj.userUpdated || testMode){
									userActionObj[agency][sitegroup].push(actionID)
									totalUserActions++
									if(userActions.indexOf(actionID) < 0){
										userActions.push(actionID)
									}
									if(agency === ui.state.agencyName){
										totalUserAgencyActions++
										if(userAgencyActions.indexOf(actionID) < 0){
											userAgencyActions.push(actionID)
										}
									}
								}					
							})
						})
					})

				// Clear the report content
					d3.selectAll('#report-pathways-vis *').remove()
					d3.selectAll('#reportDetail-pathways-vis *').remove()
					d3.selectAll('#report-macc-vis *').remove()
					d3.selectAll('#report-actionSummary-table tbody *').remove()		
					d3.selectAll('#report-inventory-table tbody *').remove()		
					d3.selectAll('.uptake-table-header').remove()
					d3.selectAll('#report-actionUptake-table tbody *').remove()
					d3.selectAll('#report-actionSummary .data-row').remove() 			
					d3.selectAll('#report-agency-action-container *').remove() 			
					d3.selectAll('#report-actionUptake-table tbody .uptake-row:not(#report-uptakeImpact-year-headers)').remove() 		
					d3.selectAll('#report-actionDescriptions-container *').remove()
					d3.selectAll('.assumption-table-header, .assumption-table-data').remove()			
					d3.selectAll('#report-consumption-table tbody *').remove()
					d3.selectAll('#report-grep-table tbody *').remove()
					d3.selectAll('#report-detailedBC-container *').remove()

				// 1. Render chart visualisations for print layout
				await renderWedgesChart('report-pathways-vis', 'report', 'print', 'static')
				await renderWedgesChart('reportDetail-pathways-vis', 'reportDetail', 'print', 'static')
				await renderCostCurve('report-macc-vis', 'report', 'print', 'static')

				await vis.wedgesChart.methods.showDetailedLabel('reportDetail') 

				// 2. Build the inventory table
					// Build a total emissions object prior (to help with percentages)
					const totalEmissions = {
						Scope1: 	Array(dataModel.schema.modelHorizon).fill(0),
						Scope2: 	Array(dataModel.schema.modelHorizon).fill(0),
						Scope3: 	Array(dataModel.schema.modelHorizon).fill(0),
						Total: 		Array(dataModel.schema.modelHorizon).fill(0),
						bySector: {}
					}
					// Find totalEmissions object: Divide by 2 as two inventory tables are built 
					const refCaseData = typeof model.inventory.referenceCase.byAgency[ui.state.agencyName] === 'undefined' ? null : model.inventory.referenceCase.byAgency[ui.state.agencyName]
					for( const inventoryObj of ui.inventoryOrder){
						const sector = Object.keys(inventoryObj)[0],
							sourceList = Object.values(inventoryObj)[0]
						if(refCaseData && refCaseData[sector] && Object.keys(refCaseData[sector]).length > 0){
							if (typeof totalEmissions.bySector[sector] === 'undefined'){ 
								totalEmissions.bySector[sector] = 0
							}
							for( const source of sourceList){	
								if(typeof refCaseData[sector][source] !== 'undefined'){
									totalEmissions.Scope1 = totalEmissions.Scope1.map((d,i)  => d + refCaseData[sector][source].emissions.Scope1[i] )  
									totalEmissions.Scope2 = totalEmissions.Scope2.map((d,i)  => d + refCaseData[sector][source].emissions.Scope2[i] ) 
									totalEmissions.Scope3 = totalEmissions.Scope3.map((d,i)  => d + refCaseData[sector][source].emissions.Scope3[i] )	
									totalEmissions.Total = totalEmissions.Total.map((d,i)  => d + refCaseData[sector][source].emissions.Total[i]  )									
									totalEmissions.bySector[sector] += refCaseData[sector][source].emissions.Total[0]
								}
							}
						}
					}

					// Build the inventory table structure
					//  Solar data and track totals by scopr	
					let solarData, solarCapacity, solarGeneration, solarUnit,
						agencyScope1 = 0, 	agencyScope2 = 0, 	agencyScope3 = 0,  agencyTotal = 0	

					if(refCaseData){
						const tableBody = d3.select('#report-inventory-table tbody'),
							solarAgencyList = data.grepProjectsBy.solarProjectsByAgency.map(d => d.key)
								
						if(solarAgencyList.indexOf(ui.state.agencyName) > -1){				
							solarData 			= data.grepProjectsBy.solarProjectsByAgency[solarAgencyList.indexOf(ui.state.agencyName)].value
							solarCapacity 		= helpers.numberFormatters.formatComma1dec(solarData['Solar installed (kW)'])
							solarGeneration 	= solarData['Elec saving (kWh)'] > 1000000 ? helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)'] / 1000000)+' GWh' : helpers.numberFormatters.formatComma1dec(solarData['Elec saving (kWh)']/1000 )+' MWh'
							solarUnit 			= solarData['Solar installed (kW)'] > 1000 ? 'MW installed' : 'kW installed'
						} else {
							solarData 			= null
							solarCapacity 		= 'None'
							solarGeneration 	= 'None'
							solarUnit 			= ''
						}

						ui.inventoryOrder.forEach( (obj, i) => {
							const sector = Object.keys(obj)[0],
							sourceArray =  Object.keys(model.inventory.referenceCase.byAgency[ui.state.agencyName][sector])

							if(sourceArray.length > 0){
								const	sectorHeaderRow = tableBody.append('tr').classed('inventory-row', true)
									sectorHeaderRow.append('td').classed('sector-header inventory-datum left top', true)
										.attr('colspan', 12)
										.html(`${sector} | ${helpers.numberFormatters.formatPct1dec(totalEmissions.bySector[sector] / totalEmissions.Total[0] )}`)

								sourceArray.forEach((source, i) => {
									if(refCaseData[sector] && refCaseData[sector][source] ){
										const rowContainer = tableBody.append('tr').classed('inventory-row', true)
										rowContainer.append('td').classed('source-header inventory-datum left', true)
											.attr('colspan', 4)
											.html(source)
										rowContainer.append('td').classed('inventory-datum right', true)
											.html(refCaseData[sector][source].naturalVolume[0] < 100 ? helpers.numberFormatters.formatComma1dec(refCaseData[sector][source].naturalVolume[0]) :  helpers.numberFormatters.formatComma(refCaseData[sector][source].naturalVolume[0]) )
										rowContainer.append('td').classed('inventory-datum center', true)
											.html(refCaseData[sector][source].naturalUnit)
										rowContainer.append('td').classed('inventory-datum volume right', true)
											.html(refCaseData[sector][source].emissions.Scope1[0] < 100 ? helpers.numberFormatters.formatComma1dec(refCaseData[sector][source].emissions.Scope1[0]): helpers.numberFormatters.formatComma(refCaseData[sector][source].emissions.Scope1[0]))
										rowContainer.append('td').classed('inventory-datum volume right', true)
											.html(refCaseData[sector][source].emissions.Scope2[0] < 100 ? helpers.numberFormatters.formatComma1dec(refCaseData[sector][source].emissions.Scope2[0]): helpers.numberFormatters.formatComma(refCaseData[sector][source].emissions.Scope2[0]))
										rowContainer.append('td').classed('inventory-datum volume right', true)
											.html(refCaseData[sector][source].emissions.Scope3[0] < 100 ? helpers.numberFormatters.formatComma1dec(refCaseData[sector][source].emissions.Scope3[0]): helpers.numberFormatters.formatComma(refCaseData[sector][source].emissions.Scope3[0]))
										rowContainer.append('td').classed('inventory-datum volume right bold', true).attr('colspan', 2)
											.html(refCaseData[sector][source].emissions.Total[0] < 100 ? helpers.numberFormatters.formatComma1dec(refCaseData[sector][source].emissions.Total[0])+' tCO<sub>2</sub>-e' : helpers.numberFormatters.formatComma(refCaseData[sector][source].emissions.Total[0])+' tCO<sub>2</sub>-e')
										rowContainer.append('td').classed('inventory-datum centre', true)
											.html(helpers.numberFormatters.formatPct1dec(refCaseData[sector][source].emissions.Total[0] / totalEmissions.Total[0]))
										// Update emisisons totals
										agencyScope1 += refCaseData[sector][source].emissions.Scope1[0]
										agencyScope2 += refCaseData[sector][source].emissions.Scope2[0]
										agencyScope3 += refCaseData[sector][source].emissions.Scope3[0]
										agencyTotal += refCaseData[sector][source].emissions.Total[0]
									}
								})	
							}
						})
						// Add net emissions and renewables
						const renewablesHeaderRow 	= tableBody.append('tr').classed('inventory-row renewables', true),
						 	renewablesRow 			= tableBody.append('tr').classed('inventory-row renewables', true),
							netEmissionsRow 		= tableBody.append('tr').classed('inventory-row totals', true),
							netEmissionsPctRow 		= tableBody.append('tr').classed('inventory-row totals pct', true)

						netEmissionsRow.append('td').classed('sector-header inventory-datum left', true).attr('colspan', 4)
							.html('Net emissions')
						netEmissionsRow.append('td').classed('hidden-datum', true)
							.html(' ')
						netEmissionsRow.append('td').classed('hidden-datum', true)
							.html(' ')
						netEmissionsRow.append('td').classed('inventory-datum volume right', true)
							.html(agencyScope1 < 100 ? helpers.numberFormatters.formatComma1dec(agencyScope1) : helpers.numberFormatters.formatComma(agencyScope1) )
						netEmissionsRow.append('td').classed('inventory-datum volume right', true)
							.html(agencyScope2 < 100 ? helpers.numberFormatters.formatComma1dec(agencyScope2) : helpers.numberFormatters.formatComma(agencyScope2) )
						netEmissionsRow.append('td').classed('inventory-datum volume right', true)
							.html(agencyScope3 < 100 ? helpers.numberFormatters.formatComma1dec(agencyScope3) : helpers.numberFormatters.formatComma(agencyScope3) )
						netEmissionsRow.append('td').classed('inventory-datum volume right bold	', true).attr('colspan', 2)
							.html(agencyTotal < 100 ? helpers.numberFormatters.formatComma1dec(agencyTotal)+' tCO<sub>2</sub>-e' : helpers.numberFormatters.formatComma(agencyTotal)+' tCO<sub>2</sub>-e' )
						netEmissionsRow.append('td').classed('inventory-datum centre', true)
							.html('')

						netEmissionsPctRow.append('td').attr('colspan', 4).html(' ')
						netEmissionsPctRow.append('td').attr('colspan', 1).html(' ')
						netEmissionsPctRow.append('td').attr('colspan', 1).html(' ')
						netEmissionsPctRow.append('td').classed('inventory-datum volume right', true)
							.html(helpers.numberFormatters.formatPct1dec(agencyScope1/ agencyTotal))
						netEmissionsPctRow.append('td').classed('inventory-datum volume right', true)
							.html(helpers.numberFormatters.formatPct1dec(agencyScope2/ agencyTotal))
						netEmissionsPctRow.append('td').classed('inventory-datum volume right', true)
							.html(helpers.numberFormatters.formatPct1dec(agencyScope3/ agencyTotal))

						renewablesHeaderRow.append('td').classed('sector-header inventory-datum left', true)
							.attr('colspan', 12)
							.html('Renewables')
						renewablesRow.append('td').classed('source-header inventory-datum left renewables', true)
							.attr('colspan', 4)
							.html('Installed rooftop solar')
						renewablesRow.append('td').classed('inventory-datum right', true)
							.html(solarCapacity)
						renewablesRow.append('td').classed('inventory-datum left', true)
							.html(solarUnit)
						renewablesRow.append('td').classed('inventory-datum left', true).attr('colspan', 6)
							.html('')
					}

				// 3.  II. Build the action summary report table
					// III. Action uptake and emission reduction table
					// IV. Business case cards
					// V. Detailed business case by action
					const actionSummaryTableContainer = d3.select('#report-actionSummary-table tbody'),
						actionUptakeTableContainer = d3.select('#report-actionUptake-table tbody'),
						bcContainer = d3.select('#report-agency-action-container'),
						detailedBCContainer = d3.select('#report-detailedBC-container'),
						reportYears = dataModel.schema.modelYears.slice(0, settings.parameters.horizon - dataModel.schema.baselineYear + 1),
						sectorsAdded = [], modelledActions = {}, sitegroups = []
		
				// 3a. Add year headers for action uptake table
				reportYears.forEach((year, i) => { 
					d3.select('#report-uptakeImpact-year-headers').append('th').classed('right uptake-table-header', true).html(year)
				})

				// 3b. Loop through inventory to build II, III, IV  and V
				ui.inventoryOrder.forEach( (obj, i) => {
					const sector = Object.keys(obj)[0],	sourceArray = Object.values(obj)[0]

					// a. Sitegroup level actions: match for each source
					const agencySitegroupActions = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]
					if(agencySitegroupActions){
						Object.entries(agencySitegroupActions).forEach( ([sitegroup, actionObjects]) => {
							// Check for user defined actions for the site group
							if(userActionObj[ui.state.agencyName][sitegroup].length > 0){
								let sitegroupContainer, actionContainer, sitegroupHeaders = [], counter = 0

								Object.entries(actionObjects).forEach( ([actionID, actionObj]) => {
									if(model.action.parameters[actionID].meta.sector === sector && userActionObj[ui.state.agencyName][sitegroup].indexOf(actionID) > -1){
										//  Add sector and sitegroup header rows (if not alreeady added)
										if(sectorsAdded.indexOf(sector) < 0){
											sectorsAdded.push(sector)
											actionSummaryTableContainer.append('tr').classed('header-row sector data-row', true)
												.append('th')
													.attr('contenteditable', true)
													.attr('colspan', 10)
													.html(sector+' emissions reduction actions')
											actionUptakeTableContainer.append('tr').classed('header-row sector data-row', true)
												.append('th')
													.attr('contenteditable', true)
													.attr('colspan', 10)
													.html(sector+' emissions reduction actions')
											bcContainer.append('div').classed('report-sector-label', true)
												.html(sector+' emissions reduction actions')
										}
										if(sitegroupHeaders.indexOf(sitegroup) < 0){
											sitegroupHeaders.push(sitegroup)
											actionSummaryTableContainer.append('tr').classed('header-row level data-row', true)
												.append('th')
												.attr('colspan', 10)
												.html(sitegroup)

											const actionUptakeSitegroupRow = actionUptakeTableContainer.append('tr').classed('header-row level data-row', true)
												
											sitegroupContainer = bcContainer.append('div').classed('sitegroup-group', true)
											sitegroupContainer.append('div').classed('report-label sitegroup', true).html(sitegroup)
											actionContainer = sitegroupContainer.append('div').classed('report-sitegroup-action-group', true)
											// Add years to uptake table for sitegrup header
											actionUptakeSitegroupRow.append('th').attr('colspan', 3).html(sitegroup)
											reportYears.forEach((year, i) => actionUptakeSitegroupRow.append('td').classed('right uptake-table-subheader', true).html(year) )
										}
										// Record structure/lists of modelled actions
											if(typeof modelledActions[sector]=== 'undefined'){
												modelledActions[sector] = {}
											}
											if(typeof modelledActions[sector][actionID] === 'undefined'){
												modelledActions[sector][actionID] = []
											}
											if(sitegroups.indexOf(sitegroup) < 0){
												sitegroups.push(sitegroup)
											}
											modelledActions[sector][actionID].push(sitegroup)
										// GET ACTION DATA
											const actionBCdata  = model.action.businessCase.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID],
												actionParameters = model.action.parameters[actionID],
												actionSettings = settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID],
												actionType = actionParameters.impact.type,
												actionAsset = actionParameters.impact.asset,
												actionSector = actionParameters.meta.sector,
												actionSource = actionParameters.impact.from[0].source

										// I. ACTION SUMMARY TABLE: Add the action row data
											const actionRow = actionSummaryTableContainer.append('tr').classed('action-row data-row', true), 
												noSites = (actionType === 'generation') ? 1 : actionSettings.uptakeTotalSites,
												abatmentCost = helpers.numberFormatters.formatCost1dec(actionObj.businessCase.Metrics["Levelised cost of abatement"]),
												npv = helpers.numberFormatters.formatCostInteger(actionObj.businessCase.Metrics.NPV),
												uptake = sitegroup === 'All of agency' ? helpers.numberFormatters.formatPct1dec(settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].reductionPct) : helpers.numberFormatters.formatPct1dec(settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].opportunity.targetUptake),
												annualAbatement = helpers.numberFormatters.formatComma(actionObj.uptakeModel.emissionsReduction.Total[settings.parameters.horizon - dataModel.schema.baselineYear])+' tCO<sub>2</sub>-e',
												targetContribution = helpers.numberFormatters.formatPct1dec((actionObj.uptakeModel.emissionsReduction.Total[settings.parameters.horizon - dataModel.schema.baselineYear]) /settings.targets.byAgency[ui.state.agencyName].targetGHG),
												rateOfReturn = isNaN(actionObj.businessCase.Metrics.IRR) ? "No return" : helpers.numberFormatters.formatPct1dec(actionObj.businessCase.Metrics.IRR)
												discountedPayback = isNaN(actionObj.businessCase.Metrics["Discounted payback"]) ? actionObj.businessCase.Metrics["Discounted payback"]==="Under one year" ? "Under one year" 
													: "No payback" 
													: helpers.numberFormatters.formatComma1dec(actionObj.businessCase.Metrics["Discounted payback"])+' years'

											actionRow.append('td').attr('colspan', 2).classed('action-summary-title', true)
												.html(actionObj.actionName)
											actionRow.append('td').classed('action-capital-cost centre', true)		
												.html(helpers.numberFormatters.formatCostInteger(d3.sum(actionObj.businessCase["Cashflow items"]["Marginal capital cost"])))
											actionRow.append('td').classed('action-abatement-cost centre', true).html(abatmentCost)
											actionRow.append('td').classed('action-discounted-payback centre', true).html(discountedPayback)
											actionRow.append('td').classed('action-irr centre', true).html(rateOfReturn)
											actionRow.append('td').classed('action-npv centre', true).html(npv)
											actionRow.append('td').classed('action-uptake centre', true).html(uptake)
											actionRow.append('td').classed('action-annual-reduction centre', true).html(annualAbatement)
											actionRow.append('td').classed('action-contribution-pct centre', true).html(targetContribution)	

										// II. ACTION UPTAKE-IMPACT TABLE: 
											const actionLabeleRow = actionUptakeTableContainer.append('tr').classed('uptake-label level data-row', true),
												actionUptakeRow = actionUptakeTableContainer.append('tr').classed('uptake-row level data-row', true),
												actionImpactRow = actionUptakeTableContainer.append('tr').classed('impact-row level data-row', true),
												actionUptakeLabel = sitegroup !== 'All of agency' ? 'Uptake (no. sites)' 
													: actionAsset === 'vehicle' ? `Uptake (% of ${actionSource} fleet)`
													: 'Uptake (% of baseline consumption)'
												
											actionLabeleRow.append('td').attr('colspan', 3).classed('uptake-action-summary-title', true)
												.html(actionObj.actionName)
											actionUptakeRow.append('td').attr('colspan', 3).html(actionUptakeLabel)

											reportYears.forEach((year, i) => { 
												// const uptake = sitegroup !== 'All of agency' ? helpers.numberFormatters.formatComma1dec(actionObj.uptakeModel.uptakePct[i] *  actionObj.uptakeModel.noSites)
												const uptake = sitegroup !== 'All of agency' ? helpers.numberFormatters.formatComma1dec(actionObj.uptakeModel.uptakePct[i] *  actionSettings.uptakeTotalSites)
													: helpers.numberFormatters.formatPct1dec(actionObj.uptakeModel.uptakePct[i] * actionSettings.reductionPct * actionSettings.opportunity.targetUptake)
												actionUptakeRow.append('td').classed('right uptake-table-data', true).html(uptake)
											})
											actionImpactRow.append('td').attr('colspan', 3).html('Emissions reduction (tCO<sub>2</sub>-e)')
											reportYears.forEach((year, i) => { 
												actionImpactRow.append('td').classed('right uptake-table-data', true).html(
													actionObj.uptakeModel.emissionsReduction.Total[i] < 100 ? helpers.numberFormatters.formatComma1dec(actionObj.uptakeModel.emissionsReduction.Total[i])
														: helpers.numberFormatters.formatComma(actionObj.uptakeModel.emissionsReduction.Total[i]))
											})

										// III. BUSINESS CARD SUMMARY: Add Business case summary card 							
											const actionCard = actionContainer.append('div').classed('report-action-card', true)
											actionCard.append('div').classed('report-action-title', true).html(actionObj.actionName)
											const bcDetailsContainer = actionCard.append('div').classed('actionBC-details-container', true)
												bcDetailsContainer.append('hr').classed('actionDivider', true)

												const bcInputsContainer = bcDetailsContainer.append('div').classed('sitegroupAction-impact-container', true)
												bcInputsContainer.append('div').classed('sitegroupAction-modelAssumptionsLabel scene-subHeader', true).html('Model assumptions')
													const uptakeContainer = bcInputsContainer.append('div').classed('impact-uptake-container sitegroupAction-impactItem-container', true)
														uptakeContainer.append('div').classed('impact-uptakeLabel impact-label', true).html(sitegroup === 'All of agency' ? 'Uptake (% of consumption)': 'Uptake (no. sites)')
														uptakeContainer.append('div').classed('impact-uptake impact-data', true).html(
															sitegroup === 'All of agency' ? helpers.numberFormatters.formatPct1dec(actionSettings.reductionPct)
															: helpers.numberFormatters.formatComma(noSites)
														)

													const reductionContainer = bcInputsContainer.append('div').classed('impact-reduction-container sitegroupAction-impactItem-container', true)
														reductionLabel = 'Reduction % (of targeted emissions)', 
														reductionPct =  sitegroup === 'All of agency' && (actionType === 'reduction' || actionType === 'switch') ?   helpers.numberFormatters.formatPct1dec(actionSettings.opportunity.targetUptake)
															: helpers.numberFormatters.formatPct1dec(actionSettings.reductionPct)
														reductionContainer.append('div').classed('impact-reductionLabel impact-label', true).html(reductionLabel)
														reductionContainer.append('div').classed('impact-reduction impact-data', true).html(reductionPct)
													const capitalCostContainer = bcInputsContainer.append('div').classed('impact-capitalCost-container sitegroupAction-impactItem-container', true)
														capitalCostContainer.append('div').classed('impact-capitalCostLabel impact-label', true).html('Total capital cost')
														capitalCostContainer.append('div').classed('impact-capitalCost impact-data', true).html(helpers.numberFormatters.formatCostInteger(actionSettings.cost.capitalCost * noSites))
													const omCostContainer = bcInputsContainer.append('div').classed('impact-omCost-container sitegroupAction-impactItem-container', true)
														omCostContainer.append('div').classed('impact-omCostLabel impact-label', true).html('Total annual O&M cost')
														omCostContainer.append('div').classed('impact-omCost impact-data', true).html(helpers.numberFormatters.formatCostInteger(actionSettings.cost.omCost * noSites))
													const lifeContainer = bcInputsContainer.append('div').classed('impact-life-container sitegroupAction-impactItem-container', true)
														lifeContainer.append('div').classed('impact-lifeLabel impact-label', true).html('Asset life (years)')
														lifeContainer.append('div').classed('impact-life impact-data', true).html(helpers.numberFormatters.formatInteger(actionSettings.economicLife))
								
												bcDetailsContainer.append('hr').classed('actionDivider', true)
												const bcMetricsContainer = bcDetailsContainer.append('div').classed('sitegroupAction-metrics-container', true)
													bcMetricsContainer.append('div').classed('scene-subHeader', true).html('Business case')
													const abatementContainer = bcMetricsContainer.append('div').classed('metrics-abatementCost-container sitegroupAction-metricsItem-container', true)
														abatementContainer.append('div').classed('metrics-abatementCostLabel metrics-label', true).html('Abatement cost')
														abatementContainer.append('div').classed('metrics-abatementCost metrics-data', true).html(abatmentCost)
													const npvContainer = bcMetricsContainer.append('div').classed('metrics-abatementCost-container sitegroupAction-metricsItem-container', true)
														npvContainer.append('div').classed('metrics-npvLabel metrics-label', true).html('Net present value')
														npvContainer.append('div').classed('metrics-npv metrics-data', true).html(npv)
													const irrContainer = bcMetricsContainer.append('div').classed('metrics-abatementCost-container sitegroupAction-metricsItem-container', true)
														irrContainer.append('div').classed('metrics-irrLabel metrics-label', true).html('Rate of return')
														irrContainer.append('div').classed('metrics-irr metrics-data', true).html(rateOfReturn)
													const discountedPbContainer = bcMetricsContainer.append('div').classed('metrics-abatementCost-container sitegroupAction-metricsItem-container', true)
														discountedPbContainer.append('div').classed('metrics-discountedPaybackLabel metrics-label', true).html('Disounted payback')
														discountedPbContainer.append('div').classed('metrics-discountedPayback metrics-data', true).html(discountedPayback)

										// IV. BUSINESS CASE DCF TABLE: Add one table per action
											const busCaseContainer = detailedBCContainer.append('div').classed('actionBC-container page-break-avoid', true),
												actionYears = actionBCdata.businessCase['Net cash flow'].map((d, i) => 'Year '+i)

											busCaseContainer.append('div').classed('actionBC-sitegroup-header', true).html(sitegroup)
											busCaseContainer.append('div').classed('actionBC-header-container', true).html(actionParameters.meta.label)

											// Add table container
											const busCaseTableContainer = busCaseContainer.append('div').classed('actionBC-table-container', true),
													busCaseTable = busCaseTableContainer.append('table')
																	.attr('id', `report-dcf-table-${helpers.camelize(sitegroup)}-${counter}`)
																	.classed('actionBC-table summary-table', true)
											// Add CSV export
											busCaseCSV = busCaseTableContainer.append('div')
															.attr('target', `report-dcf-table-${helpers.camelize(sitegroup)}-${counter}`)
															.classed('csvExport button', true)
															.html('Export to CSV')

											// Build table header content
											const busCaseHeader = busCaseTable.append('thead'),
												busCaseHeaderRow = busCaseHeader.append('tr').classed('sector data-row', true)

											busCaseHeaderRow.append('th').classed('report-actionBC-time-header', true).html('Model year')
											actionYears.forEach(year => {
												busCaseHeaderRow.append('th').classed('report-actionBC-time-year', true).html(year)
											})
											// Build table body content
											const busCaseBody = busCaseTable.append('tbody')

											// Cash outflow rows
												busCaseBody.append('tr').classed('subheader-row sector data-row', true)
													.append('th').classed('report-actionBC-subHeader', true)
													.attr('width', '100%')
													.html('Costs')
												// i. Capital cost
												const capCostRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												capCostRow.append('td').classed('report-actionBC-label', true).html('Capital cost')
												actionYears.forEach((year, i) => {
													capCostRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Marginal capital cost'][i]))
												})
												// ii. Added O&M cost
												if(d3.sum(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'] ) >= 0){
													const omCostRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
													omCostRow.append('td').classed('report-actionBC-label', true).html('Operations and maintenance cost')
													actionYears.forEach((year, i) => {
														omCostRow.append('td').classed('report-actionBC-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'][i]))
													})
												}
												// iii. Additional costs (for switches)
												if(d3.sum(actionBCdata.businessCase['Cashflow items']['Additional cost'] ) > 0){
													const addCostRow = busCaseBody.append('tr').classed('data-row sector data-row', true),
														switchCostsLabel = (actionParameters.impact.to[0].sector === 'Stationary energy' || actionParameters.impact.to[0].sector === 'Transport') ? "Switched to fuel costs"
																		: "Switched to item costs"
													addCostRow.append('td').append('report-actionBC-label', true).html(switchCostsLabel)
													actionYears.forEach((year, i) => {
														addCostRow.append('td').classed('report-actionBC-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Additional cost'][i]))
													})
												}

											// Cash inflow rows
												busCaseBody.append('tr').classed('subheader-row sector data-row', true)
													.append('th').classed('report-actionBC-subHeader', true)
													.attr('width', '100%')
													.html('Benefits')
												// i. Avoided cost / financial saving
												const financialSavingRow = busCaseBody.append('tr').classed('table-dataRow-container', true),
													financialSavingLabel = (actionParameters.impact.from[0].sector === 'Stationary energy') ? "Energy cost saving"
																		: actionParameters.impact.from[0].sector === 'Transport'  ? "Fuel cost saving" 
																		: "Avoided spend"
												financialSavingRow.append('td').classed('report-actionBC-label', true).html(financialSavingLabel)
												actionYears.forEach((year, i) => {
													financialSavingRow.append('td').classed('report-actionBC-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Avoided cost'][i]))
												})
												// ii. For reduced O&M costs
												if(d3.sum(actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'] ) < 0){
													const negOmCostRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
													negOmCostRow.append('tr').classed('report-actionBC-label', true).html('Operations and maintenance cost')
													actionYears.forEach((year, i) => {
														negOmCostRow.append('td').classed('report-actionBC-data', true).html(helpers.numberFormatters.formatComma(-actionBCdata.businessCase['Cashflow items']['Marginal operations and maintenance cost'][i]))
													})
												}
												// iii. For generation
												if(d3.sum(actionBCdata.businessCase['Cashflow items']['Revenue'] ) > 0){
													const genBenefitRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
													genBenefitRow.append('tr').classed('report-actionBC-label', true).html('Revenue from generation')
													actionYears.forEach((year, i) => {
														genBenefitRow.append('td').classed('report-actionBC-data', true).html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cashflow items']['Revenue'][i]))
													})
												}

											// Cash flow summary
												busCaseBody.append('tr').classed('subheader-row sector data-row', true)
													.append('th').classed('report-actionBC-subHeader', true)
														.attr('width', '100%')
														.html('Cash flow summary')
												// i. Net cash flow 
												const netCashflowRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												netCashflowRow.append('tr').classed('report-actionBC-label', true).html('Net cash flow')
												actionYears.forEach((year, i) => {
													netCashflowRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Net cash flow'][i]))
												})
												// ii. Cumulativee cash flow 
												const cumCashflowRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												cumCashflowRow.append('tr').classed('report-actionBC-label', true).html('Cumulative cash position')
												actionYears.forEach((year, i) => {
													cumCashflowRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cumulative cash flow'][i]))
												})
												// iii. Discounted cash flow 
												const discCashflowRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												discCashflowRow.append('tr').classed('report-actionBC-label', true).html('Discounted net cash flow (at '+helpers.numberFormatters.formatPct1dec(settings.parameters.financial["Discount factor"][1]-1)+' p.a.)')
												actionYears.forEach((year, i) => {
													discCashflowRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Discounted cash flow'][i]))
												})
												// iv. Cumulative Discounted cash flow 
												const cumDCFRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												cumDCFRow.append('tr').classed('report-actionBC-label', true).html('Cumulative discounted net cash flow')
												actionYears.forEach((year, i) => {
													cumDCFRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Cumulative DCF'][i]))
												})
											// Emissions and natural unit impacts
												busCaseBody.append('tr').classed('subheader-row sector data-row', true)
													.append('th').classed('report-actionBC-subHeader', true)
													.attr('width', '100%')
													.html('Action impacts')
												// i. Net emissions
												const netEmissionsRow = busCaseBody.append('tr').classed('data-row sector data-row', true)
												netEmissionsRow.append('tr').classed('report-actionBC-label', true).html('Net emissions reduction (tCO2-e)')
												actionYears.forEach((year, i) => {
													netEmissionsRow.append('td').classed('report-actionBC-data', true)
														.html(helpers.numberFormatters.formatComma(actionBCdata.businessCase['Emissions abatement'][i] / actionSettings.uptakeTotalSites))
												})		
									}
								})
							}
						})
					}
				})

				// 3c. Udpate misc table headers
				d3.select('#report-actionSummary-table-reduction-header').html(`Emissions reduction in ${settings.targets.byAgency[ui.state.agencyName].targetYear}`)

				// 4.  Build the action descriptions table 
				const actionDescContainerGroup = d3.select('#report-actionDescriptions-container')
				Object.entries(modelledActions).forEach(([sector, actionObj ]) => {
					actionDescContainerGroup.append('div').classed('report-sector-label', true)
						.attr('contenteditable', true)
						.html('Actions to reduce emissions from '+sector)

					const sectorDescContainer = actionDescContainerGroup.append('div').classed('report-actionDesc-sector-container' , true)
					Object.entries(actionObj).forEach(([actionID, sitegroupArray]) => {

						const actionDescContainer = sectorDescContainer.append('div').classed('action-container report-card-shadow', true)
						actionDescContainer.append('div').classed('action-title', true)
							.attr('contenteditable', true)
							.html(model.action.parameters[actionID].meta.label)
						actionDescContainer.append('div').classed('action-image-container', true)
							.append('img').attr('src', model.action.parameters[actionID].meta.imageURL)

						const actionContent = actionDescContainer.append('div').classed('action-content', true)
							const scopeContainer = actionContent.append('div').classed('action-scope', true)
							scopeContainer.append('div').html('Areas where action is planned:')
								const scopeListContainer = scopeContainer.append('ul')
								sitegroupArray.forEach( sitegroup => scopeListContainer.append('li').html(sitegroup) )
							scopeContainer.append('div').classed('action-description', true)
								.attr('contenteditable', true)
								.html(model.action.parameters[actionID].meta.description)
					})
				})

				// 5. For all assumption tables: set the colspan for all main table header rows  and remove existing data cells
				d3.selectAll('.report-table-time-header').attr('colspan', reportYears.length + 5 )

				// 6. Build the activity multiplier assumptions sector table
				const activityTableBody= d3.select('#report-activity-assumptions-table tbody')
				reportYears.forEach(year => d3.select('#report-activity-assumptions-year-headers').append('th').classed('right assumption-table-header', true).html(year)) // Add the year labels to the header	 

				sitegroups.sort().forEach(sitegroup => {
					const sitegroupRow = activityTableBody.append('tr').classed('header-row level assumption-table-data', true)					
						sitegroupRow.append('td').attr('colspan', 4).classed('action-summary-title', true)
							.html(sitegroup)
						reportYears.forEach((year, i) => { 
							sitegroupRow.append('td').classed('assumption-table-data right', true)
								.html(helpers.numberFormatters.formatComma2dec(settings.parameters.activityGrowth[ui.state.agencyName][sitegroup].value[i]))
						})
				})

				// 7. Add the CASPER consumption/cost and GREP tables
				const consumptionTable = d3.select('#report-consumption-table tbody')
				d3.select('#report-consumption-subheader').html(`Modelled consumption and cost data for FY${dataModel.schema.baselineYear-1}/${dataModel.schema.baselineYear-2000}`)
				d3.select('#report-grep-completed-header').html(`Completed by the end of FY${dataModel.schema.baselineYear-1}/${dataModel.schema.baselineYear-2000}`)
				// Consumption table
				ui.inventoryOrder.forEach( inventoryObj => {
					const sector = Object.keys(inventoryObj)[0],
						sourceList = Object.values(inventoryObj)[0]
					if(refCaseData[sector] && Object.keys(refCaseData[sector]).length > 0){
						sourceList.forEach(source => {
							const sourceData = refCaseData[sector][source]
							if(typeof sourceData !== 'undefined' && d3.sum(sourceData.naturalVolume) > 0) {
								const consumption = sourceData.naturalVolume[0],
									consumptionUnit = sourceData.naturalUnit,
									cost = sourceData.cost[0],
									rowContainer = consumptionTable.append('tr')
								rowContainer.append('td').attr('colspan', 3).classed('source-header inventory-datum left', true)
									.html(source)
								rowContainer.append('td').classed('inventory-datum right', true).attr('colspan', 2)
									.html(consumption < 100 ? helpers.numberFormatters.formatComma1dec(consumption) :  helpers.numberFormatters.formatComma(consumption) )
								rowContainer.append('td').classed('inventory-datum left', true)
									.html(consumptionUnit)
								rowContainer.append('td').attr('colspan', 2).classed('inventory-datum right', true)
									.html(helpers.numberFormatters.formatCostInteger(cost))
							}
						})
					}
				})
				// GREP table
				const grepTable = d3.select('#report-grep-table tbody')
				if(grepData.filter(d => d.agency === ui.state.agencyName).length > 0){
					// For all classified projects
					dataModel.schema.grepProjects.projectTypes.sort().forEach(projectType => {
						const completed = grepData.filter(d => d.agency === ui.state.agencyName && d.type === projectType && d.baseImpact !== 0).length,
							planned = grepData.filter(d => d.agency === ui.state.agencyName && d.type === projectType && d.baseImpact === 0).length
						if(completed > 0 || planned > 0){
							const rowContainer = grepTable.append('tr')
							rowContainer.append('td').attr('colspan', 3).classed('source-header inventory-datum left', true)
								.html(projectType)
							rowContainer.append('td').classed('inventory-datum centre', true)
								.html(helpers.numberFormatters.formatComma(completed) )
							rowContainer.append('td').classed('inventory-datum centre', true)
								.html(helpers.numberFormatters.formatComma(planned) )
						}	
					})
					// For all unclassified projects
						const noClassCompleted = grepData.filter(d => d.agency === ui.state.agencyName && d.type === '' && d.baseImpact !== 0).length,
							noClassPlanned = grepData.filter(d => d.agency === ui.state.agencyName && d.type === '' && d.baseImpact === 0).length

						if(noClassCompleted > 0 || noClassPlanned > 0){
							const rowContainer = grepTable.append('tr')
							rowContainer.append('td').attr('colspan', 3).classed('source-header inventory-datum left', true)
								.html('Not classified')
							rowContainer.append('td').classed('inventory-datum centre', true)
								.html(helpers.numberFormatters.formatComma(noClassCompleted) )
							rowContainer.append('td').classed('inventory-datum centre', true)
								.html(helpers.numberFormatters.formatComma(noClassPlanned) )
						}
				} else {
					const rowContainer = grepTable.append('tr')
					rowContainer.append('td').attr('colspan', 5).classed('source-header inventory-datum centre', true)
						.html('There are no GREP projects in the databse for '+ui.state.agencyName )
				}

				// 8. Build the and global assumptions sections
				reportYears.forEach((year, i) => {
					// a. Add year headers
					d3.select('#report-financial-assumptions-year-headers').append('th').classed('right assumption-table-header', true).html(year)
					d3.select('#report-emissions-assumptions-year-headers').append('th').classed('right assumption-table-header', true).html(year)
					// b. Add prices
					d3.select('#report-assumptions-elecPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_ElecBlended.value[i])
					d3.select('#report-assumptions-ppaPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_ElecBlended.value[i] + settings.parameters.general.price_PPA.value[i])
					d3.select('#report-assumptions-fitPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_SolarFeedIn.value[i])
					d3.select('#report-assumptions-gasPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_Gas.value[i])
					d3.select('#report-assumptions-lpgPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_BottledLPG.value[i])
					d3.select('#report-assumptions-petrolTransportPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_Petrol.value[i])
					d3.select('#report-assumptions-lpgTransportPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_LPGTransport.value[i])
					d3.select('#report-assumptions-dieselTransportPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_DieselTransport.value[i])
					d3.select('#report-assumptions-e85Price-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_BiodieselB20.value[i])
					d3.select('#report-assumptions-b20Price-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_EthanolE85.value[i])
					d3.select('#report-assumptions-avePaperPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_PaperAverage.value[i])
					d3.select('#report-assumptions-accommDomesticPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_AccomDomestic.value[i])
					d3.select('#report-assumptions-accommInternationalPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_AccomInternational.value[i])
					d3.select('#report-assumptions-airTravelShortPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_AirTravelShort.value[i])
					d3.select('#report-assumptions-airTravelMedPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_AirTravelMed.value[i])
					d3.select('#report-assumptions-airTravelLongPrice-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.general.price_AirTravelLong.value[i])
					// b. Add emissions factors
					d3.select('#report-assumptions-gridElec-scope2-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_GridFactorNSW_CO2_per_MWH.scope2[i])
					d3.select('#report-assumptions-gridElec-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_GridFactorNSW_CO2_per_MWH.scope3[i])
					d3.select('#report-assumptions-naturalGas-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_PipedGas_CO2_per_GJ.scope1[i])
					d3.select('#report-assumptions-naturalGas-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_PipedGas_CO2_per_GJ.scope3[i])
					d3.select('#report-assumptions-lpg-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_LPG_bottled_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-lpg-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_LPG_bottled_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-dieselTransport-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_Diesel_transport_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-dieselTransport-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_Diesel_transport_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-lpgTransport-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_LPG_transport_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-lpgTransport-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_LPG_transport_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-petrol-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_Gasoline_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-petrol-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_Gasoline_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-b20-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_B20_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-b20-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_B20_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-e85-scope1-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_E85_tCO2_per_kL.scope1[i])
					d3.select('#report-assumptions-e85-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_E85_tCO2_per_kL.scope3[i])
					d3.select('#report-assumptions-airTravelShort-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_FlightsShortHaul_tCO2_per_km.scope3[i])
					d3.select('#report-assumptions-airTravelMedium-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_FlightsMediumHaul_tCO2_per_km.scope3[i])
					d3.select('#report-assumptions-airTravelLong-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_FlightsLongHaul_tCO2_per_km.scope3[i])
					d3.select('#report-assumptions-ciWaste-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_Waste_CI_tCO2_per_t.scope3[i])
					d3.select('#report-assumptions-waterReticulated-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_WaterSupply_tCO2_per_ML.scope3[i])
					d3.select('#report-assumptions-paperAverage-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_PaperAve_tCO2_per_tonne.scope3[i])
					d3.select('#report-assumptions-accomodationDomestic-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_AccomDomestic_tCO2_per_night.scope3[i])
					d3.select('#report-assumptions-accomodationInternational-scope3-row').append('td').classed('right assumption-table-data', true).html(settings.parameters.emissionFactors.EF_AccomInternational_tCO2_per_night.scope3[i])
				})

				// 9. Add the about MACC content
				d3.select('#report-maccAbout-text').html(content.infoPane.costCurve)

				// 10. Build the summary page
				const targetIndex = settings.parameters.horizon - model.parameters.general.baselineYear.value
				let netCashFlow = Array(dataModel.schema.modelHorizon).fill(0),
					opex = Array(dataModel.schema.modelHorizon).fill(0),
					capex = Array(dataModel.schema.modelHorizon).fill(0),
					averageSimplePayback, totalCapitalCost, averageOpex, netCumulativeCashFlow

				const stationary1 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Stationary energy']).map(d => d.emissions.Scope1).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	stationary2 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Stationary energy']).map(d => d.emissions.Scope2).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	stationaryOffset2 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Stationary energy']).map(d => d.emissionsSinks.Scope2).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	stationary3 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Stationary energy']).map(d => d.emissions.Scope3).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	stationaryOffset3 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Stationary energy']).map(d => d.emissionsSinks.Scope3).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	stationary12 = stationary1.map((d,i) => d + stationary2[i] - stationaryOffset2[i]), 
					transport1 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Transport']).map(d => d.emissions.Scope1).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	transport2 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Transport']).map(d => d.emissions.Scope2).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	transport3 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Transport']).map(d => d.emissions.Scope3).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
				 	transport12 = transport1.map((d,i) => d + transport2[i]), 
					stationaryTransport3 = stationary3.map((d,i) => d + transport3[i]),
					supplyChain3 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Supply chain']).map(d => d.emissions.Scope3).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []), 
					waste3 = Object.values(model.inventory.actionCase.byAgency[ui.state.agencyName]['Waste']).map(d => d.emissions.Scope3).reduce((r, a) => a.map((b, i) => (r[i] || 0) + b), []),
					baselineReductionTargetYearScope1 = (stationary1[0] - stationary1[targetIndex]) + (transport1[0] - transport1[targetIndex]) , 
					baselineReductionTargetYearScope2 = (stationary2[0] - stationary2[targetIndex]) + (stationaryOffset2[0] - stationaryOffset2[targetIndex]),
					baselineReductionTargetYearScope3 = (stationary3[0] - stationary3[targetIndex]) + (transport3[0] - transport3[targetIndex]) + (waste3[0] - waste3[targetIndex]) + (supplyChain3[0] - supplyChain3[targetIndex]) + (Math.abs(stationaryOffset3[targetIndex])) ,
					baselineReductionTargetYearScope12 = baselineReductionTargetYearScope1 + baselineReductionTargetYearScope2

				d3.select('#report-summary-agencyName').html(ui.state.agencyName)
				d3.select('#report-emissions-baseline-year-S12').html(`Scope 1 and 2 emissions in ${casperBaselineYear-1}/${casperBaselineYear-2000}`)
				d3.select('#report-emissions-baseline-year-S3').html(`Scope 3 emissions in ${casperBaselineYear-1}/${casperBaselineYear-2000}`)
				d3.select('#report-summary-emissions-S12').html(helpers.numberFormatters.formatComma(totalEmissions.Total[0] - totalEmissions.Scope3[0]))
				d3.select('#report-summary-emissions-S3').html(helpers.numberFormatters.formatComma(totalEmissions.Scope3[0]))

				// Sector emissions
				d3.select('#report-summary-emissions-stationary-S12').html(`${helpers.numberFormatters.formatComma(stationary12[0])} tCO<sub>2</sub>-e`)
				d3.select('#report-summary-emissions-stationary-S3').html(`${helpers.numberFormatters.formatComma(stationary3[0])} tCO<sub>2</sub>-e`)
				d3.select('#report-summary-emissions-transport-S12').html(`${helpers.numberFormatters.formatComma(transport12[0])} tCO<sub>2</sub>-e`)
				d3.select('#report-summary-emissions-transport-S3').html(`${helpers.numberFormatters.formatComma(transport3[0])} tCO<sub>2</sub>-e`)
				d3.select('#report-summary-emissions-supply-chain-S3').html(`${helpers.numberFormatters.formatComma(supplyChain3[0])} tCO<sub>2</sub>-e`)
				d3.select('#report-summary-emissions-waste-S3').html(`${helpers.numberFormatters.formatComma(waste3[0])} tCO<sub>2</sub>-e`)

				d3.select('#report-summary-emissions-impact-S12').html(`${helpers.numberFormatters.formatComma(baselineReductionTargetYearScope12)}`)
				d3.select('#report-summary-emissions-impact-equivalant-S12').html(`equivalent to a ${helpers.numberFormatters.formatPct(Math.abs(baselineReductionTargetYearScope12)/(agencyScope1 + agencyScope2))} 
					reduction in ${settings.targets.byAgency[ui.state.agencyName].targetYear}`)

				d3.select('#report-summary-emissions-impact-S3').html(`${helpers.numberFormatters.formatComma(baselineReductionTargetYearScope3)}`)
				d3.select('#report-summary-emissions-impact-equivalant-S3').html(`equivalent to a ${helpers.numberFormatters.formatPct(Math.abs(baselineReductionTargetYearScope3)/(agencyScope3))} 
					reduction in ${settings.targets.byAgency[ui.state.agencyName].targetYear}`)

				d3.select('#report-summary-emissions-target-S12').html(helpers.numberFormatters.formatPct(1 - settings.targets.byAgency[ui.state.agencyName].targetPct_S12)+' reduction' )
				d3.select('#report-summary-target-by-S12').html(`in Scope 1 and 2 emissions by ${settings.targets.byAgency[ui.state.agencyName].targetYear}, from the baseline year of ${casperBaselineYear-1}/${casperBaselineYear-2000}`)
				d3.select('#report-summary-emissions-target-S3').html(helpers.numberFormatters.formatPct(1 - settings.targets.byAgency[ui.state.agencyName].targetPct_S3)+' reduction' )
				d3.select('#report-summary-target-by-S3').html(`in Scope 3 emissions by ${settings.targets.byAgency[ui.state.agencyName].targetYear}, from the baseline year of ${casperBaselineYear-1}/${casperBaselineYear-2000}`)

				d3.select('#report-summary-abatement-cost').html( !isNaN(vis.costCurve.metrics.aveAbatementCost) ? helpers.numberFormatters.formatCost1dec(vis.costCurve.metrics.aveAbatementCost) : '-')

				if(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]){
					const netCashFlowArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Net cash flow'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						}))),
					 	marginalCapexArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Cashflow items']['Marginal capital cost'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						}))),
					 	marginalOpexArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Cashflow items']['Marginal operations and maintenance cost'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						}))),
					 	additionalCostArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Cashflow items']['Additional cost'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						}))),
					 	avoidedCostArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Cashflow items']['Avoided cost'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						}))),
					 	revenueArray = [].concat.apply([], Object.entries(model.action.businessCase.byAgency_sitegroup[ui.state.agencyName]).map(([sitegroup,sitegroupObj]) =>  Object.entries(sitegroupObj).map( ([actionID, d]) => {
							return d.businessCase['Cashflow items']['Revenue'].map(e => e * settings.action.byAgency_sitegroup[ui.state.agencyName][sitegroup][actionID].uptakeTotalSites) 
						})))

					netCashFlowArray.forEach(array => {
						netCashFlow = netCashFlow.map((d,i) => d + (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					marginalCapexArray.forEach(array => {
						capex = capex.map((d,i) => d + (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					// Operational expenditure is: Opex + additionalCost - avoidedCost - revenue
					marginalOpexArray.forEach(array => {
						opex = opex.map((d,i) => d + (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					additionalCostArray.forEach(array => {
						opex = opex.map((d,i) => d + (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					avoidedCostArray.forEach(array => {
						opex = opex.map((d,i) => d - (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					revenueArray.forEach(array => {
						opex = opex.map((d,i) => d - (typeof(array[i]) !== 'undefined' ? array[i] : 0 ))
					})
					totalCapitalCost = d3.sum(capex) < 1000000 
						? `$${helpers.numberFormatters.formatComma( d3.sum(capex))}` 
						: `$${helpers.numberFormatters.formatComma2dec( d3.sum(capex)/1000000)} million`

					averageOpex = -d3.mean(opex.slice(0, (settings.parameters.horizon - dataModel.schema.baselineYear))) < 1000000 
						? `$${helpers.numberFormatters.formatComma(-d3.mean(opex.slice(0, (settings.parameters.horizon - dataModel.schema.baselineYear))))}` 
						: `$${helpers.numberFormatters.formatComma2dec(-d3.mean(opex.slice(0, (settings.parameters.horizon - dataModel.schema.baselineYear)))/1000000)} million` 

					netCumulativeCashFlow = netCashFlow.reduce((a, x, i) => [...a, x + (a[i-1] || 0)], []),

					averageSimplePayback = isNaN(helpers.payback(netCumulativeCashFlow, dataModel.schema.modelHorizon))
						? '-'
						:	Math.abs(helpers.payback(netCumulativeCashFlow, dataModel.schema.modelHorizon) *10) /10 === 1 
							? `${helpers.numberFormatters.formatComma1dec(helpers.payback(netCumulativeCashFlow, dataModel.schema.modelHorizon))} year` 
							: `${helpers.numberFormatters.formatComma1dec(helpers.payback(netCumulativeCashFlow, dataModel.schema.modelHorizon))} years` 
				}

				d3.select('#report-summary-average-opex').html(averageOpex)
				d3.select('#report-summary-total-capex').html(totalCapitalCost)
				d3.select('#report-summary-average-payback').html(averageSimplePayback)
				d3.select('#report-summary-average-capex-by').html(`in total from now until ${settings.targets.byAgency[ui.state.agencyName].targetYear}`)
				d3.select('#report-summary-average-opex-by').html(`per year until ${settings.targets.byAgency[ui.state.agencyName].targetYear}`)
				d3.selectAll('#report-summary-emissions-by-sector-group *').remove()
				const reportEmissionSectorContainer = d3.select('#report-summary-emissions-by-sector-group')

				ui.inventoryOrder.forEach(obj => {
					const sector = Object.keys(obj)[0]
					if(totalEmissions.bySector[sector] > 0){
						const container = reportEmissionSectorContainer.append('div').classed('report-summary-emissions-by-sector-container', true)
						container.append('div').classed('report-summary-sector-label', true).html(sector)
						container.append('div').classed('report-sector-ghg', true).html(`${helpers.numberFormatters.formatComma(totalEmissions.bySector[sector])} tCO<sub>2</sub>-e`)
					}
				})

				// 11. Add the export to CSV button events
				d3.selectAll('.csvExport').on("click", function(){ helpers.exportTableToCSV(this.getAttribute('target'))})
			} // End of condition that a user edited 

			// WHen no agency is selected 
			else {
				console.log('No report available, no agency is selected')
			}
		}; // end updateReport()


//////////////////////////////////////////////////
///  5.  SAVE AND LOAD JSON FILE FUNCTIONALITY ///
//////////////////////////////////////////////////

	// SAVE-LOAD FUNCTIONALY 
    async function addFileManagement(){
    	console.log('***** 5. ADDING FILE MANAGEMENT ******')
    	d3.select('#saveSettings').on('click', saveFile)
		d3.select("#file-load-pane").on("click", () => 	document.getElementById("hidden-file-upload").click() )		// Opens (hidden) Choose file button
	    d3.select("#hidden-file-upload").on("change", loadAllSettings)
	    d3.select('#file-load-description').html("You can upload any settings file by clicking on the load icon above. This will load <em>all</em> your edited and saved reduction actions, activity growth paths and general model settings from your saved file. If you have mulitple saved files - for example separate files for each agency or business type - you can load these consecutively and then save a merged settings file.")

		// Save file to external JSON text
		function saveFile(){
			console.log('Saving file')
	      	let blob = new Blob([window.JSON.stringify(settings)], {type: "text/plain;charset=utf-8"})
	      	saveAs(blob, 'NZP-Tool-settingsData.txt');
	      	window.alert("Your net zero tool settings file has now been saved to your device");
		}; // end saveFile()

		// Simple load of a
		function loadAllSettings(){
			if (window.File && window.FileReader && window.FileList && window.Blob) {
	        	const uploadFile = this.files[0];
	        	const filereader = new window.FileReader();
		        filereader.onload = async function(){
		          	const txtRes = filereader.result;			// text string of loaded file
		          	// Error handling: check for structure then update tool with settings
		          	try{
		          		if(ui.state.loadType === 'full' ){
							settings = JSON.parse(txtRes);		
			            	window.alert("Your model settings, agency level activity and action data has now been loaded");								     			
		          		} else {
			          		let savedSettings = JSON.parse(txtRes),
			          		 	noActionsUpdated = 0,
			          		 	noAgencyActivityUpdated = 0
			          		// Compare and update changed action settings
			          		Object.keys(settings.action.byAgency_sitegroup).forEach( agency => {
								Object.keys(settings.action.byAgency_sitegroup[agency]).forEach(sitegroup => {
									Object.keys(settings.action.byAgency_sitegroup[agency][sitegroup]).forEach(actionID => {
										let savedAction = savedSettings.action.byAgency_sitegroup[agency][sitegroup][actionID],
											settingsAction = settings.action.byAgency_sitegroup[agency][sitegroup][actionID]									
										if(savedAction.userUpdated){
											settings.action.byAgency_sitegroup[agency][sitegroup][actionID] = savedAction										
											noActionsUpdated++
										}
									})
								})
			          		})
			          		// Compare and update the agency-sitegroup activity settings
			          		Object.keys(savedSettings.parameters.activityGrowth).forEach( agency => {
			          			Object.keys(savedSettings.parameters.activityGrowth[agency]).forEach(sitegroup => {									
									let savedActivity = savedSettings.parameters.activityGrowth[agency][sitegroup],
										settingsActivity = settings.parameters.activityGrowth[agency][sitegroup]							
									if(	savedActivity.userUpdated){
										noAgencyActivityUpdated++
										settings.parameters.activityGrowth[agency][sitegroup] = savedActivity
									}
			          			})
			          		})
							// Overwrite model parameters
							settings.parameters.emissionFactors = savedSettings.parameters.emissionFactors
							settings.parameters.general = savedSettings.parameters.general
							settings.parameters.financial = savedSettings.parameters.financial
							ui.methods.nav.updateSettingsPage()
			            	window.alert("Action data for "+noActionsUpdated+" actions has now been loaded | Forecast acivity growth multipliers for "+noAgencyActivityUpdated+" agency-building types has been loaded | Global model settings have been loaded.");	
		          		}
						ui.state.pendingLoad = true
						await updateActionModel('Loaded settings file')
						await aggregateActionModels()
						await buildActionAndSwitchToCase(true)
		        		ui.state.pendingActionCaseRecalc = ui.state.agencyName === 'All agencies' ? false : true
		        		ui.state.pendingChartUpdate = ui.state.agencyName === 'All agencies' ? false : true


		          	} catch(err){
		            	window.alert("Error parsing uploaded file\nerror message: " + err.message);
		            	return;
		          	}
		        };
		        filereader.readAsText(uploadFile);
	      	} else {
	        	alert("Your browser won't let you load this file -- try using Chrome, Firefox, Safari or Edge.");
	      	}
		};
    };

//////////////////////////////
/// 6. UPDATE INTRO SCREEN ///
//////////////////////////////

	// Update intro screen update when tool is ready  
	async function toolReady(){
		d3.select('#intro-button')
			.classed('loading', false)
			.classed('loaded', true)
			.html("...and we're ready!  Tap here to begin")
			.on('click', () => {
				d3.select("#loader-container").transition().duration(1000).style('opacity', 0)
				ui.methods.nav.toggleMainMenu()
				setTimeout( () => {
					d3.select("#loader-container").classed('hidden', true)
					d3.selectAll("#header-pane, #content-pane, #overlay-nav").classed('hidden', false).style('opacity', 0)
						.transition().duration(800)
						.style('opacity', null)
					d3.select('#header-contentName').html('Emissions profile').transition().duration(800).style('opacity', null)
					d3.selectAll('.central-pane-scene').classed('hidden', true)
					d3.select('#scene-emissions').classed('hidden', false)
						.transition().duration(800)
						.style('opacity', null)
				}, 1000)
			})
		ui.methods.dataView.updateActionDataTable() 
		dataModel.uptake.updatePresets()		
	}; // end toolReady()


///////////////////////
/// HELPER METHODS  ///
///////////////////////

	const helpers = {
		parseTimeA: 		d3.timeParse("%d/%m/%Y"),
		parseTimeB: 		d3.timeParse("%d/%m/%y"),	
        numberFormatters: {
            formatComma:           	d3.format(",.0f"),
            formatComma1dec:       	d3.format(",.1f"),
            formatComma2dec:       	d3.format(",.2f"),
            formatInteger:         	d3.format(".0f"),   
            formatCostInteger:     	d3.format("$,.0f"),  
            formatCost1dec:        	d3.format("$,.1f"),  
            formatPct:          	d3.format(".0%"), 
            formatPct1dec:          d3.format(".1%")  
        },
        countDecimals: function(value) {
						    if (Math.floor(value) !== value)
						        return value.toString().split(".")[1].length || 0;
						    return 0;
					},	
		payback: 	function(cfArray, actionLife){				// Return payback period for an array of cash flows
						if(cfArray[0] > 0){
							return "Under one year"
						} else if (cfArray[actionLife] < 0){
							return "No payback"
						} else {
							for( let i = 0; i < cfArray.length; i++){
								if(cfArray[i] > 0){
									return (i-1) + cfArray[i-1] / (cfArray[i-1] - cfArray[i])
								} 
							}
						} 
					},

	 	IRR: 		function(values, guess) {					// Return the Internal rate of return from an array of net cash flows  >  Copyright (c) 2012 Sutoiku, Inc. (MIT License) | Some algorithms have been ported from Apache OpenOffice | Credits: algorithm inspired by Apache OpenOffice
					 	// Calculates the resulting amount
					  	var irrResult = function(values, dates, rate) {
					   	 	var r = rate + 1;
					    	var result = values[0];
					    	for (var i = 1; i < values.length; i++) {
					      		result += values[i] / Math.pow(r, (dates[i] - dates[0]) / 365);
					    	}
					    	return result;
					  	}
					  	// Calculates the first derivation
					  	var irrResultDeriv = function(values, dates, rate) {
					    	var r = rate + 1;
					    	var result = 0;
					    	for (var i = 1; i < values.length; i++) {
					      		var frac = (dates[i] - dates[0]) / 365;
					      		result -= frac * values[i] / Math.pow(r, frac + 1);
					    	}
					    	return result;
					  	}
					  	// Initialize dates and check that values contains at least one positive value and one negative value
					  	var dates = [];
					  	var positive = false;
					  	var negative = false;
					 	for (var i = 0; i < values.length; i++) {
					    	dates[i] = (i === 0) ? 0 : dates[i - 1] + 365;
					    	if (values[i] > 0) positive = true;
					    	if (values[i] < 0) negative = true;
					  	}	  
					 	// Return error if values does not contain at least one positive value and one negative value
					  	if (!positive || !negative) return '#NUM!';
					  	var guess = (typeof guess === 'undefined') ? 0.1 : guess;				// Initialize guess and resultRate
					 	var resultRate = guess;
					  	var epsMax = 1e-10;														// Set maximum epsilon for end of iteration
					  	var iterMax = 50;														// Set maximum number of iterations

					  	// Implement Newton's method
					  	var newRate, epsRate, resultValue;
					  	var iteration = 0;
					  	var contLoop = true;
					  	do {
					    	resultValue = irrResult(values, dates, resultRate);
					    	newRate = resultRate - resultValue / irrResultDeriv(values, dates, resultRate);
					    	epsRate = Math.abs(newRate - resultRate);
					    	resultRate = newRate;
					    	contLoop = (epsRate > epsMax) && (Math.abs(resultValue) > epsMax);
					  	} while(contLoop && (++iteration < iterMax));
						if(contLoop) return '#NUM!';
						  
					  	// Return internal rate of return
					  	return resultRate;
					},
		camelize: 	function(str) {
				        return str.replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, function(match, index) {
				            if (+match === 0) return ""; // or if (/\s+/.test(match)) for white spaces
				            return index == 0 ? match.toLowerCase() : match.toUpperCase();
				        })
					},
	 	downloadCSV(csv, filename) {							// Adapted from https://www.codexworld.com/export-html-table-data-to-csv-using-javascript/
						var csvFile,  downloadLink;
						csvFile = new Blob([csv], {type: "text/csv"}); 				// CSV file
						downloadLink = document.createElement("a");					// Download link
						downloadLink.download = filename+'.csv';					// File name
						downloadLink.href = window.URL.createObjectURL(csvFile);	// Create a link to the file
						downloadLink.style.display = "none"; 						// Hide download link
						document.body.appendChild(downloadLink); 					// Add the link to DOM
						downloadLink.click(); 										// Click download link
					},
		exportTableToCSV(target) {
						var csv = [];
						var rows = document.querySelectorAll("table#"+target+" tr");
						for (var i = 0; i < rows.length; i++) {
							var row = [], cols = rows[i].querySelectorAll("td, th");
							for (var j = 0; j < cols.length; j++) 
								row.push(cols[j].innerText.replace(/,/g, '')); 	// Remove all commas
							csv.push(row.join(","));        
						}
						// Download CSV file
						helpers.downloadCSV(csv.join("\n"), target);
					}
	}

	// Warn the user when leaving the page
	window.onbeforeunload = function(){
		if(ui.state.reloadWarning){
			 return "Make sure to save your data locally before leaving :-)"	
		}
	}		

